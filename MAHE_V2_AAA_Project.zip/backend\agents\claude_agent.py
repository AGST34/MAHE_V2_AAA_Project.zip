"""
Claude Agent Module

Integrates the Anthropic SDK (Claude 3 Opus, Sonnet, Haiku).
Implements precise system prompting, Claude's XML-style tool parsing (or native tools),
and async streaming.
"""

import asyncio
import logging
from typing import Any, AsyncGenerator, Dict, Optional

from backend.agents.base import BaseAgent
from backend.config import settings

logger = logging.getLogger(__name__)

# Mock Anthropic SDK
class MockAnthropicAsync:
    class Messages:
        async def create(self, **kwargs):
            await asyncio.sleep(1.1)
            stream = kwargs.get("stream", False)
            
            if stream:
                class ContentBlock:
                    def __init__(self, text):
                        self.text = text
                class Event:
                    def __init__(self, text):
                        self.type = "content_block_delta"
                        self.delta = ContentBlock(text)
                        
                async def mock_stream():
                    words = "This is a streaming response from Mocked Claude.".split()
                    for word in words:
                        yield Event(word + " ")
                        await asyncio.sleep(0.08)
                return mock_stream()
            else:
                class TextBlock:
                    def __init__(self):
                        self.text = "This is a complete mock response from Anthropic Claude."
                class Response:
                    def __init__(self):
                        self.content = [TextBlock()]
                return Response()

    def __init__(self, api_key: str):
        self.messages = self.Messages()


class ClaudeAgent(BaseAgent):
    """
    Anthropic Claude specific agent.
    """

    def __init__(self, model: str = "claude-3-opus-20240229", temperature: float = 0.7, max_tokens: int = 2048):
        super().__init__(name="claude", model=model, temperature=temperature, max_tokens=max_tokens)
        
        self.api_key = settings.ANTHROPIC_API_KEY
        if not self.api_key:
            logger.warning("ANTHROPIC_API_KEY is not set. Claude Agent will fail.")
            
        self._client = None
        
    def _get_client(self):
        if not self._client:
            self._client = MockAnthropicAsync(api_key=self.api_key)
        return self._client

    async def generate_response(self, prompt: str, context: Optional[str] = None) -> str:
        client = self._get_client()
        
        # Claude specifically benefits from putting context in a system block or XML tags
        system_prompt = "You are a highly capable AI assistant."
        if context:
            system_prompt += f"\n\nContext information:\n<context>\n{context}\n</context>\nUse this context to answer queries."
            
        messages = [{"role": "user", "content": prompt}]
        
        try:
            response = await client.messages.create(
                model=self.model,
                system=system_prompt,
                messages=messages,
                max_tokens=self.max_tokens,
                temperature=self.temperature
            )
            return response.content[0].text
        except Exception as e:
            logger.error(f"Claude API Error: {str(e)}")
            raise ValueError(f"Claude generation failed: {str(e)}")

    async def stream_response(self, prompt: str, context: Optional[str] = None) -> AsyncGenerator[str, None]:
        client = self._get_client()
        
        system_prompt = "You are a helpful AI assistant."
        if context:
            system_prompt += f"\n\n<context>\n{context}\n</context>"
            
        messages = [{"role": "user", "content": prompt}]
        
        try:
            stream = await client.messages.create(
                model=self.model,
                system=system_prompt,
                messages=messages,
                max_tokens=self.max_tokens,
                temperature=self.temperature,
                stream=True
            )
            async for event in stream:
                if event.type == "content_block_delta":
                    yield event.delta.text
        except Exception as e:
            logger.error(f"Claude Streaming Error: {str(e)}")
            yield f"\n[Stream Error: {str(e)}]"
