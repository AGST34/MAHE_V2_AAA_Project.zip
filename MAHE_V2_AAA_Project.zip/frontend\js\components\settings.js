// settings.js (Expanded Settings Configuration View)
export default {
    render(app) {
        const div = document.createElement('div');
        div.className = 'settings-view fade-in flex justify-center pb-12';
        
        div.innerHTML = `
            <div class="w-full max-w-4xl flex flex-col gap-8">
                
                <div class="mb-4">
                    <h3 class="text-2xl font-bold flex items-center gap-3">
                        <svg class="w-7 h-7 text-cyan"><use href="#icon-settings"></use></svg>
                        System Configuration
                    </h3>
                    <p class="text-secondary mt-2">Manage API keys, environment parameters, and UI preferences.</p>
                </div>

                <!-- API Keys Section -->
                <section class="glass-panel p-8 rounded-xl border border-primary relative overflow-hidden">
                    <div class="absolute top-0 left-0 w-1 h-full bg-cyan"></div>
                    <h4 class="text-lg font-bold mb-6 flex items-center gap-2 border-b border-primary pb-3">
                        <svg class="w-5 h-5"><use href="#icon-dashboard"></use></svg>
                        API Integration Keys
                    </h4>
                    
                    <div class="space-y-6">
                        <!-- OpenAI -->
                        <div class="form-group">
                            <label class="flex justify-between items-center mb-2">
                                <span class="text-sm font-semibold">OpenAI API Key (Required for GPT-4 Judge)</span>
                                <span class="badge badge-success text-[10px] py-0.5">Connected</span>
                            </label>
                            <div class="flex gap-3">
                                <div class="relative flex-1">
                                    <input type="password" id="key-openai" class="form-control font-mono bg-tertiary" value="sk-proj-xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx">
                                    <button type="button" class="absolute right-3 top-1/2 transform -translate-y-1/2 text-muted hover:text-cyan toggle-password" data-target="key-openai">
                                        <svg class="w-4 h-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"></path><circle cx="12" cy="12" r="3"></circle></svg>
                                    </button>
                                </div>
                                <button class="btn btn-secondary px-6">Test</button>
                            </div>
                        </div>

                        <!-- Anthropic -->
                        <div class="form-group">
                            <label class="flex justify-between items-center mb-2">
                                <span class="text-sm font-semibold">Anthropic API Key</span>
                                <span class="badge badge-error text-[10px] py-0.5">Missing</span>
                            </label>
                            <div class="flex gap-3">
                                <div class="relative flex-1">
                                    <input type="password" id="key-anthropic" class="form-control font-mono bg-tertiary" placeholder="sk-ant-api03-...">
                                    <button type="button" class="absolute right-3 top-1/2 transform -translate-y-1/2 text-muted hover:text-cyan toggle-password" data-target="key-anthropic">
                                        <svg class="w-4 h-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"></path><circle cx="12" cy="12" r="3"></circle></svg>
                                    </button>
                                </div>
                                <button class="btn btn-secondary px-6">Test</button>
                            </div>
                        </div>
                        
                        <!-- Google -->
                        <div class="form-group">
                            <label class="flex justify-between items-center mb-2">
                                <span class="text-sm font-semibold">Google Gemini API Key</span>
                                <span class="badge badge-success text-[10px] py-0.5">Connected</span>
                            </label>
                            <div class="flex gap-3">
                                <div class="relative flex-1">
                                    <input type="password" id="key-google" class="form-control font-mono bg-tertiary" value="AIzaSyAxxxxxxxxxxxxxxxxxxxxxxxxxxxxx">
                                    <button type="button" class="absolute right-3 top-1/2 transform -translate-y-1/2 text-muted hover:text-cyan toggle-password" data-target="key-google">
                                        <svg class="w-4 h-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"></path><circle cx="12" cy="12" r="3"></circle></svg>
                                    </button>
                                </div>
                                <button class="btn btn-secondary px-6">Test</button>
                            </div>
                        </div>
                    </div>
                </section>

                <!-- Evaluation Preferences -->
                <section class="glass-panel p-8 rounded-xl border border-primary relative overflow-hidden">
                    <div class="absolute top-0 left-0 w-1 h-full bg-purple"></div>
                    <h4 class="text-lg font-bold mb-6 flex items-center gap-2 border-b border-primary pb-3">
                        <svg class="w-5 h-5"><use href="#icon-evaluate"></use></svg>
                        Evaluation Engine Preferences
                    </h4>
                    
                    <div class="grid grid-cols-2 gap-8">
                        <div class="space-y-6">
                            <div class="form-group">
                                <label class="block text-sm font-semibold mb-2">Default Judge Evaluator</label>
                                <select class="form-control bg-tertiary" id="pref-judge">
                                    <option value="gpt-4o" selected>GPT-4o (Standard)</option>
                                    <option value="claude-3-opus">Claude 3 Opus</option>
                                    <option value="gemini-1.5-pro">Gemini 1.5 Pro</option>
                                </select>
                                <p class="text-xs text-muted mt-2">The model used to determine hallucination verdicts.</p>
                            </div>
                            
                            <div class="form-group">
                                <label class="flex justify-between items-center mb-2">
                                    <span class="text-sm font-semibold">Strict Factuality Mode</span>
                                    <!-- Toggle Switch -->
                                    <label class="relative inline-flex items-center cursor-pointer">
                                        <input type="checkbox" value="" class="sr-only peer" checked>
                                        <div class="w-9 h-5 bg-tertiary peer-focus:outline-none peer-focus:ring-2 peer-focus:ring-cyan rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-cyan"></div>
                                    </label>
                                </label>
                                <p class="text-xs text-muted">Enforce zero-tolerance citation checks on generated factual claims.</p>
                            </div>
                        </div>
                        
                        <div class="space-y-6">
                            <div class="form-group">
                                <label class="block text-sm font-semibold mb-2">Maximum Parallel Threads</label>
                                <input type="number" class="form-control bg-tertiary" value="4" min="1" max="10">
                                <p class="text-xs text-muted mt-2">Number of models evaluated concurrently in batch mode.</p>
                            </div>
                            
                            <div class="form-group">
                                <label class="flex justify-between items-center mb-2">
                                    <span class="text-sm font-semibold">Auto-save to History</span>
                                    <!-- Toggle Switch -->
                                    <label class="relative inline-flex items-center cursor-pointer">
                                        <input type="checkbox" value="" class="sr-only peer" checked>
                                        <div class="w-9 h-5 bg-tertiary peer-focus:outline-none peer-focus:ring-2 peer-focus:ring-cyan rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-cyan"></div>
                                    </label>
                                </label>
                                <p class="text-xs text-muted">Automatically log all evaluation runs to local storage/database.</p>
                            </div>
                        </div>
                    </div>
                </section>

                <!-- UI Preferences -->
                <section class="glass-panel p-8 rounded-xl border border-primary relative overflow-hidden">
                    <div class="absolute top-0 left-0 w-1 h-full bg-success"></div>
                    <h4 class="text-lg font-bold mb-6 flex items-center gap-2 border-b border-primary pb-3">
                        <svg class="w-5 h-5"><use href="#icon-dashboard"></use></svg>
                        User Interface
                    </h4>
                    
                    <div class="grid grid-cols-2 gap-8">
                        <div>
                            <label class="block text-sm font-semibold mb-3">Color Theme</label>
                            <div class="flex gap-4">
                                <button class="flex-1 flex flex-col items-center gap-2 p-3 border-2 border-cyan bg-tertiary rounded-lg text-cyan">
                                    <div class="w-8 h-8 rounded-full bg-primary border border-secondary shadow-inner"></div>
                                    <span class="text-xs font-bold">Dark (Default)</span>
                                </button>
                                <button class="flex-1 flex flex-col items-center gap-2 p-3 border-2 border-primary bg-tertiary rounded-lg text-muted hover:border-secondary transition-colors opacity-50 cursor-not-allowed" title="Coming soon">
                                    <div class="w-8 h-8 rounded-full bg-white border border-gray-300 shadow-inner"></div>
                                    <span class="text-xs font-bold">Light</span>
                                </button>
                            </div>
                        </div>
                    </div>
                </section>

                <!-- Save Actions -->
                <div class="flex justify-end gap-4 mt-4 sticky bottom-6 z-20 bg-primary/80 backdrop-blur py-4 border-t border-primary">
                    <button class="btn btn-secondary px-8 py-3 font-semibold">Discard Changes</button>
                    <button id="btn-save-settings" class="btn btn-primary px-8 py-3 font-semibold shadow-lg shadow-purple-glow">Save Configuration</button>
                </div>
                
            </div>
        `;
        return div;
    },

    init(app) {
        this.app = app;
        this.bindEvents();
    },

    bindEvents() {
        // Toggle Password Visibility
        const toggles = document.querySelectorAll('.toggle-password');
        toggles.forEach(toggle => {
            toggle.addEventListener('click', (e) => {
                const targetId = e.currentTarget.getAttribute('data-target');
                const input = document.getElementById(targetId);
                if (input) {
                    input.type = input.type === 'password' ? 'text' : 'password';
                    e.currentTarget.classList.toggle('text-cyan');
                }
            });
        });

        // Save Settings logic
        const saveBtn = document.getElementById('btn-save-settings');
        if (saveBtn) {
            saveBtn.addEventListener('click', () => {
                const btn = saveBtn;
                const originalHTML = btn.innerHTML;
                btn.innerHTML = `<div class="spinner sm white mr-2 inline-block"></div> Saving...`;
                btn.disabled = true;

                setTimeout(() => {
                    btn.innerHTML = `<svg class="w-5 h-5 mr-2 inline"><use href="#icon-check"></use></svg> Saved successfully`;
                    btn.classList.add('bg-success', 'border-success');
                    
                    this.app.toast.success('System configuration updated successfully.');
                    
                    setTimeout(() => {
                        btn.innerHTML = originalHTML;
                        btn.classList.remove('bg-success', 'border-success');
                        btn.disabled = false;
                    }, 2000);
                }, 800);
            });
        }
    }
}
