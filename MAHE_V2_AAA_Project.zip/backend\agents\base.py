"""
Base AI Agent Module

Defines the abstract base class `BaseAgent` from which all concrete AI providers
(OpenAI, Gemini, Claude, Judge) inherit. Implements common patterns like
retry logic, jitter, timing, token counting estimations, error handling,
and generalized response formatting.
"""

import abc
import asyncio
import logging
import random
import time
from typing import Any, AsyncGenerator, Dict, Optional

from pydantic import BaseModel, Field

# Set up logging for agents
logger = logging.getLogger(__name__)

class AgentResponse(BaseModel):
    """
    Standardized response format returned by all generation agents.
    Provides a uniform interface regardless of the underlying LLM provider.
    """
    agent_name: str = Field(..., description="Name of the agent (e.g., 'gpt-4')")
    content: str = Field(..., description="The raw text response from the model")
    processing_time_ms: int = Field(..., description="Time taken to generate the response in milliseconds")
    
    # Optional telemetry and metadata
    prompt_tokens: int = Field(0, description="Number of tokens in the prompt")
    completion_tokens: int = Field(0, description="Number of tokens in the generated text")
    total_tokens: int = Field(0, description="Total tokens consumed")
    
    status: str = Field("success", description="Status of the generation (success, error, timeout)")
    error_message: Optional[str] = Field(None, description="Detailed error message if status is 'error'")
    metadata: Dict[str, Any] = Field(default_factory=dict, description="Provider-specific metadata")


class BaseAgent(abc.ABC):
    """
    Abstract Base Class for all AI model implementations.
    Provides concrete methods for executing requests with built-in resilience
    (retries, timeouts) and enforces abstract methods for specific provider integrations.
    """

    def __init__(self, name: str, model: str, temperature: float = 0.7, max_tokens: int = 2048):
        """
        Initialize the base agent with common parameters.
        
        Args:
            name (str): Identifier for the agent type (e.g., 'openai').
            model (str): Specific model version (e.g., 'gpt-4-turbo').
            temperature (float): Generation temperature.
            max_tokens (int): Maximum tokens to generate.
        """
        self.name = name
        self.model = model
        self.temperature = temperature
        self.max_tokens = max_tokens
        
        # Retry configuration
        self.max_retries = 3
        self.base_delay = 1.0  # seconds
        self.max_delay = 15.0  # seconds

    @abc.abstractmethod
    async def generate_response(self, prompt: str, context: Optional[str] = None) -> str:
        """
        Abstract method to generate a response from the specific LLM API.
        Must be implemented by subclasses.
        
        Args:
            prompt (str): The main user instruction.
            context (Optional[str]): Background information or retrieved documents.
            
        Returns:
            str: The raw text response.
            
        Raises:
            Exception: Any provider-specific API exceptions.
        """
        pass

    async def stream_response(self, prompt: str, context: Optional[str] = None) -> AsyncGenerator[str, None]:
        """
        Optional abstract method for streaming responses token-by-token.
        Subclasses should override this if they support streaming.
        
        Yields:
            str: Chunks of text as they are generated.
        """
        # Default fallback to non-streaming if not implemented
        logger.warning(f"Agent {self.name} does not natively support streaming. Falling back to block generation.")
        full_response = await self.generate_response(prompt, context)
        # Yield in arbitrary chunks to simulate streaming
        chunk_size = 50
        for i in range(0, len(full_response), chunk_size):
            yield full_response[i:i+chunk_size]
            await asyncio.sleep(0.05)

    def _estimate_tokens(self, text: str) -> int:
        """
        Utility method to roughly estimate token count.
        Subclasses can override with actual tiktoken/tokenizer logic.
        
        Args:
            text (str): Input text.
            
        Returns:
            int: Estimated token count (roughly 1 token per 4 chars).
        """
        if not text:
            return 0
        return len(text) // 4

    async def _execute_with_retry(self, func: callable, *args, **kwargs) -> Any:
        """
        Executes a coroutine with exponential backoff and jitter.
        Handles rate limits (429) and transient network errors (500, 503).
        """
        retries = 0
        while True:
            try:
                return await func(*args, **kwargs)
            except Exception as e:
                retries += 1
                if retries > self.max_retries:
                    logger.error(f"Agent {self.name} failed after {self.max_retries} retries. Final error: {str(e)}")
                    raise e
                
                # Exponential backoff: base_delay * 2^(retry-1)
                delay = min(self.base_delay * (2 ** (retries - 1)), self.max_delay)
                # Add Jitter: random factor between 0.5 and 1.5
                jitter = delay * (0.5 + random.random())
                
                logger.warning(f"Agent {self.name} encountered error: {str(e)}. Retrying in {jitter:.2f}s (Attempt {retries}/{self.max_retries})")
                await asyncio.sleep(jitter)

    async def run(self, prompt: str, context: Optional[str] = None, timeout_seconds: int = 60) -> AgentResponse:
        """
        Main entry point for executing the agent. 
        Wraps the specific generation logic with timing, token counting, and error handling.
        
        Args:
            prompt (str): The prompt to evaluate.
            context (str, optional): The ground truth context.
            timeout_seconds (int): Maximum allowed execution time.
            
        Returns:
            AgentResponse: Structured response container.
        """
        start_time = time.time()
        status = "success"
        error_msg = None
        content = ""
        
        # Estimate prompt tokens
        combined_text = f"{context}\n\n{prompt}" if context else prompt
        p_tokens = self._estimate_tokens(combined_text)

        try:
            # Wrap execution with timeout and retry logic
            content = await asyncio.wait_for(
                self._execute_with_retry(self.generate_response, prompt, context),
                timeout=timeout_seconds
            )
        except asyncio.TimeoutError:
            logger.error(f"Agent {self.name} timed out after {timeout_seconds}s.")
            status = "timeout"
            error_msg = "Generation timed out."
            content = "Error: Request timed out."
        except Exception as e:
            logger.exception(f"Agent {self.name} failed to generate response.")
            status = "error"
            error_msg = str(e)
            content = f"Error generating response: {error_msg}"

        end_time = time.time()
        processing_time_ms = int((end_time - start_time) * 1000)
        
        c_tokens = self._estimate_tokens(content) if status == "success" else 0

        return AgentResponse(
            agent_name=self.name,
            content=content,
            processing_time_ms=processing_time_ms,
            prompt_tokens=p_tokens,
            completion_tokens=c_tokens,
            total_tokens=p_tokens + c_tokens,
            status=status,
            error_message=error_msg,
            metadata={"model": self.model, "temperature": self.temperature}
        )
