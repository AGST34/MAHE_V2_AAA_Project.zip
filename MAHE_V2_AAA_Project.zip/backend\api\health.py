"""
Health Check API Routes Module

System health monitoring endpoints. Used by Kubernetes/Docker for liveness 
and readiness probes. Also verifies configurations of external AI providers.
"""

import time
from typing import Dict, Any

from fastapi import APIRouter
from backend.config import settings
from backend.database import check_database_health

router = APIRouter()

# Store boot time to calculate uptime
BOOT_TIME = time.time()

@router.get("", summary="General system liveness check")
async def health_check() -> Dict[str, Any]:
    """
    Fast endpoint to verify the API server is responding.
    """
    uptime_seconds = int(time.time() - BOOT_TIME)
    
    return {
        "status": "ok",
        "service": settings.PROJECT_NAME,
        "version": settings.VERSION,
        "environment": settings.ENVIRONMENT,
        "uptime_seconds": uptime_seconds
    }

@router.get("/deep", summary="Deep readiness check")
async def deep_health_check() -> Dict[str, Any]:
    """
    Checks connections to external dependencies (Database).
    """
    db_status = await check_database_health()
    
    status_code = "ok" if db_status else "degraded"
    
    return {
        "status": status_code,
        "database": "connected" if db_status else "disconnected",
    }

@router.get("/providers", summary="Check AI Provider Configurations")
async def check_providers() -> Dict[str, Any]:
    """
    Verifies which AI models have API keys configured.
    """
    providers = {
        "openai": bool(settings.OPENAI_API_KEY),
        "gemini": bool(settings.GEMINI_API_KEY),
        "anthropic": bool(settings.ANTHROPIC_API_KEY)
    }
    
    configured_count = sum(1 for v in providers.values() if v)
    
    return {
        "status": "ready" if configured_count > 0 else "missing_keys",
        "configured_count": configured_count,
        "providers": providers
    }
