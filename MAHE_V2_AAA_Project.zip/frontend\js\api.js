// api.js (Expanded API Client with intercepts, retry logic, and comprehensive wrapper)
export class Api {
    constructor(appInstance) {
        this.app = appInstance;
        // Mock base URL since there's no real backend yet
        this.baseUrl = 'http://localhost:8000/api/v1';
        this.timeout = 30000;
        this.retryAttempts = 3;
        
        // Setup interceptors
        this.interceptors = {
            request: [],
            response: []
        };
        
        this.initInterceptors();
    }

    initInterceptors() {
        // Request interceptor: add auth headers, timestamp, tracking ID
        this.addRequestInterceptor((config) => {
            const token = localStorage.getItem('mahev2_auth_token') || 'dummy-token-123';
            config.headers = {
                ...config.headers,
                'Authorization': `Bearer ${token}`,
                'X-Client-Version': this.app?.store?.getState().appMeta.version || '2.0.0',
                'X-Request-ID': this.generateRequestId()
            };
            return config;
        });

        // Response interceptor: global error handling
        this.addResponseInterceptor(
            (response) => {
                // Return just the data on success
                return response.data;
            },
            (error) => {
                console.error('[API Error Intercepted]', error);
                
                // Generic error toast for specific status codes
                if (error.status === 401) {
                    this.app?.toast.error('Session expired. Please log in again.');
                } else if (error.status === 403) {
                    this.app?.toast.warning('You do not have permission to perform this action.');
                } else if (error.status >= 500) {
                    this.app?.toast.error('Server error encountered. Retrying...');
                }
                
                return Promise.reject(error);
            }
        );
    }

    generateRequestId() {
        return 'req_' + Math.random().toString(36).substr(2, 9) + '_' + Date.now();
    }

    addRequestInterceptor(fn) {
        this.interceptors.request.push(fn);
    }

    addResponseInterceptor(onSuccess, onError) {
        this.interceptors.response.push({ onSuccess, onError });
    }

    async request(endpoint, options = {}, currentAttempt = 1) {
        const url = `${this.baseUrl}${endpoint}`;
        
        let config = {
            method: 'GET',
            headers: {
                'Content-Type': 'application/json',
                'Accept': 'application/json'
            },
            ...options
        };

        // Run request interceptors
        for (const interceptor of this.interceptors.request) {
            config = await interceptor(config);
        }

        try {
            // Simulation for Frontend-only architecture (No real backend)
            // In a real app, this would be: const response = await fetch(url, config);
            const response = await this.simulateFetch(url, config);

            let data;
            try {
                data = await response.json();
            } catch(e) {
                data = null;
            }

            const responseObj = {
                status: response.status,
                statusText: response.statusText,
                headers: response.headers,
                data: data
            };

            if (!response.ok) {
                throw responseObj;
            }

            // Run response interceptors (success)
            let result = responseObj;
            for (const interceptor of this.interceptors.response) {
                if (interceptor.onSuccess) {
                    result = await interceptor.onSuccess(result);
                }
            }

            return result;
            
        } catch (error) {
            // Retry logic
            if (currentAttempt < this.retryAttempts && (!error.status || error.status >= 500 || error.status === 408)) {
                console.warn(`API request failed. Retrying... (${currentAttempt}/${this.retryAttempts})`);
                await this.delay(Math.pow(2, currentAttempt) * 500); // Exponential backoff
                return this.request(endpoint, options, currentAttempt + 1);
            }

            // Run response interceptors (error)
            let finalError = error;
            for (const interceptor of this.interceptors.response) {
                if (interceptor.onError) {
                    try {
                        finalError = await interceptor.onError(finalError);
                    } catch (e) {
                        finalError = e;
                    }
                }
            }
            throw finalError;
        }
    }

    delay(ms) {
        return new Promise(resolve => setTimeout(resolve, ms));
    }

    // ------------------------------------------------------------------------
    // API ENDPOINT WRAPPERS
    // ------------------------------------------------------------------------

    // --- Analytics & Stats ---
    async getStats() {
        return this.request('/analytics/summary', { method: 'GET' });
    }

    async getTrendData(period = '7d') {
        return this.request(`/analytics/trends?period=${period}`, { method: 'GET' });
    }

    async getModelPerformanceMatrix() {
        return this.request('/analytics/models/matrix', { method: 'GET' });
    }

    // --- Evaluations ---
    async runEvaluation(payload) {
        return this.request('/evaluations/run', {
            method: 'POST',
            body: JSON.stringify(payload)
        });
    }
    
    async runBatchEvaluation(payloads) {
        return this.request('/evaluations/batch', {
            method: 'POST',
            body: JSON.stringify({ batch: payloads })
        });
    }

    async getEvaluationDetails(id) {
        return this.request(`/evaluations/${id}`, { method: 'GET' });
    }

    async getHistory(params = {}) {
        const query = new URLSearchParams(params).toString();
        return this.request(`/evaluations/history?${query}`, { method: 'GET' });
    }

    async deleteEvaluations(ids) {
        return this.request('/evaluations/bulk-delete', {
            method: 'POST',
            body: JSON.stringify({ ids })
        });
    }

    // --- Configuration ---
    async getSettings() {
        return this.request('/settings', { method: 'GET' });
    }

    async updateSettings(settings) {
        return this.request('/settings', {
            method: 'PUT',
            body: JSON.stringify(settings)
        });
    }

    async validateApiKeys(keys) {
        return this.request('/settings/validate-keys', {
            method: 'POST',
            body: JSON.stringify(keys)
        });
    }

    // ------------------------------------------------------------------------
    // MOCK SIMULATOR (Since we are building frontend-only for now)
    // ------------------------------------------------------------------------
    async simulateFetch(url, config) {
        await this.delay(400 + Math.random() * 600); // Simulate network latency
        
        let mockData = {};
        
        if (url.includes('/analytics/summary')) {
            mockData = {
                totalEvaluations: 12458,
                avgHallucinationRate: 8.4,
                activeModels: 6,
                avgLatency: 1.2,
                weeklyTrend: '+12%',
                rateTrend: '-2.1%'
            };
        } else if (url.includes('/evaluations/history')) {
            mockData = [
                { id: 'EVAL-1042', date: 'Oct 24, 14:32', model: 'GPT-4o', query: 'Parse JSON logs', status: 'clean', score: 0.98 },
                { id: 'EVAL-1041', date: 'Oct 24, 11:15', model: 'Claude 3', query: 'Summarize inception', status: 'hallucination', score: 0.45 }
            ];
        } else {
            mockData = { success: true, message: "Simulated response" };
        }

        return {
            ok: true,
            status: 200,
            statusText: 'OK',
            headers: new Headers(),
            json: async () => mockData
        };
    }
}
