"""
Authentication and Authorization Module

Provides utilities for hashing passwords, generating JWTs, verifying tokens,
and extracting user data from dependencies. 
Implements OAuth2 password bearer flow with scopes and API key fallback.
"""

import logging
from datetime import datetime, timedelta
from typing import Any, Dict, Optional, Union

from fastapi import Depends, HTTPException, Request, status
from fastapi.security import OAuth2PasswordBearer, SecurityScopes
from jose import JWTError, jwt
from passlib.context import CryptContext
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.future import select
from sqlalchemy.orm import selectinload

from backend.config import settings
from backend.database import get_db
from backend.models import APIKey, User
from backend.schemas import TokenData

logger = logging.getLogger(__name__)

# Password hashing context using Bcrypt
pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")

# OAuth2 scheme declaration. The tokenUrl matches the login route we will define.
oauth2_scheme = OAuth2PasswordBearer(
    tokenUrl=f"{settings.API_V1_STR}/auth/login",
    scopes={
        "me": "Read information about the current user.",
        "admin": "Admin privileges for entire system.",
    },
    auto_error=False # Set to false to allow API key fallback
)


def verify_password(plain_password: str, hashed_password: str) -> bool:
    """
    Verifies that a plaintext password matches the hashed version.
    
    Args:
        plain_password (str): The password to check.
        hashed_password (str): The bcrypt hash from the database.
        
    Returns:
        bool: True if password matches, False otherwise.
    """
    try:
        return pwd_context.verify(plain_password, hashed_password)
    except Exception as e:
        logger.error(f"Error verifying password: {str(e)}")
        return False


def get_password_hash(password: str) -> str:
    """
    Generates a bcrypt hash for the provided password.
    
    Args:
        password (str): The plaintext password.
        
    Returns:
        str: The hashed password.
    """
    return pwd_context.hash(password)


def create_access_token(
    subject: Union[str, Any], 
    scopes: list[str] = [], 
    expires_delta: Optional[timedelta] = None
) -> str:
    """
    Creates a JWT access token containing the subject identity and scopes.
    
    Args:
        subject (str): Usually the user's email or UUID.
        scopes (list): List of permissions/scopes.
        expires_delta (timedelta): Custom expiration duration.
        
    Returns:
        str: The encoded JWT.
    """
    if expires_delta:
        expire = datetime.utcnow() + expires_delta
    else:
        expire = datetime.utcnow() + timedelta(minutes=settings.ACCESS_TOKEN_EXPIRE_MINUTES)
        
    to_encode = {
        "exp": expire,
        "sub": str(subject),
        "scopes": scopes,
        "type": "access"
    }
    encoded_jwt = jwt.encode(to_encode, settings.SECRET_KEY, algorithm=settings.ALGORITHM)
    return encoded_jwt


async def authenticate_user(
    db: AsyncSession, 
    email: str, 
    password: str
) -> Optional[User]:
    """
    Authenticates a user against the database.
    
    Args:
        db (AsyncSession): The database session.
        email (str): User's email.
        password (str): User's plaintext password.
        
    Returns:
        User object if successful, None otherwise.
    """
    stmt = select(User).where(User.email == email)
    result = await db.execute(stmt)
    user = result.scalar_one_or_none()
    
    if not user:
        return None
    if not verify_password(password, user.hashed_password):
        return None
    return user


async def get_current_user(
    security_scopes: SecurityScopes,
    request: Request,
    token: Optional[str] = Depends(oauth2_scheme),
    db: AsyncSession = Depends(get_db)
) -> User:
    """
    Dependency function to retrieve the current user.
    Supports both Bearer JWTs and custom X-API-Key headers.
    
    Args:
        security_scopes: Required scopes for the route.
        request: The raw FastAPI request.
        token: The extracted OAuth2 token (if present).
        db: Database session.
        
    Raises:
        HTTPException: If authentication fails or permissions are insufficient.
    """
    if security_scopes.scopes:
        authenticate_value = f'Bearer scope="{security_scopes.scope_str}"'
    else:
        authenticate_value = "Bearer"

    credentials_exception = HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="Could not validate credentials",
        headers={"WWW-Authenticate": authenticate_value},
    )

    # Check for API Key fallback first
    api_key_header = request.headers.get("X-API-Key")
    if api_key_header:
        stmt = select(APIKey).options(selectinload(APIKey.user)).where(APIKey.key == api_key_header)
        result = await db.execute(stmt)
        api_key_record = result.scalar_one_or_none()
        
        if not api_key_record or not api_key_record.is_valid():
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN, 
                detail="Invalid or expired API Key"
            )
        
        # Update last used
        api_key_record.last_used_at = datetime.utcnow()
        await db.commit()
        return api_key_record.user

    # Proceed with JWT validation if no API key
    if not token:
        raise credentials_exception

    try:
        payload = jwt.decode(token, settings.SECRET_KEY, algorithms=[settings.ALGORITHM])
        email: str = payload.get("sub")
        if email is None:
            raise credentials_exception
        token_scopes = payload.get("scopes", [])
        token_data = TokenData(scopes=token_scopes, email=email)
    except (JWTError, Exception) as e:
        logger.warning(f"JWT Validation error: {str(e)}")
        raise credentials_exception

    stmt = select(User).where(User.email == token_data.email)
    result = await db.execute(stmt)
    user = result.scalar_one_or_none()
    
    if user is None:
        raise credentials_exception

    # Check required scopes
    for scope in security_scopes.scopes:
        if scope not in token_data.scopes and not user.is_superuser:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Not enough permissions",
                headers={"WWW-Authenticate": authenticate_value},
            )

    return user


async def get_current_active_user(
    current_user: User = Depends(get_current_user),
) -> User:
    """Dependency that ensures the current user is active."""
    if not current_user.is_active:
        raise HTTPException(status_code=400, detail="Inactive user account")
    return current_user


async def get_current_superuser(
    current_user: User = Depends(get_current_active_user),
) -> User:
    """Dependency that ensures the current user has superuser privileges."""
    if not current_user.is_superuser:
        raise HTTPException(
            status_code=403, detail="The user doesn't have enough privileges"
        )
    return current_user
