// analytics.js (Analytics Dashboard with complex charting logic and robust layout)
import { Chart } from '../charts.js';

export default {
    render(app) {
        const div = document.createElement('div');
        div.className = 'analytics-view fade-in flex flex-col gap-6';
        
        div.innerHTML = `
            <!-- Top Controls -->
            <div class="flex justify-between items-center">
                <h3 class="text-xl font-bold">Analytics & Trends</h3>
                
                <div class="flex items-center gap-4">
                    <div class="bg-tertiary border border-primary rounded-lg flex p-1">
                        <button class="px-4 py-1 text-sm rounded bg-glass text-primary shadow">7D</button>
                        <button class="px-4 py-1 text-sm rounded text-muted hover:text-primary">30D</button>
                        <button class="px-4 py-1 text-sm rounded text-muted hover:text-primary">90D</button>
                        <button class="px-4 py-1 text-sm rounded text-muted hover:text-primary">YTD</button>
                    </div>
                    <button class="btn bg-tertiary border border-primary flex items-center gap-2">
                        <svg class="w-4 h-4"><use href="#icon-download"></use></svg>
                        Export Report
                    </button>
                </div>
            </div>

            <!-- KPI Summary Cards -->
            <div class="grid grid-cols-12 gap-6">
                <!-- Card 1 -->
                <div class="col-span-3 glass-panel p-6 rounded-xl relative overflow-hidden group">
                    <div class="absolute top-0 right-0 w-32 h-32 bg-cyan-500 opacity-5 rounded-full blur-3xl transform translate-x-10 -translate-y-10 group-hover:opacity-20 transition-opacity duration-500"></div>
                    <h4 class="text-sm font-medium text-secondary mb-1">Total Evaluations</h4>
                    <div class="text-3xl font-mono font-bold mb-2">12,458</div>
                    <div class="flex items-center gap-2 text-xs">
                        <span class="text-success flex items-center bg-success/10 px-1.5 py-0.5 rounded border border-success/20">
                            <svg class="w-3 h-3 mr-1" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="22 7 13.5 15.5 8.5 10.5 2 17"></polyline><polyline points="16 7 22 7 22 13"></polyline></svg>
                            +12.4%
                        </span>
                        <span class="text-muted">vs last period</span>
                    </div>
                </div>
                
                <!-- Card 2 -->
                <div class="col-span-3 glass-panel p-6 rounded-xl relative overflow-hidden group">
                    <div class="absolute top-0 right-0 w-32 h-32 bg-error opacity-5 rounded-full blur-3xl transform translate-x-10 -translate-y-10 group-hover:opacity-20 transition-opacity duration-500"></div>
                    <h4 class="text-sm font-medium text-secondary mb-1">Global Hallucination Rate</h4>
                    <div class="text-3xl font-mono font-bold text-error mb-2">8.4%</div>
                    <div class="flex items-center gap-2 text-xs">
                        <span class="text-success flex items-center bg-success/10 px-1.5 py-0.5 rounded border border-success/20">
                            <svg class="w-3 h-3 mr-1" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="22 17 13.5 8.5 8.5 13.5 2 7"></polyline><polyline points="16 17 22 17 22 11"></polyline></svg>
                            -2.1%
                        </span>
                        <span class="text-muted">vs last period</span>
                    </div>
                </div>

                <!-- Card 3 -->
                <div class="col-span-3 glass-panel p-6 rounded-xl relative overflow-hidden group">
                    <div class="absolute top-0 right-0 w-32 h-32 bg-purple opacity-5 rounded-full blur-3xl transform translate-x-10 -translate-y-10 group-hover:opacity-20 transition-opacity duration-500"></div>
                    <h4 class="text-sm font-medium text-secondary mb-1">Avg Detection Latency</h4>
                    <div class="text-3xl font-mono font-bold mb-2">1.2s</div>
                    <div class="flex items-center gap-2 text-xs">
                        <span class="text-warning flex items-center bg-warning/10 px-1.5 py-0.5 rounded border border-warning/20">
                            <svg class="w-3 h-3 mr-1" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="5" y1="12" x2="19" y2="12"></line></svg>
                            +0.1s
                        </span>
                        <span class="text-muted">vs last period</span>
                    </div>
                </div>

                <!-- Card 4 -->
                <div class="col-span-3 glass-panel p-6 rounded-xl relative overflow-hidden group">
                    <div class="absolute top-0 right-0 w-32 h-32 bg-info opacity-5 rounded-full blur-3xl transform translate-x-10 -translate-y-10 group-hover:opacity-20 transition-opacity duration-500"></div>
                    <h4 class="text-sm font-medium text-secondary mb-1">Models Monitored</h4>
                    <div class="text-3xl font-mono font-bold mb-2">6</div>
                    <div class="flex items-center gap-2 text-xs">
                        <span class="text-muted">Active across all endpoints</span>
                    </div>
                </div>
            </div>

            <!-- Main Charts Row 1 -->
            <div class="grid grid-cols-12 gap-6">
                <!-- Trend Line Chart -->
                <div class="col-span-8 glass-panel p-6 rounded-xl flex flex-col h-[450px]">
                    <div class="flex justify-between items-center mb-6">
                        <div>
                            <h4 class="font-bold">Evaluation Volume & Hallucination Rate</h4>
                            <p class="text-xs text-muted">Daily breakdown of total requests vs detected errors.</p>
                        </div>
                        <div class="flex gap-4 text-xs">
                            <div class="flex items-center gap-2"><div class="w-3 h-3 rounded bg-cyan/50 border border-cyan"></div> Volume</div>
                            <div class="flex items-center gap-2"><div class="w-3 h-3 rounded bg-error/50 border border-error"></div> Errors</div>
                        </div>
                    </div>
                    <div class="flex-1 relative w-full h-full">
                        <canvas id="trendChart"></canvas>
                    </div>
                </div>

                <!-- Radar Chart -->
                <div class="col-span-4 glass-panel p-6 rounded-xl flex flex-col h-[450px]">
                    <div class="mb-6">
                        <h4 class="font-bold">Model Performance Matrix</h4>
                        <p class="text-xs text-muted">Comparative breakdown across 5 dimensions.</p>
                    </div>
                    <div class="flex-1 relative w-full h-full flex justify-center items-center">
                        <canvas id="radarChart"></canvas>
                    </div>
                </div>
            </div>

            <!-- Main Charts Row 2 -->
            <div class="grid grid-cols-12 gap-6">
                <!-- Bar Chart -->
                <div class="col-span-6 glass-panel p-6 rounded-xl flex flex-col h-[400px]">
                    <div class="mb-6">
                        <h4 class="font-bold">Hallucination Rate by Model</h4>
                        <p class="text-xs text-muted">Percentage of queries flagged as hallucinations.</p>
                    </div>
                    <div class="flex-1 relative w-full h-full">
                        <canvas id="modelBarChart"></canvas>
                    </div>
                </div>

                <!-- Breakdown Custom Donut -->
                <div class="col-span-6 glass-panel p-6 rounded-xl flex flex-col h-[400px]">
                    <div class="mb-6">
                        <h4 class="font-bold">Error Typology Distribution</h4>
                        <p class="text-xs text-muted">Classification of detected hallucination types.</p>
                    </div>
                    
                    <div class="flex-1 flex items-center gap-8 px-4">
                        <!-- Custom CSS Donut (Since canvas might be overkill if we want rich HTML inside) -->
                        <div class="relative w-48 h-48 shrink-0">
                            <!-- Conic gradient for donut chart -->
                            <div class="w-full h-full rounded-full" style="background: conic-gradient(#ff1744 0% 42%, #ffea00 42% 70%, #00f0ff 70% 88%, #7b2ff7 88% 100%);"></div>
                            <!-- Inner circle to make it a donut -->
                            <div class="absolute inset-4 bg-secondary rounded-full flex flex-col items-center justify-center border border-primary shadow-inner">
                                <span class="text-2xl font-mono font-bold">1,046</span>
                                <span class="text-xs text-muted uppercase">Errors</span>
                            </div>
                        </div>
                        
                        <!-- Legend and Progress Bars -->
                        <div class="flex-1 flex flex-col justify-center gap-4">
                            <!-- Item 1 -->
                            <div>
                                <div class="flex justify-between text-sm mb-1">
                                    <div class="flex items-center gap-2"><div class="w-2.5 h-2.5 rounded-full bg-error"></div>Factual Inconsistency</div>
                                    <span class="font-mono">42%</span>
                                </div>
                                <div class="w-full h-1.5 bg-tertiary rounded-full overflow-hidden">
                                    <div class="h-full bg-error w-[42%]"></div>
                                </div>
                            </div>
                            <!-- Item 2 -->
                            <div>
                                <div class="flex justify-between text-sm mb-1">
                                    <div class="flex items-center gap-2"><div class="w-2.5 h-2.5 rounded-full bg-warning"></div>Logical Flaw</div>
                                    <span class="font-mono">28%</span>
                                </div>
                                <div class="w-full h-1.5 bg-tertiary rounded-full overflow-hidden">
                                    <div class="h-full bg-warning w-[28%]"></div>
                                </div>
                            </div>
                            <!-- Item 3 -->
                            <div>
                                <div class="flex justify-between text-sm mb-1">
                                    <div class="flex items-center gap-2"><div class="w-2.5 h-2.5 rounded-full bg-cyan"></div>Fabricated Citation</div>
                                    <span class="font-mono">18%</span>
                                </div>
                                <div class="w-full h-1.5 bg-tertiary rounded-full overflow-hidden">
                                    <div class="h-full bg-cyan w-[18%]"></div>
                                </div>
                            </div>
                            <!-- Item 4 -->
                            <div>
                                <div class="flex justify-between text-sm mb-1">
                                    <div class="flex items-center gap-2"><div class="w-2.5 h-2.5 rounded-full bg-purple"></div>Nonsense/Formatting</div>
                                    <span class="font-mono">12%</span>
                                </div>
                                <div class="w-full h-1.5 bg-tertiary rounded-full overflow-hidden">
                                    <div class="h-full bg-purple w-[12%]"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        `;
        return div;
    },

    init(app) {
        // Wrap chart initialization in setTimeout to ensure DOM is fully painted
        // and canvas bounding rects are correct.
        setTimeout(() => {
            this.initCharts();
        }, 150);
    },

    initCharts() {
        const trendCanvas = document.getElementById('trendChart');
        if (trendCanvas) {
            new Chart(trendCanvas, {
                type: 'line',
                data: {
                    labels: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'],
                    datasets: [{
                        label: 'Volume',
                        data: [1200, 1900, 1500, 2200, 2800, 1400, 1100],
                        borderColor: '#00f0ff',
                        backgroundColor: 'rgba(0, 240, 255, 0.2)'
                    }]
                }
            });
        }

        const radarCanvas = document.getElementById('radarChart');
        if (radarCanvas) {
            new Chart(radarCanvas, {
                type: 'radar',
                data: {
                    labels: ['Factual Accuracy', 'Logical Coherence', 'Citation Validity', 'Format Adherence', 'Instruction Following'],
                    datasets: [{
                        label: 'GPT-4o',
                        data: [95, 98, 92, 99, 97],
                        borderColor: '#00f0ff',
                        backgroundColor: 'rgba(0, 240, 255, 0.2)'
                    }]
                }
            });
        }

        const barCanvas = document.getElementById('modelBarChart');
        if (barCanvas) {
            new Chart(barCanvas, {
                type: 'bar',
                data: {
                    labels: ['GPT-4o', 'Claude 3 Opus', 'Gemini 1.5', 'Llama 3 70B', 'Mistral Large'],
                    datasets: [{
                        label: 'Error Rate (%)',
                        data: [2.1, 2.5, 4.8, 7.2, 8.5],
                        borderColor: '#7b2ff7',
                        backgroundColor: 'rgba(123, 47, 247, 0.5)'
                    }]
                }
            });
        }
    }
}
