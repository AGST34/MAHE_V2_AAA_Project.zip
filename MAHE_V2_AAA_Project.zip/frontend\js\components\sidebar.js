// sidebar.js (Collapsible, responsive sidebar)
export function initSidebar(app) {
    const sidebar = app.ui.sidebar;
    const toggleBtn = app.ui.sidebarToggle;
    const mobileToggle = app.ui.mobileToggle;
    
    // Subscribe to store changes to reflect UI state
    window.store.subscribe((state) => {
        if (state.ui.sidebarCollapsed) {
            sidebar.classList.add('collapsed');
            if (toggleBtn) {
                toggleBtn.querySelector('svg').style.transform = 'rotate(0deg)';
            }
        } else {
            sidebar.classList.remove('collapsed');
            if (toggleBtn) {
                toggleBtn.querySelector('svg').style.transform = 'rotate(180deg)';
            }
        }
        
        // Render menu based on active view
        renderMenu(state.ui.activeView);
    });

    // Handle mobile overlay
    if (mobileToggle) {
        mobileToggle.addEventListener('click', () => {
            sidebar.classList.toggle('mobile-open');
            // Create backdrop if not exists
            let backdrop = document.getElementById('mobile-sidebar-backdrop');
            if (!backdrop) {
                backdrop = document.createElement('div');
                backdrop.id = 'mobile-sidebar-backdrop';
                backdrop.className = 'fixed inset-0 bg-black/60 backdrop-blur-sm z-30 lg:hidden transition-opacity opacity-0';
                document.body.appendChild(backdrop);
                
                backdrop.addEventListener('click', () => {
                    sidebar.classList.remove('mobile-open');
                    backdrop.classList.replace('opacity-100', 'opacity-0');
                    setTimeout(() => backdrop.remove(), 300);
                });
            }
            
            if (sidebar.classList.contains('mobile-open')) {
                // Request animation frame to ensure transition plays
                requestAnimationFrame(() => {
                    backdrop.classList.replace('opacity-0', 'opacity-100');
                });
            } else {
                backdrop.classList.replace('opacity-100', 'opacity-0');
                setTimeout(() => backdrop.remove(), 300);
            }
        });
    }

    function renderMenu(activeView) {
        const list = document.getElementById('sidebar-menu-list');
        if (!list) return;

        const navItems = [
            { id: 'dashboard', icon: 'icon-dashboard', label: 'Dashboard' },
            { id: 'evaluate', icon: 'icon-evaluate', label: 'Evaluate Evaluator' },
            { id: 'compare', icon: 'icon-compare', label: 'A/B Comparison' },
            { id: 'history', icon: 'icon-history', label: 'Ledger History' },
            { id: 'analytics', icon: 'icon-analytics', label: 'Analytics Pro' },
            { id: 'settings', icon: 'icon-settings', label: 'Configuration', bottom: true }
        ];

        let html = '';
        navItems.forEach(item => {
            const isActive = activeView === item.id;
            const liClass = item.bottom ? 'mt-auto' : '';
            const activeClass = isActive ? 'active' : '';
            
            html += `
                <li class="nav-item ${liClass}">
                    <a href="#/${item.id}" class="nav-link ${activeClass} relative overflow-hidden group" data-view="${item.id}">
                        ${isActive ? '<div class="absolute left-0 top-0 h-full w-1 bg-cyan shadow-[0_0_10px_#00f0ff]"></div>' : ''}
                        <svg class="icon group-hover:scale-110 transition-transform"><use href="#${item.icon}"></use></svg>
                        <span class="label transition-opacity duration-300 ${window.store.getState().ui.sidebarCollapsed ? 'opacity-0 w-0' : 'opacity-100'}">${item.label}</span>
                        ${item.id === 'evaluate' && !window.store.getState().ui.sidebarCollapsed ? '<span class="badge bg-cyan text-black border-none ml-auto text-[10px] px-1.5 py-0.5 rounded shadow-[0_0_5px_#00f0ff]">NEW</span>' : ''}
                    </a>
                </li>
            `;
        });
        
        // Only update if changed to prevent DOM thrashing
        if (list.innerHTML !== html) {
            list.innerHTML = html;
        }
        
        // Add mobile close logic to links
        list.querySelectorAll('a').forEach(link => {
            link.addEventListener('click', () => {
                if (window.innerWidth < 1024) {
                    sidebar.classList.remove('mobile-open');
                    const backdrop = document.getElementById('mobile-sidebar-backdrop');
                    if(backdrop) {
                        backdrop.classList.replace('opacity-100', 'opacity-0');
                        setTimeout(() => backdrop.remove(), 300);
                    }
                }
            });
        });
    }
    
    // Initial Render
    renderMenu(window.store.getState().ui.activeView);
}
