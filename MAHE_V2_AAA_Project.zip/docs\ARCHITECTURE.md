# Architecture Overview

## 1. System Overview
MAHE V2 uses a multi-agent DAG to process requests asynchronously. It consists of multiple independent agents evaluating text concurrently.

## 2. Component Diagram
```mermaid
graph LR
  A --> B
```

## 3. Data Flow
Requests enter via FastAPI, are authenticated, and pushed to the evaluation queue.

## 4. Agent Hierarchy
- **Factual Agent**
- **Context Agent**
- **Logical Agent**

## 5. Evaluation Stages
- Pre-processing
- Parallel Agent Execution
- Consensus & Scoring
- Post-processing

## 6. Caching Strategy
Redis is used for caching responses and intermediate states.

## 7. Error Handling
Tenacity is used for retries. HTTP errors are mapped to specific API responses.

## 8. Security Model
API Keys, JWT, and rate limiting.

## 9. Scaling Considerations
Horizontal scaling of agent workers.

### Detailed Agent Architecture Section 0
The agent processes data by loading the context window and comparing it against ground truth facts. In scenario 0, the evaluation matrix resolves conflicts using a weighted voting system.

### Detailed Agent Architecture Section 1
The agent processes data by loading the context window and comparing it against ground truth facts. In scenario 1, the evaluation matrix resolves conflicts using a weighted voting system.

### Detailed Agent Architecture Section 2
The agent processes data by loading the context window and comparing it against ground truth facts. In scenario 2, the evaluation matrix resolves conflicts using a weighted voting system.

### Detailed Agent Architecture Section 3
The agent processes data by loading the context window and comparing it against ground truth facts. In scenario 3, the evaluation matrix resolves conflicts using a weighted voting system.

### Detailed Agent Architecture Section 4
The agent processes data by loading the context window and comparing it against ground truth facts. In scenario 4, the evaluation matrix resolves conflicts using a weighted voting system.

### Detailed Agent Architecture Section 5
The agent processes data by loading the context window and comparing it against ground truth facts. In scenario 5, the evaluation matrix resolves conflicts using a weighted voting system.

### Detailed Agent Architecture Section 6
The agent processes data by loading the context window and comparing it against ground truth facts. In scenario 6, the evaluation matrix resolves conflicts using a weighted voting system.

### Detailed Agent Architecture Section 7
The agent processes data by loading the context window and comparing it against ground truth facts. In scenario 7, the evaluation matrix resolves conflicts using a weighted voting system.

### Detailed Agent Architecture Section 8
The agent processes data by loading the context window and comparing it against ground truth facts. In scenario 8, the evaluation matrix resolves conflicts using a weighted voting system.

### Detailed Agent Architecture Section 9
The agent processes data by loading the context window and comparing it against ground truth facts. In scenario 9, the evaluation matrix resolves conflicts using a weighted voting system.

### Detailed Agent Architecture Section 10
The agent processes data by loading the context window and comparing it against ground truth facts. In scenario 10, the evaluation matrix resolves conflicts using a weighted voting system.

### Detailed Agent Architecture Section 11
The agent processes data by loading the context window and comparing it against ground truth facts. In scenario 11, the evaluation matrix resolves conflicts using a weighted voting system.

### Detailed Agent Architecture Section 12
The agent processes data by loading the context window and comparing it against ground truth facts. In scenario 12, the evaluation matrix resolves conflicts using a weighted voting system.

### Detailed Agent Architecture Section 13
The agent processes data by loading the context window and comparing it against ground truth facts. In scenario 13, the evaluation matrix resolves conflicts using a weighted voting system.

### Detailed Agent Architecture Section 14
The agent processes data by loading the context window and comparing it against ground truth facts. In scenario 14, the evaluation matrix resolves conflicts using a weighted voting system.

### Detailed Agent Architecture Section 15
The agent processes data by loading the context window and comparing it against ground truth facts. In scenario 15, the evaluation matrix resolves conflicts using a weighted voting system.

### Detailed Agent Architecture Section 16
The agent processes data by loading the context window and comparing it against ground truth facts. In scenario 16, the evaluation matrix resolves conflicts using a weighted voting system.

### Detailed Agent Architecture Section 17
The agent processes data by loading the context window and comparing it against ground truth facts. In scenario 17, the evaluation matrix resolves conflicts using a weighted voting system.

### Detailed Agent Architecture Section 18
The agent processes data by loading the context window and comparing it against ground truth facts. In scenario 18, the evaluation matrix resolves conflicts using a weighted voting system.

### Detailed Agent Architecture Section 19
The agent processes data by loading the context window and comparing it against ground truth facts. In scenario 19, the evaluation matrix resolves conflicts using a weighted voting system.

### Detailed Agent Architecture Section 20
The agent processes data by loading the context window and comparing it against ground truth facts. In scenario 20, the evaluation matrix resolves conflicts using a weighted voting system.

### Detailed Agent Architecture Section 21
The agent processes data by loading the context window and comparing it against ground truth facts. In scenario 21, the evaluation matrix resolves conflicts using a weighted voting system.

### Detailed Agent Architecture Section 22
The agent processes data by loading the context window and comparing it against ground truth facts. In scenario 22, the evaluation matrix resolves conflicts using a weighted voting system.

### Detailed Agent Architecture Section 23
The agent processes data by loading the context window and comparing it against ground truth facts. In scenario 23, the evaluation matrix resolves conflicts using a weighted voting system.

### Detailed Agent Architecture Section 24
The agent processes data by loading the context window and comparing it against ground truth facts. In scenario 24, the evaluation matrix resolves conflicts using a weighted voting system.

### Detailed Agent Architecture Section 25
The agent processes data by loading the context window and comparing it against ground truth facts. In scenario 25, the evaluation matrix resolves conflicts using a weighted voting system.

### Detailed Agent Architecture Section 26
The agent processes data by loading the context window and comparing it against ground truth facts. In scenario 26, the evaluation matrix resolves conflicts using a weighted voting system.

### Detailed Agent Architecture Section 27
The agent processes data by loading the context window and comparing it against ground truth facts. In scenario 27, the evaluation matrix resolves conflicts using a weighted voting system.

### Detailed Agent Architecture Section 28
The agent processes data by loading the context window and comparing it against ground truth facts. In scenario 28, the evaluation matrix resolves conflicts using a weighted voting system.

### Detailed Agent Architecture Section 29
The agent processes data by loading the context window and comparing it against ground truth facts. In scenario 29, the evaluation matrix resolves conflicts using a weighted voting system.

### Detailed Agent Architecture Section 30
The agent processes data by loading the context window and comparing it against ground truth facts. In scenario 30, the evaluation matrix resolves conflicts using a weighted voting system.

### Detailed Agent Architecture Section 31
The agent processes data by loading the context window and comparing it against ground truth facts. In scenario 31, the evaluation matrix resolves conflicts using a weighted voting system.

### Detailed Agent Architecture Section 32
The agent processes data by loading the context window and comparing it against ground truth facts. In scenario 32, the evaluation matrix resolves conflicts using a weighted voting system.

### Detailed Agent Architecture Section 33
The agent processes data by loading the context window and comparing it against ground truth facts. In scenario 33, the evaluation matrix resolves conflicts using a weighted voting system.

### Detailed Agent Architecture Section 34
The agent processes data by loading the context window and comparing it against ground truth facts. In scenario 34, the evaluation matrix resolves conflicts using a weighted voting system.

### Detailed Agent Architecture Section 35
The agent processes data by loading the context window and comparing it against ground truth facts. In scenario 35, the evaluation matrix resolves conflicts using a weighted voting system.

### Detailed Agent Architecture Section 36
The agent processes data by loading the context window and comparing it against ground truth facts. In scenario 36, the evaluation matrix resolves conflicts using a weighted voting system.

### Detailed Agent Architecture Section 37
The agent processes data by loading the context window and comparing it against ground truth facts. In scenario 37, the evaluation matrix resolves conflicts using a weighted voting system.

### Detailed Agent Architecture Section 38
The agent processes data by loading the context window and comparing it against ground truth facts. In scenario 38, the evaluation matrix resolves conflicts using a weighted voting system.

### Detailed Agent Architecture Section 39
The agent processes data by loading the context window and comparing it against ground truth facts. In scenario 39, the evaluation matrix resolves conflicts using a weighted voting system.

### Detailed Agent Architecture Section 40
The agent processes data by loading the context window and comparing it against ground truth facts. In scenario 40, the evaluation matrix resolves conflicts using a weighted voting system.

### Detailed Agent Architecture Section 41
The agent processes data by loading the context window and comparing it against ground truth facts. In scenario 41, the evaluation matrix resolves conflicts using a weighted voting system.

### Detailed Agent Architecture Section 42
The agent processes data by loading the context window and comparing it against ground truth facts. In scenario 42, the evaluation matrix resolves conflicts using a weighted voting system.

### Detailed Agent Architecture Section 43
The agent processes data by loading the context window and comparing it against ground truth facts. In scenario 43, the evaluation matrix resolves conflicts using a weighted voting system.

### Detailed Agent Architecture Section 44
The agent processes data by loading the context window and comparing it against ground truth facts. In scenario 44, the evaluation matrix resolves conflicts using a weighted voting system.

### Detailed Agent Architecture Section 45
The agent processes data by loading the context window and comparing it against ground truth facts. In scenario 45, the evaluation matrix resolves conflicts using a weighted voting system.

### Detailed Agent Architecture Section 46
The agent processes data by loading the context window and comparing it against ground truth facts. In scenario 46, the evaluation matrix resolves conflicts using a weighted voting system.

### Detailed Agent Architecture Section 47
The agent processes data by loading the context window and comparing it against ground truth facts. In scenario 47, the evaluation matrix resolves conflicts using a weighted voting system.

### Detailed Agent Architecture Section 48
The agent processes data by loading the context window and comparing it against ground truth facts. In scenario 48, the evaluation matrix resolves conflicts using a weighted voting system.

### Detailed Agent Architecture Section 49
The agent processes data by loading the context window and comparing it against ground truth facts. In scenario 49, the evaluation matrix resolves conflicts using a weighted voting system.

### Detailed Agent Architecture Section 50
The agent processes data by loading the context window and comparing it against ground truth facts. In scenario 50, the evaluation matrix resolves conflicts using a weighted voting system.

### Detailed Agent Architecture Section 51
The agent processes data by loading the context window and comparing it against ground truth facts. In scenario 51, the evaluation matrix resolves conflicts using a weighted voting system.

### Detailed Agent Architecture Section 52
The agent processes data by loading the context window and comparing it against ground truth facts. In scenario 52, the evaluation matrix resolves conflicts using a weighted voting system.

### Detailed Agent Architecture Section 53
The agent processes data by loading the context window and comparing it against ground truth facts. In scenario 53, the evaluation matrix resolves conflicts using a weighted voting system.

### Detailed Agent Architecture Section 54
The agent processes data by loading the context window and comparing it against ground truth facts. In scenario 54, the evaluation matrix resolves conflicts using a weighted voting system.

### Detailed Agent Architecture Section 55
The agent processes data by loading the context window and comparing it against ground truth facts. In scenario 55, the evaluation matrix resolves conflicts using a weighted voting system.

### Detailed Agent Architecture Section 56
The agent processes data by loading the context window and comparing it against ground truth facts. In scenario 56, the evaluation matrix resolves conflicts using a weighted voting system.

### Detailed Agent Architecture Section 57
The agent processes data by loading the context window and comparing it against ground truth facts. In scenario 57, the evaluation matrix resolves conflicts using a weighted voting system.

### Detailed Agent Architecture Section 58
The agent processes data by loading the context window and comparing it against ground truth facts. In scenario 58, the evaluation matrix resolves conflicts using a weighted voting system.

### Detailed Agent Architecture Section 59
The agent processes data by loading the context window and comparing it against ground truth facts. In scenario 59, the evaluation matrix resolves conflicts using a weighted voting system.

### Detailed Agent Architecture Section 60
The agent processes data by loading the context window and comparing it against ground truth facts. In scenario 60, the evaluation matrix resolves conflicts using a weighted voting system.

### Detailed Agent Architecture Section 61
The agent processes data by loading the context window and comparing it against ground truth facts. In scenario 61, the evaluation matrix resolves conflicts using a weighted voting system.

### Detailed Agent Architecture Section 62
The agent processes data by loading the context window and comparing it against ground truth facts. In scenario 62, the evaluation matrix resolves conflicts using a weighted voting system.

### Detailed Agent Architecture Section 63
The agent processes data by loading the context window and comparing it against ground truth facts. In scenario 63, the evaluation matrix resolves conflicts using a weighted voting system.

### Detailed Agent Architecture Section 64
The agent processes data by loading the context window and comparing it against ground truth facts. In scenario 64, the evaluation matrix resolves conflicts using a weighted voting system.

### Detailed Agent Architecture Section 65
The agent processes data by loading the context window and comparing it against ground truth facts. In scenario 65, the evaluation matrix resolves conflicts using a weighted voting system.

### Detailed Agent Architecture Section 66
The agent processes data by loading the context window and comparing it against ground truth facts. In scenario 66, the evaluation matrix resolves conflicts using a weighted voting system.

### Detailed Agent Architecture Section 67
The agent processes data by loading the context window and comparing it against ground truth facts. In scenario 67, the evaluation matrix resolves conflicts using a weighted voting system.

### Detailed Agent Architecture Section 68
The agent processes data by loading the context window and comparing it against ground truth facts. In scenario 68, the evaluation matrix resolves conflicts using a weighted voting system.

### Detailed Agent Architecture Section 69
The agent processes data by loading the context window and comparing it against ground truth facts. In scenario 69, the evaluation matrix resolves conflicts using a weighted voting system.

### Detailed Agent Architecture Section 70
The agent processes data by loading the context window and comparing it against ground truth facts. In scenario 70, the evaluation matrix resolves conflicts using a weighted voting system.

### Detailed Agent Architecture Section 71
The agent processes data by loading the context window and comparing it against ground truth facts. In scenario 71, the evaluation matrix resolves conflicts using a weighted voting system.

### Detailed Agent Architecture Section 72
The agent processes data by loading the context window and comparing it against ground truth facts. In scenario 72, the evaluation matrix resolves conflicts using a weighted voting system.

### Detailed Agent Architecture Section 73
The agent processes data by loading the context window and comparing it against ground truth facts. In scenario 73, the evaluation matrix resolves conflicts using a weighted voting system.

### Detailed Agent Architecture Section 74
The agent processes data by loading the context window and comparing it against ground truth facts. In scenario 74, the evaluation matrix resolves conflicts using a weighted voting system.

### Detailed Agent Architecture Section 75
The agent processes data by loading the context window and comparing it against ground truth facts. In scenario 75, the evaluation matrix resolves conflicts using a weighted voting system.

### Detailed Agent Architecture Section 76
The agent processes data by loading the context window and comparing it against ground truth facts. In scenario 76, the evaluation matrix resolves conflicts using a weighted voting system.

### Detailed Agent Architecture Section 77
The agent processes data by loading the context window and comparing it against ground truth facts. In scenario 77, the evaluation matrix resolves conflicts using a weighted voting system.

### Detailed Agent Architecture Section 78
The agent processes data by loading the context window and comparing it against ground truth facts. In scenario 78, the evaluation matrix resolves conflicts using a weighted voting system.

### Detailed Agent Architecture Section 79
The agent processes data by loading the context window and comparing it against ground truth facts. In scenario 79, the evaluation matrix resolves conflicts using a weighted voting system.

### Detailed Agent Architecture Section 80
The agent processes data by loading the context window and comparing it against ground truth facts. In scenario 80, the evaluation matrix resolves conflicts using a weighted voting system.

### Detailed Agent Architecture Section 81
The agent processes data by loading the context window and comparing it against ground truth facts. In scenario 81, the evaluation matrix resolves conflicts using a weighted voting system.

### Detailed Agent Architecture Section 82
The agent processes data by loading the context window and comparing it against ground truth facts. In scenario 82, the evaluation matrix resolves conflicts using a weighted voting system.

### Detailed Agent Architecture Section 83
The agent processes data by loading the context window and comparing it against ground truth facts. In scenario 83, the evaluation matrix resolves conflicts using a weighted voting system.

### Detailed Agent Architecture Section 84
The agent processes data by loading the context window and comparing it against ground truth facts. In scenario 84, the evaluation matrix resolves conflicts using a weighted voting system.

### Detailed Agent Architecture Section 85
The agent processes data by loading the context window and comparing it against ground truth facts. In scenario 85, the evaluation matrix resolves conflicts using a weighted voting system.

### Detailed Agent Architecture Section 86
The agent processes data by loading the context window and comparing it against ground truth facts. In scenario 86, the evaluation matrix resolves conflicts using a weighted voting system.

### Detailed Agent Architecture Section 87
The agent processes data by loading the context window and comparing it against ground truth facts. In scenario 87, the evaluation matrix resolves conflicts using a weighted voting system.

### Detailed Agent Architecture Section 88
The agent processes data by loading the context window and comparing it against ground truth facts. In scenario 88, the evaluation matrix resolves conflicts using a weighted voting system.

### Detailed Agent Architecture Section 89
The agent processes data by loading the context window and comparing it against ground truth facts. In scenario 89, the evaluation matrix resolves conflicts using a weighted voting system.

### Detailed Agent Architecture Section 90
The agent processes data by loading the context window and comparing it against ground truth facts. In scenario 90, the evaluation matrix resolves conflicts using a weighted voting system.

### Detailed Agent Architecture Section 91
The agent processes data by loading the context window and comparing it against ground truth facts. In scenario 91, the evaluation matrix resolves conflicts using a weighted voting system.

### Detailed Agent Architecture Section 92
The agent processes data by loading the context window and comparing it against ground truth facts. In scenario 92, the evaluation matrix resolves conflicts using a weighted voting system.

### Detailed Agent Architecture Section 93
The agent processes data by loading the context window and comparing it against ground truth facts. In scenario 93, the evaluation matrix resolves conflicts using a weighted voting system.

### Detailed Agent Architecture Section 94
The agent processes data by loading the context window and comparing it against ground truth facts. In scenario 94, the evaluation matrix resolves conflicts using a weighted voting system.

### Detailed Agent Architecture Section 95
The agent processes data by loading the context window and comparing it against ground truth facts. In scenario 95, the evaluation matrix resolves conflicts using a weighted voting system.

### Detailed Agent Architecture Section 96
The agent processes data by loading the context window and comparing it against ground truth facts. In scenario 96, the evaluation matrix resolves conflicts using a weighted voting system.

### Detailed Agent Architecture Section 97
The agent processes data by loading the context window and comparing it against ground truth facts. In scenario 97, the evaluation matrix resolves conflicts using a weighted voting system.

### Detailed Agent Architecture Section 98
The agent processes data by loading the context window and comparing it against ground truth facts. In scenario 98, the evaluation matrix resolves conflicts using a weighted voting system.

### Detailed Agent Architecture Section 99
The agent processes data by loading the context window and comparing it against ground truth facts. In scenario 99, the evaluation matrix resolves conflicts using a weighted voting system.

