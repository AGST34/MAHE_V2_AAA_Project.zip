"""
Evaluations API Routes Module

Defines the endpoints for interacting with the evaluation engine.
Includes routes for single evaluation, batch processing, fetching history,
and live streaming via WebSockets.
"""

import asyncio
from typing import Any, Dict

from fastapi import APIRouter, Depends, HTTPException, BackgroundTasks, status, Query
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.future import select
from sqlalchemy.orm import selectinload

from backend.database import get_db
from backend.models import Evaluation, User
from backend.auth import get_current_user
from backend.schemas import (
    EvaluationRequest, 
    EvaluationResponse, 
    BatchEvaluationRequest,
    BatchEvaluationResponse,
    ErrorResponse
)
from backend.core.evaluator import EvaluationPipeline
from backend.utils.logger import get_logger

logger = get_logger(__name__)
router = APIRouter()


@router.post(
    "", 
    response_model=EvaluationResponse,
    status_code=status.HTTP_201_CREATED,
    summary="Run a single evaluation",
    responses={
        500: {"model": ErrorResponse, "description": "Internal server error during evaluation"},
        400: {"model": ErrorResponse, "description": "Validation error"}
    }
)
async def evaluate_single(
    request: EvaluationRequest, 
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user)
) -> Any:
    """
    Submits a single prompt and optional context for evaluation across multiple requested AI models.
    
    The backend will concurrently generate responses using the specified models, 
    evaluate them using the Judge Agent for hallucinations and coherence, 
    and return a consolidated report with scoring.
    """
    try:
        pipeline = EvaluationPipeline(db=db, current_user=current_user)
        result = await pipeline.run_single_evaluation(request)
        return result
    except Exception as e:
        logger.exception("Failed processing single evaluation request.")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Evaluation failed: {str(e)}"
        )


@router.post(
    "/batch", 
    response_model=BatchEvaluationResponse,
    status_code=status.HTTP_202_ACCEPTED,
    summary="Run multiple evaluations in batch mode"
)
async def evaluate_batch(
    request: BatchEvaluationRequest, 
    background_tasks: BackgroundTasks,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user)
) -> Any:
    """
    Submits a batch of evaluation requests to be processed asynchronously.
    Returns immediately with a batch ID. The actual processing occurs in the background.
    """
    # In a full production setup, this would dispatch to a Celery/Redis queue.
    # For this implementation, we use FastAPI's BackgroundTasks.
    
    pipeline = EvaluationPipeline(db=db, current_user=current_user)
    
    # Fire and forget
    background_tasks.add_task(pipeline.run_batch_evaluation, request)
    
    return BatchEvaluationResponse(
        batch_id=f"batch_{int(asyncio.get_event_loop().time())}",
        status="accepted",
        evaluation_count=len(request.evaluations)
    )


@router.get(
    "/{eval_id}", 
    response_model=EvaluationResponse,
    summary="Get details of a specific evaluation"
)
async def get_evaluation(
    eval_id: str, 
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user)
) -> Any:
    """
    Retrieves the complete details and results of a previously executed evaluation.
    Users can only access their own evaluations unless they are a superuser.
    """
    stmt = select(Evaluation).options(selectinload(Evaluation.results)).where(Evaluation.id == eval_id)
    result = await db.execute(stmt)
    evaluation = result.scalar_one_or_none()
    
    if not evaluation:
        raise HTTPException(status_code=404, detail="Evaluation not found")
        
    # Security check
    if not current_user.is_superuser and evaluation.user_id != current_user.id:
        raise HTTPException(status_code=403, detail="Not authorized to access this evaluation")
        
    return EvaluationResponse.model_validate(evaluation)


@router.get(
    "/{eval_id}/compare", 
    summary="Get comparative analysis for an evaluation"
)
async def compare_evaluation_results(
    eval_id: str,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user)
) -> Dict[str, Any]:
    """
    Generates a comparative analysis for a specific evaluation, returning rankings
    and identifying the model that performed best (lowest hallucination, highest coherence).
    """
    # Verify access first
    stmt = select(Evaluation).where(Evaluation.id == eval_id)
    result = await db.execute(stmt)
    evaluation = result.scalar_one_or_none()
    
    if not evaluation:
        raise HTTPException(status_code=404, detail="Evaluation not found")
    if not current_user.is_superuser and evaluation.user_id != current_user.id:
        raise HTTPException(status_code=403, detail="Not authorized to access this evaluation")

    pipeline = EvaluationPipeline(db=db, current_user=current_user)
    analysis = await pipeline.run_comparative_analysis(eval_id)
    return analysis
