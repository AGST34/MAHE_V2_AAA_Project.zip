"""
Main Application Entrypoint

This module bootstraps the FastAPI application. It wires together the configuration,
middleware, static files, lifecycle events, global exception handlers, and all API routers.
It is the entry point for Uvicorn/Gunicorn.
"""

import logging
from contextlib import asynccontextmanager

from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from fastapi.staticfiles import StaticFiles
from fastapi.openapi.utils import get_openapi

from backend.api.router import api_router
from backend.config import settings
from backend.middleware import setup_middlewares
from backend.database import check_database_health

logger = logging.getLogger(__name__)

# ==========================================
# Lifecycle Management
# ==========================================

@asynccontextmanager
async def lifespan(app: FastAPI):
    """
    Lifespan context manager to handle application startup and shutdown events.
    Useful for initializing ML models, database connections, or cache pools.
    """
    logger.info(f"Starting up {settings.PROJECT_NAME} Environment: {settings.ENVIRONMENT}")
    
    # Perform database connectivity check
    db_ok = await check_database_health()
    if not db_ok:
        logger.error("WARNING: Initial database health check failed. Application may not function correctly.")
    else:
        logger.info("Database connection verified successfully.")
        
    # Simulate loading large items (e.g. tokenizer, embedding model)
    logger.info("Initializing evaluation pipelines...")
    
    yield  # Application is now handling requests
    
    logger.info(f"Shutting down {settings.PROJECT_NAME}...")
    # Perform cleanup (close DB pools, clear caches, etc.)
    logger.info("Cleanup completed successfully.")


# ==========================================
# Application Setup
# ==========================================

app = FastAPI(
    title=settings.PROJECT_NAME,
    description=settings.DESCRIPTION,
    version=settings.VERSION,
    lifespan=lifespan,
    docs_url="/docs",
    redoc_url="/redoc",
    openapi_url="/openapi.json",
)


# ==========================================
# Custom OpenAPI Schema
# ==========================================

def custom_openapi():
    """Enhances the generated OpenAPI schema with additional metadata."""
    if app.openapi_schema:
        return app.openapi_schema
    openapi_schema = get_openapi(
        title=settings.PROJECT_NAME,
        version=settings.VERSION,
        description=settings.DESCRIPTION,
        routes=app.routes,
    )
    # Custom tags metadata or extensions can go here
    app.openapi_schema = openapi_schema
    return app.openapi_schema

app.openapi = custom_openapi


# ==========================================
# Middleware Configuration
# ==========================================

# Apply custom middlewares (Timing, Correlation ID, Rate Limiter)
setup_middlewares(app)

# Apply CORS Middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.BACKEND_CORS_ORIGINS,
    allow_credentials=True,
    allow_methods=["GET", "POST", "PUT", "DELETE", "OPTIONS", "PATCH"],
    allow_headers=["*"],
    expose_headers=["X-Correlation-ID", "X-Process-Time"]
)


# ==========================================
# Global Exception Handlers
# ==========================================

@app.exception_handler(ValueError)
async def value_error_handler(request: Request, exc: ValueError):
    """Globally catch ValueErrors and convert to 400 Bad Request."""
    logger.error(f"ValueError: {exc}")
    return JSONResponse(
        status_code=400,
        content={"detail": str(exc), "code": "VALIDATION_ERROR"},
    )


# ==========================================
# Routers and Static Files
# ==========================================

# Include the main API router under the configured prefix (e.g., /api/v1)
app.include_router(api_router, prefix=settings.API_V1_STR)

# Optional static file mount for frontend hosting (uncomment in production if needed)
# import os
# static_dir = os.path.join(os.path.dirname(__file__), "..", "static")
# if os.path.exists(static_dir):
#     app.mount("/static", StaticFiles(directory=static_dir), name="static")


# ==========================================
# Root Routes
# ==========================================

@app.get("/", tags=["system"])
async def root():
    """Root endpoint verifying application is running."""
    return {
        "app": settings.PROJECT_NAME,
        "version": settings.VERSION,
        "environment": settings.ENVIRONMENT,
        "status": "online"
    }

@app.get("/health", tags=["system"])
async def health_check():
    """Deep health check endpoint."""
    db_ok = await check_database_health()
    return {
        "status": "healthy" if db_ok else "unhealthy",
        "database": "connected" if db_ok else "disconnected",
        "timestamp": "2026-09-24T00:00:00Z"
    }
