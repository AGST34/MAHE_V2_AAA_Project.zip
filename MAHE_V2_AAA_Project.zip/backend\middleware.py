"""
FastAPI Middleware Module

Contains various middleware classes and functions for request processing:
- Timing Middleware: Measures request duration.
- Correlation ID Middleware: Attaches a unique ID to each request for logging.
- Request Logging Middleware: Logs incoming requests and outgoing responses.
- Basic Rate Limiting: Limits incoming requests based on IP.
- Exception Handling: Global catch-all for unhandled exceptions to prevent server crashes.
"""

import time
import uuid
import logging
from typing import Callable, Awaitable
from collections import defaultdict
from datetime import datetime, timedelta

from fastapi import Request, Response
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.responses import JSONResponse

from backend.utils.logger import set_correlation_id

logger = logging.getLogger(__name__)

# Basic In-Memory Rate Limiter State (In prod, use Redis)
RATE_LIMIT_STORE = defaultdict(list)


class CorrelationIdMiddleware(BaseHTTPMiddleware):
    """
    Middleware that generates and injects a Correlation ID into the request.
    This ID is used across the system for distributed tracing and logging.
    """
    async def dispatch(self, request: Request, call_next: Callable[[Request], Awaitable[Response]]) -> Response:
        # Check if client sent an ID, otherwise generate one
        corr_id = request.headers.get("X-Correlation-ID", str(uuid.uuid4()))
        
        # Set it in context variable for the logger
        set_correlation_id(corr_id)
        
        # Also attach to request state for other parts of the app
        request.state.correlation_id = corr_id
        
        response = await call_next(request)
        
        # Ensure the response has the correlation ID header
        response.headers["X-Correlation-ID"] = corr_id
        return response


class TimingAndLoggingMiddleware(BaseHTTPMiddleware):
    """
    Middleware to log the start and end of requests along with timing metrics.
    """
    async def dispatch(self, request: Request, call_next: Callable[[Request], Awaitable[Response]]) -> Response:
        start_time = time.time()
        client_ip = request.client.host if request.client else "unknown"
        method = request.method
        url = str(request.url.path)
        
        logger.info(f"Incoming request: {method} {url} from IP: {client_ip}")
        
        try:
            response = await call_next(request)
            process_time = time.time() - start_time
            response.headers["X-Process-Time"] = str(process_time)
            
            logger.info(
                f"Completed request: {method} {url} "
                f"Status: {response.status_code} "
                f"Duration: {process_time:.4f}s"
            )
            return response
            
        except Exception as exc:
            process_time = time.time() - start_time
            logger.exception(
                f"Failed request: {method} {url} "
                f"Duration: {process_time:.4f}s "
                f"Error: {str(exc)}"
            )
            # Global Exception Handler fallback
            return JSONResponse(
                status_code=500,
                content={
                    "detail": "Internal server error", 
                    "message": "An unexpected error occurred. Please contact support.",
                    "correlation_id": getattr(request.state, 'correlation_id', 'unknown')
                }
            )


class SimpleRateLimiterMiddleware(BaseHTTPMiddleware):
    """
    A basic in-memory rate limiter to protect endpoints from abuse.
    Checks the IP address and allows a specific number of requests per minute.
    """
    def __init__(self, app, max_requests: int = 60, window_seconds: int = 60):
        super().__init__(app)
        self.max_requests = max_requests
        self.window_seconds = window_seconds

    async def dispatch(self, request: Request, call_next: Callable[[Request], Awaitable[Response]]) -> Response:
        # Skip rate limiting for static/docs routes if needed
        if request.url.path.startswith(("/docs", "/openapi.json", "/health")):
            return await call_next(request)
            
        client_ip = request.client.host if request.client else "127.0.0.1"
        now = datetime.utcnow()
        
        # Clean up old timestamps
        RATE_LIMIT_STORE[client_ip] = [
            t for t in RATE_LIMIT_STORE[client_ip] 
            if t > now - timedelta(seconds=self.window_seconds)
        ]
        
        if len(RATE_LIMIT_STORE[client_ip]) >= self.max_requests:
            logger.warning(f"Rate limit exceeded for IP: {client_ip}")
            return JSONResponse(
                status_code=429,
                content={"detail": "Too many requests. Please try again later."},
                headers={"Retry-After": str(self.window_seconds)}
            )
            
        RATE_LIMIT_STORE[client_ip].append(now)
        return await call_next(request)


def setup_middlewares(app):
    """Utility function to apply all middlewares in correct order."""
    from backend.config import settings
    
    # Applied bottom-up (first added is outermost)
    app.add_middleware(
        SimpleRateLimiterMiddleware, 
        max_requests=settings.RATE_LIMIT_PER_MINUTE, 
        window_seconds=60
    )
    app.add_middleware(TimingAndLoggingMiddleware)
    app.add_middleware(CorrelationIdMiddleware)
