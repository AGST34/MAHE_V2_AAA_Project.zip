// compare.js (Expanded Compare Models View)
export default {
    render(app) {
        const div = document.createElement('div');
        div.className = 'compare-view flex flex-col gap-6 fade-in h-full min-h-[800px]';
        
        div.innerHTML = `
            <div class="glass-panel p-6 rounded-xl relative overflow-hidden flex-shrink-0">
                <div class="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-purple-500 to-cyan-500"></div>
                <h3 class="text-xl font-bold mb-4 flex items-center gap-2">
                    <svg class="w-6 h-6 text-purple"><use href="#icon-compare"></use></svg>
                    A/B Model Comparison
                </h3>
                
                <form id="compare-form" class="flex flex-col md:flex-row gap-4 items-start">
                    <div class="flex-1 w-full">
                        <label class="block text-sm font-semibold text-secondary mb-2">Comparison Prompt</label>
                        <textarea id="compare-prompt" class="w-full bg-tertiary border border-primary rounded-lg p-3 text-primary font-mono text-sm focus:border-purple focus:ring-1 focus:ring-purple resize-none h-20" placeholder="Enter a prompt to run simultaneously across models..."></textarea>
                    </div>
                    
                    <button type="submit" id="btn-run-compare" class="md:mt-7 w-full md:w-auto bg-gradient-to-r from-purple-600 to-cyan-600 hover:from-purple-500 hover:to-cyan-500 text-white font-bold py-3 px-8 rounded-lg shadow-lg hover:shadow-purple-glow transition-all flex items-center justify-center gap-2 h-20">
                        <svg class="w-5 h-5"><use href="#icon-play"></use></svg>
                        <span>Run Fight</span>
                    </button>
                </form>
            </div>
            
            <div class="grid grid-cols-2 gap-6 flex-1 h-full">
                <!-- Model 1 Container -->
                <div class="glass-panel rounded-xl flex flex-col overflow-hidden border-cyan/30 shadow-cyan-glow relative">
                    <div class="bg-cyan/10 px-4 py-3 border-b border-cyan/20 flex justify-between items-center z-10">
                        <div class="flex items-center gap-3">
                            <span class="text-xl font-black text-cyan">A</span>
                            <select id="compare-model-1" class="bg-tertiary border border-primary rounded px-3 py-1 text-sm font-semibold text-primary focus:border-cyan appearance-none cursor-pointer">
                                <option value="gpt-4o" selected>GPT-4o</option>
                                <option value="claude-3">Claude 3 Opus</option>
                                <option value="gemini-1.5">Gemini 1.5 Pro</option>
                                <option value="llama-3">Llama 3 70B</option>
                            </select>
                        </div>
                        <div id="status-1" class="badge bg-tertiary text-muted border border-primary">Waiting</div>
                    </div>
                    
                    <div class="flex-1 p-6 flex flex-col relative overflow-hidden bg-primary/50">
                        <!-- Empty State -->
                        <div id="empty-1" class="absolute inset-0 flex items-center justify-center text-muted flex-col opacity-50 z-0">
                            <svg class="w-16 h-16 mb-4"><use href="#icon-dashboard"></use></svg>
                            <p>Select model and run fight</p>
                        </div>
                        
                        <!-- Loading State -->
                        <div id="loading-1" class="absolute inset-0 flex items-center justify-center hidden bg-primary z-10">
                            <div class="flex flex-col items-center">
                                <div class="spinner lg mb-4"></div>
                                <div class="text-cyan font-mono text-sm tracking-widest animate-pulse">GENERATING...</div>
                            </div>
                        </div>
                        
                        <!-- Content State -->
                        <div id="content-1" class="hidden relative z-20 flex-1 flex flex-col h-full">
                            <div class="flex-1 overflow-y-auto pr-2 custom-scrollbar text-sm text-secondary leading-relaxed space-y-4 font-mono whitespace-pre-wrap" id="response-1"></div>
                            
                            <div class="mt-4 pt-4 border-t border-primary">
                                <div class="text-xs text-muted uppercase tracking-widest mb-2">Performance Metrics</div>
                                <div class="grid grid-cols-3 gap-2">
                                    <div class="bg-tertiary p-2 rounded text-center">
                                        <div class="text-[10px] text-muted uppercase">Latency</div>
                                        <div class="font-mono text-sm font-bold text-primary">1.24s</div>
                                    </div>
                                    <div class="bg-tertiary p-2 rounded text-center">
                                        <div class="text-[10px] text-muted uppercase">Speed</div>
                                        <div class="font-mono text-sm font-bold text-primary">68 t/s</div>
                                    </div>
                                    <div class="bg-tertiary p-2 rounded text-center">
                                        <div class="text-[10px] text-muted uppercase">Factuality</div>
                                        <div class="font-mono text-sm font-bold text-success">1.0</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Model 2 Container -->
                <div class="glass-panel rounded-xl flex flex-col overflow-hidden border-purple/30 shadow-purple-glow relative">
                    <div class="bg-purple/10 px-4 py-3 border-b border-purple/20 flex justify-between items-center z-10">
                        <div class="flex items-center gap-3">
                            <span class="text-xl font-black text-purple">B</span>
                            <select id="compare-model-2" class="bg-tertiary border border-primary rounded px-3 py-1 text-sm font-semibold text-primary focus:border-purple appearance-none cursor-pointer">
                                <option value="gpt-4o">GPT-4o</option>
                                <option value="claude-3" selected>Claude 3 Opus</option>
                                <option value="gemini-1.5">Gemini 1.5 Pro</option>
                                <option value="llama-3">Llama 3 70B</option>
                            </select>
                        </div>
                        <div id="status-2" class="badge bg-tertiary text-muted border border-primary">Waiting</div>
                    </div>
                    
                    <div class="flex-1 p-6 flex flex-col relative overflow-hidden bg-primary/50">
                        <!-- Empty State -->
                        <div id="empty-2" class="absolute inset-0 flex items-center justify-center text-muted flex-col opacity-50 z-0">
                            <svg class="w-16 h-16 mb-4"><use href="#icon-dashboard"></use></svg>
                            <p>Select model and run fight</p>
                        </div>
                        
                        <!-- Loading State -->
                        <div id="loading-2" class="absolute inset-0 flex items-center justify-center hidden bg-primary z-10">
                            <div class="flex flex-col items-center">
                                <div class="spinner lg purple mb-4"></div>
                                <div class="text-purple font-mono text-sm tracking-widest animate-pulse">GENERATING...</div>
                            </div>
                        </div>
                        
                        <!-- Content State -->
                        <div id="content-2" class="hidden relative z-20 flex-1 flex flex-col h-full">
                            <div class="flex-1 overflow-y-auto pr-2 custom-scrollbar text-sm text-secondary leading-relaxed space-y-4 font-mono whitespace-pre-wrap" id="response-2"></div>
                            
                            <div class="mt-4 pt-4 border-t border-primary">
                                <div class="text-xs text-muted uppercase tracking-widest mb-2">Performance Metrics</div>
                                <div class="grid grid-cols-3 gap-2">
                                    <div class="bg-tertiary p-2 rounded text-center">
                                        <div class="text-[10px] text-muted uppercase">Latency</div>
                                        <div class="font-mono text-sm font-bold text-primary">2.1s</div>
                                    </div>
                                    <div class="bg-tertiary p-2 rounded text-center">
                                        <div class="text-[10px] text-muted uppercase">Speed</div>
                                        <div class="font-mono text-sm font-bold text-primary">42 t/s</div>
                                    </div>
                                    <div class="bg-tertiary p-2 rounded text-center">
                                        <div class="text-[10px] text-muted uppercase">Factuality</div>
                                        <div class="font-mono text-sm font-bold text-error">0.4</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        `;
        return div;
    },

    init(app) {
        this.app = app;
        
        const form = document.getElementById('compare-form');
        if(form) {
            form.addEventListener('submit', (e) => {
                e.preventDefault();
                this.runComparison();
            });
        }
    },
    
    async runComparison() {
        const prompt = document.getElementById('compare-prompt').value;
        if(!prompt.trim()) {
            this.app.toast.error('Please enter a comparison prompt');
            return;
        }

        const m1 = document.getElementById('compare-model-1').value;
        const m2 = document.getElementById('compare-model-2').value;

        if (m1 === m2) {
            this.app.toast.warning('Comparing the exact same models. Results may vary slightly due to temperature.');
        }

        // Setup UI
        const btn = document.getElementById('btn-run-compare');
        btn.disabled = true;
        btn.innerHTML = `<div class="spinner sm white mr-2"></div> Processing...`;
        
        ['1', '2'].forEach(id => {
            document.getElementById(`empty-${id}`).classList.add('hidden');
            document.getElementById(`content-${id}`).classList.add('hidden');
            document.getElementById(`loading-${id}`).classList.remove('hidden');
            document.getElementById(`status-${id}`).className = 'badge bg-cyan/20 text-cyan border border-cyan/30';
            document.getElementById(`status-${id}`).textContent = 'Generating';
        });

        // Simulate network
        await new Promise(r => setTimeout(r, 2000));
        
        // Render 1
        document.getElementById('loading-1').classList.add('hidden');
        document.getElementById('content-1').classList.remove('hidden');
        document.getElementById('status-1').className = 'badge badge-success';
        document.getElementById('status-1').innerHTML = '<svg class="w-3 h-3 inline mr-1"><use href="#icon-check"></use></svg>Clean';
        document.getElementById('response-1').innerHTML = `To implement a binary search tree in Python, you define a Node class with 'left', 'right', and 'val' attributes. Then, you create a BST class that handles the insertion logic, ensuring values less than the current node go left, and greater values go right.`;
        
        // Render 2
        await new Promise(r => setTimeout(r, 800)); // model 2 is slower
        document.getElementById('loading-2').classList.add('hidden');
        document.getElementById('content-2').classList.remove('hidden');
        document.getElementById('status-2').className = 'badge badge-error';
        document.getElementById('status-2').innerHTML = '<svg class="w-3 h-3 inline mr-1"><use href="#icon-alert"></use></svg>Hallucination';
        document.getElementById('response-2').innerHTML = `To implement a binary search tree in Python, you can use the built-in <span class="bg-error/20 border-b border-error text-white">bst library (import bst)</span> which provides an optimized C-level implementation. Alternatively, you can use the <span class="bg-warning/20 border-b border-warning text-white">collections.BinaryTree</span> class introduced in Python 3.9.`;

        // Reset btn
        btn.disabled = false;
        btn.innerHTML = `<svg class="w-5 h-5"><use href="#icon-play"></use></svg><span>Run Fight</span>`;
        this.app.toast.success('Comparison complete');
    }
}
