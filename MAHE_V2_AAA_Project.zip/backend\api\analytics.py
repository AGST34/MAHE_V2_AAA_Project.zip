"""
Analytics API Routes Module

Calculates and returns aggregated insights from the evaluations table.
Useful for rendering dashboards showing system-wide AI performance and hallucination rates.
"""

from typing import Any, Dict
from datetime import datetime, timedelta

from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy import func, cast, Float, and_
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.future import select

from backend.auth import get_current_active_user, get_current_superuser
from backend.database import get_db
from backend.models import Evaluation, EvaluationResult, User
from backend.utils.logger import get_logger

logger = get_logger(__name__)
router = APIRouter()

@router.get("/summary", summary="Get global evaluation summary")
async def get_analytics_summary(
    days: int = Query(30, description="Time window in days"),
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_active_user) # Any active user can see summary
) -> Dict[str, Any]:
    """
    Returns high-level statistics like total evaluations run and global average scores.
    """
    cutoff_date = datetime.utcnow() - timedelta(days=days)
    
    # Total evaluations
    eval_stmt = select(func.count(Evaluation.id)).where(Evaluation.created_at >= cutoff_date)
    eval_count = (await db.execute(eval_stmt)).scalar() or 0
    
    # Averages from Results
    res_stmt = select(
        func.avg(EvaluationResult.hallucination_score).label("avg_hallucination"),
        func.avg(EvaluationResult.coherence_score).label("avg_coherence"),
        func.avg(EvaluationResult.factual_accuracy).label("avg_factual"),
        func.avg(EvaluationResult.composite_score).label("avg_composite"),
    ).join(Evaluation).where(Evaluation.created_at >= cutoff_date)
    
    res_result = (await db.execute(res_stmt)).one()
    
    return {
        "period_days": days,
        "total_evaluations": eval_count,
        "averages": {
            "hallucination": float(res_result.avg_hallucination or 0.0),
            "coherence": float(res_result.avg_coherence or 0.0),
            "factual_accuracy": float(res_result.avg_factual or 0.0),
            "composite_score": float(res_result.avg_composite or 0.0),
        }
    }

@router.get("/models", summary="Compare performance across models")
async def get_model_analytics(
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
) -> Dict[str, Any]:
    """
    Aggregates performance metrics grouped by agent/model name.
    """
    stmt = select(
        EvaluationResult.agent_name,
        func.count(EvaluationResult.id).label("total_runs"),
        func.avg(EvaluationResult.hallucination_score).label("avg_hallucination"),
        func.avg(EvaluationResult.composite_score).label("avg_composite"),
        func.avg(EvaluationResult.processing_time_ms).label("avg_time_ms")
    ).group_by(EvaluationResult.agent_name)
    
    result = await db.execute(stmt)
    rows = result.all()
    
    model_data = []
    for row in rows:
        model_data.append({
            "model": row.agent_name,
            "total_runs": row.total_runs,
            "avg_hallucination": round(float(row.avg_hallucination or 0.0), 3),
            "avg_composite": round(float(row.avg_composite or 0.0), 3),
            "avg_processing_time_ms": int(row.avg_time_ms or 0)
        })
        
    return {"models": model_data}

@router.get("/trends", summary="Time-series trend data")
async def get_analytics_trends(
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_superuser) # Only admins get trend data
) -> Dict[str, Any]:
    """
    Returns time-series data for chart rendering. Restricted to superusers.
    """
    # Note: Complex date grouping varies heavily by SQL Dialect. 
    # For SQLite, strftime is used. For Postgres, date_trunc.
    # Using generic fallback logic via Python processing for this example,
    # though in production you'd write dialect-specific SQL.
    
    stmt = select(EvaluationResult.created_at, EvaluationResult.hallucination_score)
    result = await db.execute(stmt)
    
    # Simple grouping in Python (inefficient for millions of rows, fine for demo)
    trends = {}
    for row in result.all():
        if not row.created_at or row.hallucination_score is None:
            continue
        day_str = row.created_at.strftime("%Y-%m-%d")
        if day_str not in trends:
            trends[day_str] = {"total": 0, "sum_hal": 0.0}
        trends[day_str]["total"] += 1
        trends[day_str]["sum_hal"] += row.hallucination_score
        
    formatted = [
        {
            "date": day, 
            "avg_hallucination": round(trends[day]["sum_hal"] / trends[day]["total"], 3)
        }
        for day in sorted(trends.keys())
    ]
    
    return {"trends": formatted}
