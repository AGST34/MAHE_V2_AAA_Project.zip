"""
API Router definitions
"""
