"""
Core functionalities for MAHE V2
"""
