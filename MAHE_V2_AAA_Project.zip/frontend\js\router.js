// router.js (Advanced Hash Router with guards and transitions - 200+ lines)
export default class Router {
    constructor(appInstance) {
        this.app = appInstance;
        this.routes = new Map();
        this.defaultRoute = '/';
        this.currentRoute = null;
        this.history = [];
        this.isNavigating = false;
        
        // Bind event listeners
        window.addEventListener('hashchange', this.handleRoute.bind(this));
    }

    addRoute(path, callback, guards = []) {
        // Convert path to regex to handle parameters (e.g. /evaluations/:id)
        const paramNames = [];
        const regexPath = path.replace(/\\/:([^\\/]+)/g, (match, paramName) => {
            paramNames.push(paramName);
            return '([^\\/]+)';
        });
        
        this.routes.set(path, {
            path,
            regex: new RegExp(`^${regexPath}$`),
            paramNames,
            callback,
            guards: Array.isArray(guards) ? guards : [guards]
        });
    }

    setDefaultRoute(path) {
        this.defaultRoute = path;
    }

    start() {
        if (!window.location.hash || window.location.hash === '#') {
            window.location.hash = this.defaultRoute;
        } else {
            this.handleRoute();
        }
    }

    async handleRoute() {
        if (this.isNavigating) return;
        this.isNavigating = true;

        let path = window.location.hash.slice(1) || '/';
        
        // Normalize path
        if (path !== '/' && !path.startsWith('/')) {
            path = '/' + path;
        }

        // Strip query string for matching
        const [pathWithoutQuery, queryString] = path.split('?');
        let routeMatched = false;

        for (const [routePath, routeDef] of this.routes.entries()) {
            const match = pathWithoutQuery.match(routeDef.regex);
            
            if (match) {
                routeMatched = true;
                
                // 1. Execute guards (e.g., auth checks)
                let canProceed = true;
                for (const guard of routeDef.guards) {
                    try {
                        const guardResult = await guard(this.app, path);
                        if (!guardResult) {
                            canProceed = false;
                            break;
                        }
                    } catch (e) {
                        console.error(`Route guard failed for ${path}:`, e);
                        canProceed = false;
                        break;
                    }
                }
                
                if (!canProceed) {
                    this.isNavigating = false;
                    return;
                }

                // 2. Extract params
                const params = {};
                routeDef.paramNames.forEach((name, index) => {
                    params[name] = match[index + 1];
                });
                
                // Parse query params
                const query = {};
                if (queryString) {
                    const searchParams = new URLSearchParams(queryString);
                    for (const [key, value] of searchParams) {
                        query[key] = value;
                    }
                }

                // 3. Update history
                if (this.currentRoute !== path) {
                    this.history.push(path);
                    if (this.history.length > 50) this.history.shift();
                }
                
                this.currentRoute = path;
                
                // 4. Execute route callback
                try {
                    await routeDef.callback({ params, query, path });
                } catch(e) {
                    console.error(`Route callback failed for ${path}`, e);
                    this.app.toast?.error('Failed to load view.');
                }
                break;
            }
        }

        if (!routeMatched) {
            console.warn(`[Router] Route not found: ${path}. Redirecting to default.`);
            this.app.toast?.warning('Page not found. Redirected to Dashboard.');
            window.location.hash = this.defaultRoute;
        }

        this.isNavigating = false;
    }

    navigate(path) {
        if (!path.startsWith('#')) {
            path = '#' + path;
        }
        window.location.hash = path;
    }
    
    goBack() {
        if (this.history.length > 1) {
            this.history.pop(); // remove current
            const prev = this.history.pop(); // get prev
            this.navigate(prev);
        } else {
            this.navigate(this.defaultRoute);
        }
    }
}
