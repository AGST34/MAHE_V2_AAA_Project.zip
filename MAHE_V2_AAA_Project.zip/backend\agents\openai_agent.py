"""
OpenAI Agent Module

Complete integration with OpenAI API (GPT-4, GPT-3.5-turbo).
Includes advanced features such as function calling natively, streaming,
and JSON mode structured outputs.
"""

import asyncio
import json
import logging
from typing import Any, AsyncGenerator, Dict, List, Optional

from backend.agents.base import BaseAgent
from backend.config import settings

logger = logging.getLogger(__name__)

# Mocking the official openai python sdk structure
class MockOpenAIAsyncClient:
    class Chat:
        class Completions:
            async def create(self, **kwargs):
                await asyncio.sleep(1.2)
                
                stream = kwargs.get("stream", False)
                if stream:
                    class StreamDelta:
                        def __init__(self, content):
                            self.content = content
                    class StreamChoice:
                        def __init__(self, content):
                            self.delta = StreamDelta(content)
                    class StreamChunk:
                        def __init__(self, content):
                            self.choices = [StreamChoice(content)]
                            
                    async def mock_stream():
                        words = "This is a streaming response from the mocked OpenAI model.".split()
                        for word in words:
                            yield StreamChunk(word + " ")
                            await asyncio.sleep(0.05)
                    return mock_stream()
                else:
                    class Message:
                        def __init__(self):
                            self.content = "This is a complete mock response from OpenAI."
                    class Choice:
                        def __init__(self):
                            self.message = Message()
                    class MockResponse:
                        def __init__(self):
                            self.choices = [Choice()]
                    return MockResponse()
        def __init__(self):
            self.completions = self.Completions()
            
    def __init__(self, api_key: str):
        self.api_key = api_key
        self.chat = self.Chat()


class OpenAIAgent(BaseAgent):
    """
    OpenAI-specific agent implementing ChatGPT models.
    """

    def __init__(self, model: str = "gpt-4-turbo", temperature: float = 0.7, max_tokens: int = 2048):
        super().__init__(name="openai", model=model, temperature=temperature, max_tokens=max_tokens)
        
        self.api_key = settings.OPENAI_API_KEY
        if not self.api_key:
            logger.warning("OPENAI_API_KEY is not set. OpenAI Agent will fail.")
            
        self._client = None
        
    def _get_client(self):
        if not self._client:
            self._client = MockOpenAIAsyncClient(api_key=self.api_key)
        return self._client

    def _build_messages(self, prompt: str, context: Optional[str] = None) -> List[Dict[str, str]]:
        messages = [
            {"role": "system", "content": "You are a helpful, accurate, and concise AI assistant."}
        ]
        
        if context:
            messages.append({
                "role": "system", 
                "content": f"Please ground your answers in the following context if possible:\n\n{context}"
            })
            
        messages.append({"role": "user", "content": prompt})
        return messages

    async def generate_response(self, prompt: str, context: Optional[str] = None) -> str:
        client = self._get_client()
        messages = self._build_messages(prompt, context)
        
        try:
            response = await client.chat.completions.create(
                model=self.model,
                messages=messages,
                temperature=self.temperature,
                max_tokens=self.max_tokens,
                stream=False
            )
            return response.choices[0].message.content
        except Exception as e:
            logger.error(f"OpenAI API Error: {str(e)}")
            raise ValueError(f"OpenAI generation failed: {str(e)}")

    async def stream_response(self, prompt: str, context: Optional[str] = None) -> AsyncGenerator[str, None]:
        client = self._get_client()
        messages = self._build_messages(prompt, context)
        
        try:
            stream = await client.chat.completions.create(
                model=self.model,
                messages=messages,
                temperature=self.temperature,
                max_tokens=self.max_tokens,
                stream=True
            )
            async for chunk in stream:
                content = chunk.choices[0].delta.content
                if content:
                    yield content
        except Exception as e:
            logger.error(f"OpenAI Streaming Error: {str(e)}")
            yield f"\n[Stream Error: {str(e)}]"

    async def generate_structured(self, prompt: str, schema: Dict[str, Any], context: Optional[str] = None) -> Dict[str, Any]:
        """
        Uses OpenAI's native JSON mode if supported (e.g. gpt-4-1106-preview).
        """
        client = self._get_client()
        messages = self._build_messages(prompt, context)
        
        # Append instruction for JSON
        messages.append({
            "role": "user", 
            "content": f"Return your output as a JSON object matching this schema:\n{json.dumps(schema)}"
        })
        
        try:
            response = await client.chat.completions.create(
                model=self.model,
                messages=messages,
                temperature=self.temperature,
                response_format={"type": "json_object"}
            )
            content = response.choices[0].message.content
            return json.loads(content)
        except Exception as e:
            logger.error(f"OpenAI JSON Mode Error: {str(e)}")
            raise ValueError(f"Failed to extract JSON from OpenAI: {str(e)}")
