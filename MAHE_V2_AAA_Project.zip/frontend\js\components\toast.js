// components/toast.js (Detailed Toast Manager - 150+ lines)
export class ToastManager {
    constructor() {
        this.container = document.getElementById('toast-container');
        if (!this.container) {
            this.container = document.createElement('div');
            this.container.id = 'toast-container';
            this.container.className = 'fixed bottom-6 right-6 flex flex-col gap-3 z-[1080] pointer-events-none';
            document.body.appendChild(this.container);
        }
        
        this.toasts = new Map();
        this.toastCount = 0;
    }

    show(message, type = 'info', options = {}) {
        const duration = options.duration !== undefined ? options.duration : 4000;
        const id = `toast_${++this.toastCount}`;
        
        const toast = document.createElement('div');
        toast.id = id;
        
        // Base styling for toast
        let typeClass = '';
        let iconHtml = '';
        
        if (type === 'success') {
            typeClass = 'bg-tertiary border-success';
            iconHtml = '<svg class="w-5 h-5 text-success" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"></path></svg>';
        } else if (type === 'error') {
            typeClass = 'bg-tertiary border-error';
            iconHtml = '<svg class="w-5 h-5 text-error" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path></svg>';
        } else if (type === 'warning') {
            typeClass = 'bg-tertiary border-warning';
            iconHtml = '<svg class="w-5 h-5 text-warning" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z"></path></svg>';
        } else {
            typeClass = 'bg-tertiary border-cyan';
            iconHtml = '<svg class="w-5 h-5 text-cyan" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>';
        }
        
        toast.className = `glass-panel pointer-events-auto flex items-start p-4 rounded-lg min-w-[300px] max-w-md transform transition-all duration-300 translate-x-full opacity-0 border ${typeClass}`;
        
        toast.innerHTML = `
            <div class="mr-3 mt-0.5 flex-shrink-0">${iconHtml}</div>
            <div class="flex-1 mr-2">
                ${options.title ? `<h4 class="text-sm font-bold mb-1 text-primary">${options.title}</h4>` : ''}
                <p class="text-sm text-secondary leading-tight">${message}</p>
            </div>
            <button class="text-muted hover:text-primary transition-colors focus:outline-none flex-shrink-0" id="close-${id}">
                <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path></svg>
            </button>
            ${duration > 0 ? `<div class="absolute bottom-0 left-0 h-1 bg-${type === 'info' ? 'cyan' : type} opacity-50" id="progress-${id}" style="width: 100%; transition: width ${duration}ms linear;"></div>` : ''}
        `;

        this.container.appendChild(toast);
        this.toasts.set(id, toast);

        // Bind close button
        toast.querySelector(`#close-${id}`).addEventListener('click', () => {
            this.dismiss(id);
        });

        // Animate in
        requestAnimationFrame(() => {
            toast.classList.remove('translate-x-full', 'opacity-0');
            
            // Start progress bar
            if (duration > 0) {
                const pb = toast.querySelector(`#progress-${id}`);
                if (pb) {
                    requestAnimationFrame(() => {
                        pb.style.width = '0%';
                    });
                }
            }
        });

        // Auto dismiss
        if (duration > 0) {
            const timeoutId = setTimeout(() => {
                this.dismiss(id);
            }, duration);
            toast.dataset.timeoutId = timeoutId;
        }
    }

    success(message, options) { this.show(message, 'success', options); }
    error(message, options) { this.show(message, 'error', options); }
    warning(message, options) { this.show(message, 'warning', options); }
    info(message, options) { this.show(message, 'info', options); }

    dismiss(id) {
        const toast = this.toasts.get(id);
        if (toast) {
            if (toast.dataset.timeoutId) clearTimeout(parseInt(toast.dataset.timeoutId));
            
            toast.classList.add('translate-x-full', 'opacity-0');
            setTimeout(() => {
                toast.remove();
                this.toasts.delete(id);
            }, 300);
        }
    }
}
