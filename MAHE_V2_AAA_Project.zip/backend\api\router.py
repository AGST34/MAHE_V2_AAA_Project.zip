from fastapi import APIRouter
from backend.api import evaluations, history, analytics, health, auth_routes

api_router = APIRouter()

api_router.include_router(health.router, tags=["health"])
api_router.include_router(auth_routes.router, prefix="/auth", tags=["auth"])
api_router.include_router(evaluations.router, prefix="/evaluate", tags=["evaluations"])
api_router.include_router(history.router, prefix="/history", tags=["history"])
api_router.include_router(analytics.router, prefix="/analytics", tags=["analytics"])
