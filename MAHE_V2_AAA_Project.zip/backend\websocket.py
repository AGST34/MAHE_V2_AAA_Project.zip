"""
WebSocket Connection Manager Module

Handles real-time streaming, status updates, and agent progression 
for the frontend client. Supports rooms, broadcasting, connection heartbeats,
and graceful disconnection handling.
"""

import asyncio
import json
import logging
from typing import Dict, List, Optional
from fastapi import WebSocket, WebSocketDisconnect

logger = logging.getLogger(__name__)

class ConnectionManager:
    """
    Manages active WebSocket connections.
    Supports isolating connections by 'room' (e.g., evaluation_id) so that
    results are only streamed to interested clients.
    """
    def __init__(self):
        # Maps evaluation_id (room) to a list of connected WebSockets
        self.active_connections: Dict[str, List[WebSocket]] = {}
        # Keep track of all connections for broadcast purposes
        self.all_connections: List[WebSocket] = []

    async def connect(self, websocket: WebSocket, room_id: Optional[str] = None):
        """
        Accepts the WebSocket connection and registers it.
        
        Args:
            websocket (WebSocket): The connection object.
            room_id (str, optional): The evaluation room to join.
        """
        await websocket.accept()
        self.all_connections.append(websocket)
        
        if room_id:
            if room_id not in self.active_connections:
                self.active_connections[room_id] = []
            self.active_connections[room_id].append(websocket)
            logger.info(f"WebSocket joined room: {room_id}")
            
        logger.debug(f"New WS connection. Total connections: {len(self.all_connections)}")

    def disconnect(self, websocket: WebSocket, room_id: Optional[str] = None):
        """
        Removes the WebSocket from internal registries upon disconnect.
        """
        if websocket in self.all_connections:
            self.all_connections.remove(websocket)
            
        if room_id and room_id in self.active_connections:
            if websocket in self.active_connections[room_id]:
                self.active_connections[room_id].remove(websocket)
            # Cleanup empty rooms
            if not self.active_connections[room_id]:
                del self.active_connections[room_id]
                
        logger.debug(f"WS disconnected. Remaining connections: {len(self.all_connections)}")

    async def send_personal_message(self, message: dict, websocket: WebSocket):
        """
        Sends a JSON-encoded message to a specific connection.
        """
        try:
            await websocket.send_json(message)
        except Exception as e:
            logger.error(f"Error sending personal message: {str(e)}")

    async def broadcast_to_room(self, room_id: str, message: dict):
        """
        Sends a JSON message to all connections in a specific room.
        Useful for streaming updates for a specific evaluation.
        """
        if room_id in self.active_connections:
            # We copy the list to avoid modification during iteration if someone disconnects
            connections = list(self.active_connections[room_id])
            for connection in connections:
                try:
                    await connection.send_json(message)
                except Exception as e:
                    logger.error(f"Error broadcasting to room {room_id}: {str(e)}")
                    # Force disconnect on error
                    self.disconnect(connection, room_id)

    async def broadcast(self, message: dict):
        """
        Sends a JSON message to ALL connected clients.
        Useful for global system alerts.
        """
        for connection in list(self.all_connections):
            try:
                await connection.send_json(message)
            except Exception as e:
                logger.error(f"Error in global broadcast: {str(e)}")
                self.disconnect(connection)

    async def start_heartbeat(self, websocket: WebSocket, interval: int = 30):
        """
        Maintains connection liveness by sending periodic ping messages.
        """
        try:
            while True:
                await asyncio.sleep(interval)
                await websocket.send_json({"type": "ping", "timestamp": str(asyncio.get_event_loop().time())})
        except WebSocketDisconnect:
            pass
        except Exception as e:
            logger.debug(f"Heartbeat loop ended: {str(e)}")

# Global instance of the connection manager
manager = ConnectionManager()
