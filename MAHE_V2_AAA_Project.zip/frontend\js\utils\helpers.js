// utils/helpers.js (DOM and Utility Helpers - 200+ lines)

export const Helpers = {
    // --------------------------------------------------------
    // DOM Helpers
    // --------------------------------------------------------
    
    $el(selector, context = document) {
        return context.querySelector(selector);
    },

    $all(selector, context = document) {
        return Array.from(context.querySelectorAll(selector));
    },

    create(tag, attributes = {}, children = []) {
        const el = document.createElement(tag);
        
        for (const [key, value] of Object.entries(attributes)) {
            if (key === 'className') {
                el.className = value;
            } else if (key === 'dataset') {
                for (const [dKey, dValue] of Object.entries(value)) {
                    el.dataset[dKey] = dValue;
                }
            } else if (key === 'style' && typeof value === 'object') {
                Object.assign(el.style, value);
            } else if (key.startsWith('on') && typeof value === 'function') {
                el.addEventListener(key.substring(2).toLowerCase(), value);
            } else if (value !== null && value !== undefined) {
                el.setAttribute(key, value);
            }
        }
        
        if (!Array.isArray(children)) {
            children = [children];
        }
        
        children.forEach(child => {
            if (typeof child === 'string' || typeof child === 'number') {
                el.appendChild(document.createTextNode(String(child)));
            } else if (child instanceof Node) {
                el.appendChild(child);
            }
        });
        
        return el;
    },

    removeAllChildren(parent) {
        while (parent.firstChild) {
            parent.removeChild(parent.firstChild);
        }
    },

    addClass(element, ...classes) {
        if (!element) return;
        element.classList.add(...classes);
    },

    removeClass(element, ...classes) {
        if (!element) return;
        element.classList.remove(...classes);
    },

    // --------------------------------------------------------
    // Timing & Async Helpers
    // --------------------------------------------------------

    debounce(func, wait, immediate = false) {
        let timeout;
        return function(...args) {
            const context = this;
            const later = function() {
                timeout = null;
                if (!immediate) func.apply(context, args);
            };
            const callNow = immediate && !timeout;
            clearTimeout(timeout);
            timeout = setTimeout(later, wait);
            if (callNow) func.apply(context, args);
        };
    },

    throttle(func, limit) {
        let inThrottle;
        return function(...args) {
            const context = this;
            if (!inThrottle) {
                func.apply(context, args);
                inThrottle = true;
                setTimeout(() => inThrottle = false, limit);
            }
        };
    },

    sleep(ms) {
        return new Promise(resolve => setTimeout(resolve, ms));
    },

    async retry(fn, retries = 3, delay = 1000) {
        try {
            return await fn();
        } catch (e) {
            if (retries === 1) throw e;
            await this.sleep(delay);
            return this.retry(fn, retries - 1, delay * 2);
        }
    },

    // --------------------------------------------------------
    // Math & Data Helpers
    // --------------------------------------------------------
    
    clamp(num, min, max) {
        return Math.min(Math.max(num, min), max);
    },

    uuid() {
        return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
            var r = Math.random() * 16 | 0,
                v = c === 'x' ? r : (r & 0x3 | 0x8);
            return v.toString(16);
        });
    },
    
    downloadFile(filename, content, mimeType = 'text/plain') {
        const blob = new Blob([content], { type: mimeType });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = filename;
        document.body.appendChild(a);
        a.click();
        
        setTimeout(() => {
            document.body.removeChild(a);
            window.URL.revokeObjectURL(url);
        }, 0);
    }
};
