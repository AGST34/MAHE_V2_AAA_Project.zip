// components/dashboard.js
import { Chart } from '../charts.js';

export default {
    render() {
        const div = document.createElement('div');
        div.innerHTML = `
            <div class="dashboard-grid">
                <!-- Stats -->
                <div class="stat-card glass-panel cyan-accent">
                    <div class="stat-title">Total Evaluations</div>
                    <div class="stat-value" id="stat-total">1,245</div>
                    <div class="stat-change positive">
                        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="22 7 13.5 15.5 8.5 10.5 2 17"></polyline><polyline points="16 7 22 7 22 13"></polyline></svg>
                        +12% this week
                    </div>
                </div>
                
                <div class="stat-card glass-panel purple-accent">
                    <div class="stat-title">Hallucination Rate</div>
                    <div class="stat-value" id="stat-rate">8.4%</div>
                    <div class="stat-change negative">
                        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="22 17 13.5 8.5 8.5 13.5 2 7"></polyline><polyline points="16 17 22 17 22 11"></polyline></svg>
                        -2.1% from last week
                    </div>
                </div>
                
                <div class="stat-card glass-panel cyan-accent">
                    <div class="stat-title">Active Models</div>
                    <div class="stat-value">4</div>
                    <div class="stat-change text-muted">GPT-4, Claude-3, Gemini</div>
                </div>
                
                <div class="stat-card glass-panel purple-accent">
                    <div class="stat-title">Avg Processing Time</div>
                    <div class="stat-value">1.2s</div>
                    <div class="stat-change positive">Fast & Stable</div>
                </div>

                <!-- Charts -->
                <div class="chart-container glass-panel">
                    <div class="chart-header">
                        <div class="chart-title">Evaluation Activity (Last 7 Days)</div>
                    </div>
                    <div class="chart-canvas-wrapper">
                        <canvas id="activityChart"></canvas>
                    </div>
                </div>
                
                <div class="chart-container glass-panel">
                    <div class="chart-header">
                        <div class="chart-title">Hallucination Rate by Model</div>
                    </div>
                    <div class="chart-canvas-wrapper">
                        <canvas id="modelChart"></canvas>
                    </div>
                </div>

                <!-- Recent Activity -->
                <div class="activity-feed glass-panel">
                    <div class="chart-title" style="margin-bottom:16px;">Recent Evaluations</div>
                    <div id="recent-list">
                        <!-- Items injected here -->
                    </div>
                </div>
            </div>
        `;
        return div;
    },
    
    init() {
        // Initialize charts
        setTimeout(() => {
            const actCanvas = document.getElementById('activityChart');
            if(actCanvas) {
                new Chart(actCanvas, {
                    type: 'line',
                    data: {
                        labels: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'],
                        datasets: [{
                            data: [120, 190, 300, 250, 400, 200, 150],
                            borderColor: '#00f0ff',
                            backgroundColor: 'rgba(0, 240, 255, 0.2)'
                        }]
                    }
                });
            }

            const modCanvas = document.getElementById('modelChart');
            if(modCanvas) {
                new Chart(modCanvas, {
                    type: 'bar',
                    data: {
                        labels: ['GPT-4', 'Claude-3', 'Gemini-1.5', 'Llama-3'],
                        datasets: [{
                            data: [4.2, 3.8, 6.1, 8.5],
                            backgroundColor: '#7b2ff7'
                        }]
                    }
                });
            }
            
            // Populate recent list
            const list = document.getElementById('recent-list');
            const items = [
                { model: 'GPT-4', status: 'clean', text: 'Analyze Q3 financial report for anomalies...' },
                { model: 'Claude-3', status: 'hallucination', text: 'Summarize the plot of Inception and focus on...' },
                { model: 'Gemini-1.5', status: 'clean', text: 'Write a python script to parse JSON logs...' }
            ];
            
            let html = '';
            items.forEach(item => {
                const isClean = item.status === 'clean';
                html += `
                    <div class="activity-item">
                        <div class="activity-icon" style="color: ${isClean ? 'var(--success)' : 'var(--error)'}">
                            ${isClean ? 
                                '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path><polyline points="22 4 12 14.01 9 11.01"></polyline></svg>' : 
                                '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"></circle><line x1="12" y1="8" x2="12" y2="12"></line><line x1="12" y1="16" x2="12.01" y2="16"></line></svg>'
                            }
                        </div>
                        <div class="activity-content">
                            <div class="activity-title">${item.text}</div>
                            <div class="activity-meta">Model: <span class="text-cyan">${item.model}</span> • 2 mins ago</div>
                        </div>
                        <div class="badge ${isClean ? 'badge-success' : 'badge-error'}">${isClean ? 'Passed' : 'Hallucination Detected'}</div>
                    </div>
                `;
            });
            if(list) list.innerHTML = html;
        }, 100);
    }
}
