// app.js (Massive expansion of core App logic)
import Router from './router.js';
import Store from './store.js';
import { Api } from './api.js';
import { Socket } from './websocket.js';
import { ToastManager } from './components/toast.js';

// Global Event Emitter for decoupling cross-component communication
class EventBus {
    constructor() {
        this.events = {};
    }
    on(event, listener) {
        if (!this.events[event]) this.events[event] = [];
        this.events[event].push(listener);
    }
    off(event, listener) {
        if (!this.events[event]) return;
        this.events[event] = this.events[event].filter(l => l !== listener);
    }
    emit(event, ...args) {
        if (!this.events[event]) return;
        this.events[event].forEach(listener => listener(...args));
    }
}

class App {
    constructor() {
        console.time('App Initialization');
        
        // 1. Core Services
        this.events = new EventBus();
        this.toast = new ToastManager();
        this.api = new Api(this);
        this.socket = new Socket('ws://localhost:8000/ws', this);
        
        // 2. Global State Management
        this.initializeStore();
        
        // 3. Routing
        this.router = new Router(this);
        
        // 4. Error Boundaries
        this.setupErrorHandling();
        
        // 5. Global Listeners (Keyboard, Resize, Theme)
        this.setupGlobalListeners();
        
        // 6. Component References
        this.ui = {
            sidebar: document.getElementById('sidebar'),
            sidebarToggle: document.getElementById('sidebar-toggle'),
            mobileToggle: document.getElementById('mobile-menu-toggle'),
            viewContainer: document.getElementById('view-container'),
            viewTitle: document.getElementById('view-title'),
            viewSubtitle: document.getElementById('view-subtitle'),
            globalSearch: document.getElementById('global-search'),
            notificationBtn: document.getElementById('notification-btn'),
            notificationDropdown: document.getElementById('notification-dropdown'),
            progressBar: document.getElementById('global-progress')
        };
    }

    initializeStore() {
        // Initial Default State
        const defaultState = {
            user: {
                id: 'usr_001',
                name: 'Admin User',
                role: 'Superadmin',
                avatar: 'AD'
            },
            appMeta: {
                version: '2.4.1',
                environment: 'production',
                latency: 0
            },
            ui: {
                activeView: 'dashboard',
                sidebarCollapsed: false,
                theme: 'dark',
                compactMode: false
            },
            models: [
                { id: 'gpt-4-turbo', name: 'GPT-4 Turbo', provider: 'OpenAI', defaultTemp: 0.7 },
                { id: 'gpt-4o', name: 'GPT-4o', provider: 'OpenAI', defaultTemp: 0.7 },
                { id: 'claude-3-opus', name: 'Claude 3 Opus', provider: 'Anthropic', defaultTemp: 0.7 },
                { id: 'claude-3-5-sonnet', name: 'Claude 3.5 Sonnet', provider: 'Anthropic', defaultTemp: 0.7 },
                { id: 'gemini-1.5-pro', name: 'Gemini 1.5 Pro', provider: 'Google', defaultTemp: 0.7 },
                { id: 'llama-3-70b', name: 'Llama 3 70B', provider: 'Meta', defaultTemp: 0.6 }
            ],
            settings: {
                defaultEvaluator: 'gpt-4o',
                apiKeys: {
                    openai: '',
                    anthropic: '',
                    google: ''
                },
                saveHistoryLocally: true,
                autoRunComparisons: false
            },
            data: {
                stats: null,
                recentEvaluations: [],
                notifications: [
                    { id: 1, type: 'info', text: 'System update applied successfully.', time: '2 mins ago', read: false },
                    { id: 2, type: 'warning', text: 'Anthropic API rate limit approaching.', time: '1 hour ago', read: false },
                    { id: 3, type: 'error', text: 'Evaluation #EVAL-089 failed due to timeout.', time: '3 hours ago', read: true }
                ]
            }
        };

        // Hydrate from LocalStorage if available
        let savedState = {};
        try {
            const raw = localStorage.getItem('mahev2_state');
            if (raw) savedState = JSON.parse(raw);
        } catch(e) {
            console.warn('Failed to parse localStorage state:', e);
        }

        // Deep merge config (simplified for brevity, usually use lodash.merge)
        const mergedState = {
            ...defaultState,
            ui: { ...defaultState.ui, ...(savedState.ui || {}) },
            settings: { ...defaultState.settings, ...(savedState.settings || {}) }
        };

        window.store = new Store(mergedState);

        // Subscribe to state changes for side effects
        window.store.subscribe((nextState, prevState) => {
            // Persist specific slices
            const stateToPersist = {
                ui: nextState.ui,
                settings: nextState.settings
            };
            localStorage.setItem('mahev2_state', JSON.stringify(stateToPersist));

            // Theme side effects
            if (nextState.ui.theme !== prevState.ui.theme) {
                this.applyTheme(nextState.ui.theme);
            }
            
            // Sidebar side effects
            if (nextState.ui.sidebarCollapsed !== prevState.ui.sidebarCollapsed) {
                this.toggleSidebarUI(nextState.ui.sidebarCollapsed);
            }
            
            // Notification Badge updates
            this.updateNotificationBadge(nextState.data.notifications);
        });
    }

    async init() {
        console.log('[MAHE V2] Bootstrapping Application Modules...');
        
        // 1. Initialize Core UI Components
        this.initSidebarNavigation();
        this.initNavbarInteractions();
        
        // 2. Setup Route Definitions
        this.router.addRoute('/dashboard', () => this.loadView('dashboard', 'Dashboard', 'System Overview & Metrics'));
        this.router.addRoute('/evaluate', () => this.loadView('evaluate', 'Evaluate', 'Run single or batch model evaluations'));
        this.router.addRoute('/compare', () => this.loadView('compare', 'Compare Models', 'Side-by-side performance analysis'));
        this.router.addRoute('/history', () => this.loadView('history', 'History', 'Past evaluations and logs'));
        this.router.addRoute('/analytics', () => this.loadView('analytics', 'Analytics', 'Deep dive into hallucination trends'));
        this.router.addRoute('/settings', () => this.loadView('settings', 'Settings', 'Configuration & API Keys'));
        this.router.setDefaultRoute('/dashboard');

        // 3. Start Router
        this.router.start();
        
        // 4. Connect Services
        this.socket.connect();
        await this.loadInitialData();
        
        console.timeEnd('App Initialization');
        this.toast.success('MAHE V2 Initialized Successfully');
    }

    // --------------------------------------------------------
    // DATA LOADING
    // --------------------------------------------------------
    async loadInitialData() {
        try {
            this.showProgress(30);
            
            // Parallel loading of necessary bootstrapping data
            const [stats, history] = await Promise.all([
                this.api.getStats().catch(() => this.getMockStats()),
                this.api.getHistory({ limit: 5 }).catch(() => [])
            ]);
            
            this.showProgress(80);
            
            window.store.setState({
                data: {
                    ...window.store.getState().data,
                    stats,
                    recentEvaluations: history
                }
            });
            
            this.showProgress(100);
        } catch (error) {
            console.error('Failed to load initial data:', error);
            this.toast.error('Failed to fetch backend data. Operating in offline mode.');
            this.hideProgress();
        }
    }

    // --------------------------------------------------------
    // VIEW MANAGEMENT
    // --------------------------------------------------------
    async loadView(viewName, title, subtitle) {
        // Update UI Shell
        this.ui.viewTitle.textContent = title;
        this.ui.viewSubtitle.textContent = subtitle;
        
        // Update navigation active states
        document.querySelectorAll('.sidebar-nav a').forEach(link => {
            if (link.getAttribute('href') === `#/${viewName}`) {
                link.classList.add('active');
            } else {
                link.classList.remove('active');
            }
        });

        // Handle view transitions
        const container = this.ui.viewContainer;
        
        // Fade out current content
        container.classList.remove('fade-in');
        container.style.opacity = '0';
        
        this.showProgress(40);

        try {
            // Dynamic import of view component
            const module = await import(`./components/${viewName}.js`);
            
            this.showProgress(80);
            
            // Small delay to allow CSS transitions to catch up
            setTimeout(() => {
                container.innerHTML = '';
                const domNode = module.default.render(this);
                container.appendChild(domNode);
                
                if (module.default.init) {
                    module.default.init(this);
                }
                
                // Update global state
                const currentState = window.store.getState();
                window.store.setState({ ui: { ...currentState.ui, activeView: viewName } });
                
                // Fade in new content
                this.showProgress(100);
                container.style.opacity = '1';
                container.classList.add('fade-in');
                
            }, 150); // duration of opacity transition

        } catch (error) {
            console.error(`Error loading view [${viewName}]:`, error);
            this.hideProgress();
            this.toast.error(`Failed to load module: ${viewName}`);
            
            container.innerHTML = `
                <div class="glass-panel p-12 text-center rounded-xl mx-auto max-w-2xl mt-12">
                    <svg class="w-16 h-16 text-error mx-auto mb-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <circle cx="12" cy="12" r="10"></circle><line x1="12" y1="8" x2="12" y2="12"></line><line x1="12" y1="16" x2="12.01" y2="16"></line>
                    </svg>
                    <h3 class="text-2xl font-bold mb-2">View Loading Error</h3>
                    <p class="text-secondary mb-6">${error.message}</p>
                    <button class="btn btn-primary" onclick="window.location.reload()">Reload Application</button>
                </div>
            `;
            container.style.opacity = '1';
        }
    }

    // --------------------------------------------------------
    // UI HELPERS & LISTENERS
    // --------------------------------------------------------
    showProgress(percent) {
        if (!this.ui.progressBar) return;
        this.ui.progressBar.classList.remove('hidden');
        const bar = this.ui.progressBar.querySelector('.progress-bar');
        bar.style.width = `${percent}%`;
        
        if (percent >= 100) {
            setTimeout(() => this.hideProgress(), 300);
        }
    }

    hideProgress() {
        if (!this.ui.progressBar) return;
        this.ui.progressBar.classList.add('hidden');
        const bar = this.ui.progressBar.querySelector('.progress-bar');
        setTimeout(() => { bar.style.width = '0%'; }, 200);
    }

    applyTheme(theme) {
        if (theme === 'light') {
            document.body.classList.remove('dark-theme');
            document.body.classList.add('light-theme');
        } else {
            document.body.classList.remove('light-theme');
            document.body.classList.add('dark-theme');
        }
    }

    toggleSidebarUI(isCollapsed) {
        if (isCollapsed) {
            this.ui.sidebar.classList.add('collapsed');
            document.documentElement.style.setProperty('--sidebar-width', 'var(--sidebar-width-collapsed)');
        } else {
            this.ui.sidebar.classList.remove('collapsed');
            document.documentElement.style.setProperty('--sidebar-width', '260px');
        }
    }

    updateNotificationBadge(notifications) {
        const unread = notifications.filter(n => !n.read).length;
        const badge = document.getElementById('notification-count');
        if (badge) {
            badge.textContent = unread;
            badge.style.display = unread > 0 ? 'flex' : 'none';
        }
    }

    setupErrorHandling() {
        window.addEventListener('error', (e) => {
            console.error('Global JS Error:', e.error);
            this.toast.error('An unexpected application error occurred.');
        });
        
        window.addEventListener('unhandledrejection', (e) => {
            console.error('Unhandled Promise Rejection:', e.reason);
            // Don't show toast for every rejected API call if we handle them locally
        });
    }

    setupGlobalListeners() {
        // Keyboard shortcuts
        document.addEventListener('keydown', (e) => {
            // Cmd/Ctrl + K = Search
            if ((e.metaKey || e.ctrlKey) && e.key === 'k') {
                e.preventDefault();
                if (this.ui.globalSearch) this.ui.globalSearch.focus();
            }
            // Cmd/Ctrl + / = Quick Evaluate
            if ((e.metaKey || e.ctrlKey) && e.key === '/') {
                e.preventDefault();
                this.router.navigate('/evaluate');
            }
            // Escape = Close modals/dropdowns
            if (e.key === 'Escape') {
                this.events.emit('ui:close_overlays');
                if (this.ui.notificationDropdown) {
                    this.ui.notificationDropdown.classList.add('hidden');
                }
            }
        });

        // Click outside notification dropdown
        document.addEventListener('click', (e) => {
            if (this.ui.notificationBtn && this.ui.notificationDropdown) {
                if (!this.ui.notificationBtn.contains(e.target) && !this.ui.notificationDropdown.contains(e.target)) {
                    this.ui.notificationDropdown.classList.add('hidden');
                }
            }
        });
    }

    initSidebarNavigation() {
        const list = document.getElementById('sidebar-menu-list');
        if (!list) return;

        const navItems = [
            { id: 'dashboard', icon: 'icon-dashboard', label: 'Dashboard' },
            { id: 'evaluate', icon: 'icon-evaluate', label: 'Evaluate' },
            { id: 'compare', icon: 'icon-compare', label: 'Compare Models' },
            { id: 'history', icon: 'icon-history', label: 'History' },
            { id: 'analytics', icon: 'icon-analytics', label: 'Analytics' },
            { id: 'settings', icon: 'icon-settings', label: 'Settings', bottom: true }
        ];

        let html = '';
        navItems.forEach(item => {
            const liClass = item.bottom ? 'mt-auto' : '';
            html += `
                <li class="nav-item ${liClass}">
                    <a href="#/${item.id}" class="nav-link" data-view="${item.id}">
                        <svg class="icon"><use href="#${item.icon}"></use></svg>
                        <span class="label">${item.label}</span>
                        ${item.id === 'evaluate' ? '<span class="badge badge-cyan ml-auto text-xs">New</span>' : ''}
                    </a>
                </li>
            `;
        });
        
        list.innerHTML = html;

        // Toggle logic
        if (this.ui.sidebarToggle) {
            this.ui.sidebarToggle.addEventListener('click', () => {
                const currentState = window.store.getState();
                window.store.setState({
                    ui: { ...currentState.ui, sidebarCollapsed: !currentState.ui.sidebarCollapsed }
                });
            });
        }
    }

    initNavbarInteractions() {
        if (this.ui.notificationBtn) {
            this.ui.notificationBtn.addEventListener('click', () => {
                this.ui.notificationDropdown.classList.toggle('hidden');
                this.renderNotifications();
            });
        }
    }

    renderNotifications() {
        const list = document.getElementById('notification-list');
        if (!list) return;
        
        const state = window.store.getState();
        const notifications = state.data.notifications;
        
        if (notifications.length === 0) {
            list.innerHTML = `<div class="p-4 text-center text-muted text-sm">No new notifications</div>`;
            return;
        }

        let html = '';
        notifications.forEach(n => {
            const iconColor = n.type === 'error' ? 'text-error' : n.type === 'warning' ? 'text-warning' : 'text-cyan';
            const iconShape = n.type === 'error' ? 'icon-error' : n.type === 'warning' ? 'icon-alert' : 'icon-info';
            
            html += `
                <div class="notification-item flex gap-3 p-3 border-b border-primary hover:bg-glass cursor-pointer ${n.read ? 'opacity-60' : ''}">
                    <div class="${iconColor} mt-0.5">
                        <svg class="w-4 h-4"><use href="#${iconShape}"></use></svg>
                    </div>
                    <div>
                        <p class="text-sm leading-tight mb-1 text-primary">${n.text}</p>
                        <p class="text-xs text-muted">${n.time}</p>
                    </div>
                </div>
            `;
        });
        list.innerHTML = html;
    }

    getMockStats() {
        return {
            totalEvaluations: 12458,
            avgHallucinationRate: 8.4,
            activeModels: 6,
            avgLatency: 1.2,
            weeklyTrend: '+12%',
            rateTrend: '-2.1%'
        };
    }
}

// Global exposure & instantiation
document.addEventListener('DOMContentLoaded', () => {
    window.app = new App();
    window.app.init();
});
