"""
Application Configuration Module

This module defines the configuration settings for the MAHE V2 backend using Pydantic BaseSettings.
It provides comprehensive validation, default values, and computed properties for environment variables.
"""

import os
from enum import Enum
from typing import Any, Dict, List, Optional, Union
from pydantic import AnyHttpUrl, Field, field_validator, model_validator
from pydantic_settings import BaseSettings, SettingsConfigDict


class EnvironmentType(str, Enum):
    """Enumeration of supported deployment environments."""
    DEVELOPMENT = "development"
    TESTING = "testing"
    STAGING = "staging"
    PRODUCTION = "production"


class LogLevel(str, Enum):
    """Enumeration of standard logging levels."""
    DEBUG = "DEBUG"
    INFO = "INFO"
    WARNING = "WARNING"
    ERROR = "ERROR"
    CRITICAL = "CRITICAL"


class Settings(BaseSettings):
    """
    Main application configuration class.
    
    Attributes are populated from environment variables, a .env file, or defaults.
    """
    # Core Application Info
    PROJECT_NAME: str = Field(default="MAHE V2", description="The name of the project")
    VERSION: str = Field(default="2.0.0", description="Application version")
    DESCRIPTION: str = Field(
        default="Multi-Agent Hallucination Evaluator API", 
        description="A brief description of the API"
    )
    ENVIRONMENT: EnvironmentType = Field(
        default=EnvironmentType.DEVELOPMENT, 
        description="Current deployment environment"
    )
    API_V1_STR: str = Field(default="/api/v1", description="Prefix for API v1 routes")
    DEBUG: bool = Field(default=False, description="Enable debug mode")
    
    # CORS Configuration
    BACKEND_CORS_ORIGINS: List[str] = Field(
        default=["*"], 
        description="List of origins allowed to make cross-origin requests"
    )

    @field_validator("BACKEND_CORS_ORIGINS", mode="before")
    def assemble_cors_origins(cls, v: Union[str, List[str]]) -> Union[List[str], str]:
        """Validates and parses CORS origins."""
        if isinstance(v, str) and not v.startswith("["):
            return [i.strip() for i in v.split(",")]
        elif isinstance(v, (list, str)):
            return v
        raise ValueError(v)

    # Security & Authentication
    SECRET_KEY: str = Field(
        default="development-secret-key-please-change-in-production-long-random-string",
        description="Secret key used for JWT signing and cryptographic operations"
    )
    ALGORITHM: str = Field(default="HS256", description="Algorithm used for JWT")
    ACCESS_TOKEN_EXPIRE_MINUTES: int = Field(
        default=60 * 24 * 8, # 8 days
        description="Expiration time for access tokens in minutes"
    )
    REFRESH_TOKEN_EXPIRE_MINUTES: int = Field(
        default=60 * 24 * 30, # 30 days
        description="Expiration time for refresh tokens in minutes"
    )

    # Database Configuration
    DB_HOST: str = Field(default="localhost", description="Database host")
    DB_PORT: int = Field(default=5432, description="Database port")
    DB_USER: str = Field(default="postgres", description="Database user")
    DB_PASSWORD: str = Field(default="postgres", description="Database password")
    DB_NAME: str = Field(default="mahe_v2", description="Database name")
    DATABASE_URL: Optional[str] = Field(
        default="sqlite+aiosqlite:///./mahe_v2.db",
        description="Direct database URL connection string"
    )
    DB_POOL_SIZE: int = Field(default=20, description="SQLAlchemy pool size")
    DB_MAX_OVERFLOW: int = Field(default=10, description="SQLAlchemy max overflow")

    @model_validator(mode="after")
    def assemble_db_connection(self) -> "Settings":
        """Construct the database URL if not explicitly provided."""
        if not self.DATABASE_URL:
            # Fallback for complex database generation if required
            pass
        return self

    # External API Keys
    OPENAI_API_KEY: Optional[str] = Field(default=None, description="OpenAI API Key")
    GEMINI_API_KEY: Optional[str] = Field(default=None, description="Google Gemini API Key")
    ANTHROPIC_API_KEY: Optional[str] = Field(default=None, description="Anthropic API Key")

    @field_validator("OPENAI_API_KEY", "GEMINI_API_KEY", "ANTHROPIC_API_KEY")
    def warn_missing_keys(cls, v: Optional[str], info) -> Optional[str]:
        """Emit a warning if a crucial API key is missing in production."""
        # Note: In Pydantic v2 validators, `info` contains field metadata
        if not v:
            print(f"Warning: {info.field_name} is not set.")
        return v

    # Rate Limiting & Performance
    RATE_LIMIT_PER_MINUTE: int = Field(default=60, description="Max requests per minute per IP")
    REDIS_URL: Optional[str] = Field(default=None, description="Redis URL for caching/rate limiting")
    MAX_CONCURRENT_AGENTS: int = Field(
        default=10, 
        description="Maximum number of agents to run concurrently"
    )
    AGENT_TIMEOUT_SECONDS: int = Field(
        default=120, 
        description="Maximum seconds to wait for an agent response"
    )

    # Logging Configuration
    LOG_LEVEL: LogLevel = Field(default=LogLevel.INFO, description="Application logging level")
    LOG_FORMAT: str = Field(
        default="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
        description="Standard log format"
    )

    model_config = SettingsConfigDict(
        env_file=".env", 
        env_file_encoding="utf-8", 
        case_sensitive=True,
        extra="ignore"
    )


def get_settings() -> Settings:
    """
    Dependency to retrieve cached settings.
    In a real app, this might use lru_cache for performance.
    """
    return Settings()

settings = get_settings()
