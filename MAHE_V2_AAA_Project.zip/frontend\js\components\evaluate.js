// evaluate.js (Expanded Evaluation Component with 400+ lines of robust logic)
export default {
    render(app) {
        const div = document.createElement('div');
        div.className = 'evaluate-view-container h-full flex flex-col gap-6 fade-in';
        div.innerHTML = `
            <div class="grid grid-cols-12 gap-6 h-full min-h-[800px]">
                
                <!-- Left Panel: Configuration Form -->
                <div class="col-span-12 lg:col-span-5 flex flex-col gap-6">
                    
                    <!-- Form Header & Setup -->
                    <div class="glass-panel p-6 rounded-xl flex-1 flex flex-col relative overflow-hidden">
                        <div class="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-cyan-500 to-purple-500"></div>
                        <h3 class="text-xl font-bold mb-6 flex items-center gap-2">
                            <svg class="w-6 h-6 text-cyan"><use href="#icon-evaluate"></use></svg>
                            New Evaluation
                        </h3>
                        
                        <!-- Configuration Tabs -->
                        <div class="flex border-b border-primary mb-6">
                            <button class="tab-btn active px-4 py-2 text-sm font-medium border-b-2 border-cyan text-cyan">Single Query</button>
                            <button class="tab-btn px-4 py-2 text-sm font-medium border-b-2 border-transparent text-muted hover:text-secondary">Batch Mode</button>
                            <button class="tab-btn px-4 py-2 text-sm font-medium border-b-2 border-transparent text-muted hover:text-secondary">A/B Testing</button>
                        </div>
                        
                        <form id="eval-form" class="flex flex-col flex-1 gap-5">
                            
                            <!-- System Prompt -->
                            <div class="form-group">
                                <label class="block text-sm font-semibold text-secondary mb-2 flex justify-between">
                                    System Prompt
                                    <span class="text-xs font-normal text-muted bg-primary px-2 py-0.5 rounded">Optional</span>
                                </label>
                                <textarea id="eval-system-prompt" class="w-full bg-tertiary border border-primary rounded-lg p-3 text-primary font-mono text-sm focus:border-cyan focus:ring-1 focus:ring-cyan resize-y min-h-[80px]" placeholder="e.g. You are a helpful assistant that only answers in JSON format..."></textarea>
                                <p class="text-xs text-muted mt-1">Sets the behavior context for the target models.</p>
                            </div>
                            
                            <!-- User Query -->
                            <div class="form-group">
                                <label class="block text-sm font-semibold text-secondary mb-2 flex justify-between">
                                    User Query
                                    <span class="text-xs font-normal text-error">* Required</span>
                                </label>
                                <textarea id="eval-user-query" class="w-full bg-tertiary border border-primary rounded-lg p-4 text-primary font-mono text-sm focus:border-cyan focus:ring-1 focus:ring-cyan resize-y min-h-[140px]" placeholder="Enter the exact prompt to test for hallucinations..." required></textarea>
                            </div>
                            
                            <!-- Target Models Selection -->
                            <div class="form-group">
                                <label class="block text-sm font-semibold text-secondary mb-2">Target Models to Evaluate</label>
                                <div class="grid grid-cols-2 gap-3" id="model-checkbox-container">
                                    <!-- Rendered dynamically via init() -->
                                </div>
                            </div>
                            
                            <hr class="border-primary my-2">
                            
                            <!-- Judge Configuration -->
                            <div class="form-group">
                                <label class="block text-sm font-semibold text-secondary mb-2">Judge Model (Evaluator)</label>
                                <select id="eval-judge" class="w-full bg-tertiary border border-primary rounded-lg p-3 text-primary focus:border-purple focus:ring-1 focus:ring-purple cursor-pointer appearance-none">
                                    <option value="gpt-4o">GPT-4o (Recommended - Highest Accuracy)</option>
                                    <option value="claude-3-opus">Claude 3 Opus (Best for Logic)</option>
                                    <option value="gemini-1.5-pro">Gemini 1.5 Pro (Best for Long Context)</option>
                                </select>
                            </div>
                            
                            <!-- Advanced Settings Accordion -->
                            <div class="advanced-settings border border-primary rounded-lg overflow-hidden mt-2">
                                <button type="button" class="w-full bg-tertiary p-3 flex justify-between items-center text-sm font-medium hover:bg-glass transition-colors" id="adv-settings-toggle">
                                    <span>Advanced Parameters</span>
                                    <svg class="w-4 h-4 transition-transform duration-200" id="adv-chevron"><use href="#icon-chevron-down"></use></svg>
                                </button>
                                <div class="p-4 bg-secondary hidden" id="adv-settings-content">
                                    <!-- Temperature -->
                                    <div class="mb-4">
                                        <label class="flex justify-between text-sm mb-2">
                                            <span class="text-secondary">Temperature</span>
                                            <span class="text-cyan font-mono" id="temp-val">0.7</span>
                                        </label>
                                        <input type="range" id="eval-temp" min="0" max="1.5" step="0.1" value="0.7" class="w-full accent-cyan cursor-pointer">
                                        <div class="flex justify-between text-xs text-muted mt-1">
                                            <span>Deterministic (0)</span>
                                            <span>Creative (1.5)</span>
                                        </div>
                                    </div>
                                    
                                    <!-- Max Tokens -->
                                    <div>
                                        <label class="block text-sm text-secondary mb-2">Max Response Tokens</label>
                                        <input type="number" id="eval-tokens" class="w-full bg-tertiary border border-primary rounded p-2 text-sm" value="2048">
                                    </div>
                                </div>
                            </div>
                            
                            <!-- Submit Button -->
                            <button type="submit" id="btn-submit-eval" class="mt-auto w-full bg-gradient-to-r from-cyan-600 to-purple-600 hover:from-cyan-500 hover:to-purple-500 text-white font-bold py-4 px-6 rounded-lg shadow-lg hover:shadow-cyan-glow transition-all transform hover:-translate-y-1 flex items-center justify-center gap-3">
                                <svg class="w-5 h-5"><use href="#icon-play"></use></svg>
                                <span>Run Evaluation</span>
                            </button>
                        </form>
                    </div>
                </div>
                
                <!-- Right Panel: Real-time Results display -->
                <div class="col-span-12 lg:col-span-7 flex flex-col h-full">
                    <div class="glass-panel p-0 rounded-xl flex-1 flex flex-col overflow-hidden relative">
                        
                        <!-- Results Header -->
                        <div class="px-6 py-4 border-b border-primary bg-tertiary flex justify-between items-center z-10">
                            <h3 class="text-lg font-bold flex items-center gap-2">
                                <div class="w-2 h-2 rounded-full bg-cyan animate-pulse hidden" id="status-indicator"></div>
                                Execution Results
                            </h3>
                            <div class="flex gap-2">
                                <span id="eval-timer" class="text-mono text-sm text-muted hidden">00:00.0s</span>
                                <span id="eval-status-badge" class="badge bg-primary text-secondary border border-primary px-3 py-1">Idle</span>
                            </div>
                        </div>
                        
                        <!-- Empty State -->
                        <div id="results-empty" class="flex-1 flex flex-col items-center justify-center p-12 text-center absolute inset-0 pt-16 z-0">
                            <div class="w-24 h-24 mb-6 rounded-full bg-tertiary border-2 border-dashed border-primary flex items-center justify-center text-muted">
                                <svg class="w-10 h-10 opacity-50"><use href="#icon-evaluate"></use></svg>
                            </div>
                            <h4 class="text-xl font-semibold mb-2">Ready to Evaluate</h4>
                            <p class="text-secondary max-w-md mx-auto">Configure your parameters on the left and click "Run Evaluation" to stream real-time analysis of LLM hallucinations.</p>
                        </div>
                        
                        <!-- Loading State -->
                        <div id="results-loading" class="flex-1 flex flex-col p-6 hidden absolute inset-0 pt-16 z-0 overflow-y-auto">
                            <!-- Stream steps -->
                            <div class="mb-8">
                                <div class="flex justify-between mb-2">
                                    <span class="text-sm font-mono text-cyan" id="loading-step-text">Connecting to models...</span>
                                    <span class="text-sm font-mono text-cyan" id="loading-pct">15%</span>
                                </div>
                                <div class="w-full h-2 bg-tertiary rounded-full overflow-hidden">
                                    <div class="h-full bg-cyan shadow-glow-cyan w-[15%] transition-all duration-300" id="loading-bar"></div>
                                </div>
                            </div>
                            
                            <div class="flex flex-col gap-4">
                                <div class="glass-panel p-4 rounded-lg flex gap-4 opacity-50">
                                    <div class="w-8 h-8 rounded bg-tertiary animate-pulse"></div>
                                    <div class="flex-1 space-y-3 py-1">
                                        <div class="h-2 bg-tertiary rounded w-3/4 animate-pulse"></div>
                                        <div class="h-2 bg-tertiary rounded w-1/2 animate-pulse"></div>
                                    </div>
                                </div>
                                <div class="glass-panel p-4 rounded-lg flex gap-4 opacity-30">
                                    <div class="w-8 h-8 rounded bg-tertiary animate-pulse"></div>
                                    <div class="flex-1 space-y-3 py-1">
                                        <div class="h-2 bg-tertiary rounded w-5/6 animate-pulse"></div>
                                        <div class="h-2 bg-tertiary rounded w-4/6 animate-pulse"></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <!-- Actual Results Container -->
                        <div id="results-content" class="flex-1 hidden absolute inset-0 pt-16 z-0 overflow-y-auto bg-primary">
                            <!-- Injected by JS upon completion -->
                        </div>
                    </div>
                </div>
            </div>
        `;
        return div;
    },
    
    init(app) {
        this.app = app;
        this.bindEvents();
        this.renderModelOptions();
        
        // Timer state
        this.startTime = null;
        this.timerInterval = null;
    },
    
    renderModelOptions() {
        const container = document.getElementById('model-checkbox-container');
        const models = window.store.getState().models;
        
        let html = '';
        models.forEach((m, idx) => {
            html += `
                <label class="flex items-center gap-3 p-3 rounded-lg border border-primary bg-tertiary cursor-pointer hover:border-cyan transition-colors group">
                    <input type="checkbox" name="target-models" value="${m.id}" ${idx === 0 ? 'checked' : ''} class="w-4 h-4 accent-cyan cursor-pointer">
                    <div class="flex flex-col">
                        <span class="text-sm font-semibold group-hover:text-cyan transition-colors">${m.name}</span>
                        <span class="text-xs text-muted">${m.provider}</span>
                    </div>
                </label>
            `;
        });
        container.innerHTML = html;
    },
    
    bindEvents() {
        // Advanced Settings Accordion
        const advToggle = document.getElementById('adv-settings-toggle');
        const advContent = document.getElementById('adv-settings-content');
        const advChevron = document.getElementById('adv-chevron');
        
        if(advToggle) {
            advToggle.addEventListener('click', () => {
                advContent.classList.toggle('hidden');
                advChevron.style.transform = advContent.classList.contains('hidden') ? 'rotate(0deg)' : 'rotate(180deg)';
            });
        }
        
        // Temperature Slider
        const tempSlider = document.getElementById('eval-temp');
        const tempVal = document.getElementById('temp-val');
        if(tempSlider) {
            tempSlider.addEventListener('input', (e) => {
                tempVal.textContent = parseFloat(e.target.value).toFixed(1);
            });
        }
        
        // Form Submission
        const form = document.getElementById('eval-form');
        if(form) {
            form.addEventListener('submit', (e) => {
                e.preventDefault();
                this.runEvaluation();
            });
        }
    },
    
    startTimer() {
        const timerEl = document.getElementById('eval-timer');
        timerEl.classList.remove('hidden');
        this.startTime = Date.now();
        
        this.timerInterval = setInterval(() => {
            const elapsed = Date.now() - this.startTime;
            const secs = (elapsed / 1000).toFixed(1);
            
            // Formatting MM:SS.s
            const m = Math.floor(secs / 60).toString().padStart(2, '0');
            const s = (secs % 60).toFixed(1).padStart(4, '0');
            timerEl.textContent = `${m}:${s}s`;
        }, 100);
    },
    
    stopTimer() {
        if(this.timerInterval) clearInterval(this.timerInterval);
    },
    
    async runEvaluation() {
        const query = document.getElementById('eval-user-query').value.trim();
        if (!query) {
            this.app.toast.error('User query is required.');
            return;
        }

        const selectedModels = Array.from(document.querySelectorAll('input[name="target-models"]:checked')).map(cb => cb.value);
        if (selectedModels.length === 0) {
            this.app.toast.error('Select at least one target model.');
            return;
        }

        // Setup UI for Loading
        const btn = document.getElementById('btn-submit-eval');
        const emptyState = document.getElementById('results-empty');
        const loadingState = document.getElementById('results-loading');
        const contentState = document.getElementById('results-content');
        const statusBadge = document.getElementById('eval-status-badge');
        const indicator = document.getElementById('status-indicator');
        
        // Reset states
        btn.disabled = true;
        btn.innerHTML = `<div class="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin"></div><span>Processing...</span>`;
        
        emptyState.classList.add('hidden');
        contentState.classList.add('hidden');
        loadingState.classList.remove('hidden');
        
        statusBadge.className = 'badge bg-cyan/20 text-cyan border border-cyan/30 px-3 py-1';
        statusBadge.textContent = 'RUNNING';
        indicator.classList.remove('hidden');
        
        this.startTimer();
        
        // Mock streaming simulation
        const pBar = document.getElementById('loading-bar');
        const pText = document.getElementById('loading-step-text');
        const pPct = document.getElementById('loading-pct');
        
        const steps = [
            { t: 'Compiling prompt payload...', p: 25 },
            { t: `Querying ${selectedModels.length} models in parallel...`, p: 50 },
            { t: 'Models responded. Initializing Judge Evaluator...', p: 75 },
            { t: 'Analyzing for factual consistency...', p: 85 },
            { t: 'Finalizing verdict...', p: 95 },
            { t: 'Complete.', p: 100 }
        ];
        
        for (let i = 0; i < steps.length; i++) {
            await new Promise(r => setTimeout(r, 600 + Math.random() * 800));
            pBar.style.width = steps[i].p + '%';
            pText.textContent = steps[i].t;
            pPct.textContent = steps[i].p + '%';
        }
        
        this.stopTimer();
        this.renderResults(selectedModels[0], query);
        
        // Restore UI
        loadingState.classList.add('hidden');
        contentState.classList.remove('hidden');
        indicator.classList.add('hidden');
        
        statusBadge.className = 'badge bg-error/20 text-error border border-error/30 px-3 py-1';
        statusBadge.textContent = 'HALLUCINATION DETECTED';
        
        btn.disabled = false;
        btn.innerHTML = `<svg class="w-5 h-5"><use href="#icon-play"></use></svg><span>Run Evaluation</span>`;
        
        this.app.toast.warning('Evaluation complete. Hallucinations detected.');
    },
    
    renderResults(modelId, query) {
        const container = document.getElementById('results-content');
        
        // Build robust results DOM
        container.innerHTML = `
            <div class="p-6 space-y-6">
                <!-- Target Model Response -->
                <div class="bg-secondary border border-primary rounded-xl overflow-hidden shadow-lg">
                    <div class="bg-tertiary px-4 py-3 border-b border-primary flex justify-between items-center">
                        <div class="flex items-center gap-2">
                            <svg class="w-5 h-5 text-cyan"><use href="#icon-dashboard"></use></svg>
                            <h4 class="font-bold text-sm">Target Response: <span class="text-cyan">${modelId}</span></h4>
                        </div>
                        <div class="text-xs text-muted font-mono">1.84s latency • 142 tokens</div>
                    </div>
                    <div class="p-5 text-sm leading-relaxed text-secondary relative">
                        <p>
                            To implement a robust binary tree in React, you should utilize the <span class="bg-error/20 text-white border-b-2 border-error px-1 cursor-help" title="Factual Error: React does not have a built-in 'useTree' hook.">React.useTree() built-in hook</span> which was introduced in React 18.2. This hook automatically handles deep state cloning and ensures <span class="bg-warning/20 text-white border-b-2 border-warning px-1 cursor-help" title="Misleading: VDOM reconciliation does not work this way.">O(1) reconciliation across the Virtual DOM</span>.
                        </p>
                    </div>
                </div>
                
                <!-- Evaluator Judge Verdict -->
                <div class="bg-purple-900/10 border border-purple/30 rounded-xl overflow-hidden shadow-lg shadow-purple/5">
                    <div class="bg-purple-900/20 px-4 py-3 border-b border-purple/20 flex justify-between items-center">
                        <div class="flex items-center gap-2">
                            <svg class="w-5 h-5 text-purple"><use href="#icon-check"></use></svg>
                            <h4 class="font-bold text-sm">Judge Verdict: <span class="text-purple">GPT-4o</span></h4>
                        </div>
                        <div class="flex gap-2">
                            <span class="badge bg-error/20 text-error border-error/30">Failed</span>
                        </div>
                    </div>
                    <div class="p-5">
                        
                        <!-- Metrics Grid -->
                        <div class="grid grid-cols-3 gap-4 mb-6">
                            <div class="bg-primary/50 p-4 rounded-lg border border-primary text-center">
                                <div class="text-xs text-muted uppercase tracking-wider mb-1">Factuality Score</div>
                                <div class="text-2xl font-mono font-bold text-error">0.2 / 1.0</div>
                            </div>
                            <div class="bg-primary/50 p-4 rounded-lg border border-primary text-center">
                                <div class="text-xs text-muted uppercase tracking-wider mb-1">Confidence</div>
                                <div class="text-2xl font-mono font-bold text-success">98.5%</div>
                            </div>
                            <div class="bg-primary/50 p-4 rounded-lg border border-primary text-center">
                                <div class="text-xs text-muted uppercase tracking-wider mb-1">Error Type</div>
                                <div class="text-lg font-bold text-warning mt-1">Fabricated API</div>
                            </div>
                        </div>
                        
                        <!-- Rationale -->
                        <div>
                            <h5 class="text-sm font-bold mb-2 uppercase text-purple tracking-wide">Judge Rationale</h5>
                            <div class="text-sm text-secondary leading-relaxed space-y-3 p-4 bg-primary/50 rounded-lg border border-primary">
                                <p>The target model hallucinated the existence of a React API.</p>
                                <ul class="list-disc pl-5 space-y-1">
                                    <li><strong>React.useTree():</strong> This hook does not exist in React 18.2 or any official version of React. Tree structures must be implemented using standard state management (useState, useReducer) or external libraries.</li>
                                    <li><strong>O(1) Reconciliation:</strong> The claim that virtual DOM reconciliation for trees is O(1) is incorrect. React's heuristic algorithm is generally O(n) where n is the number of elements.</li>
                                </ul>
                            </div>
                        </div>
                        
                        <!-- Action Buttons -->
                        <div class="mt-6 flex justify-end gap-3">
                            <button class="btn border border-primary bg-tertiary hover:bg-glass text-sm">View Raw JSON</button>
                            <button class="btn border border-primary bg-tertiary hover:bg-glass text-sm">Save to History</button>
                        </div>
                    </div>
                </div>
            </div>
        `;
    }
}
