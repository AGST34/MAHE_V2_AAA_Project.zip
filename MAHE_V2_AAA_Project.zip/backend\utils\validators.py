"""
Validation Utilities Module

Helper functions for validating inputs that aren't easily handled by Pydantic,
or for use in pre-processing before data hits the schemas.
Includes query sanitization, model name verification, and strict type checking.
"""

import re
from fastapi import HTTPException, status
from typing import List

ALLOWED_MODELS = {
    "gpt-4", 
    "gpt-4-turbo", 
    "gpt-3.5-turbo", 
    "gemini-pro", 
    "gemini-1.5-pro", 
    "claude-3-opus", 
    "claude-3-sonnet"
}

def sanitize_input_text(text: str) -> str:
    """
    Cleans up input text by removing non-printable characters 
    and excessive whitespace.
    """
    if not text:
        return ""
    # Remove null bytes
    text = text.replace('\x00', '')
    # Replace multiple spaces with a single space
    text = re.sub(r' {2,}', ' ', text)
    # Strip leading/trailing whitespace
    return text.strip()

def validate_prompt(prompt: str, max_len: int = 15000) -> str:
    """
    Validates and sanitizes a user prompt.
    Raises HTTPException if invalid.
    """
    clean_prompt = sanitize_input_text(prompt)
    if not clean_prompt:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Prompt cannot be empty or just whitespace."
        )
    if len(clean_prompt) > max_len:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Prompt exceeds maximum allowed length of {max_len} characters."
        )
    return clean_prompt

def validate_models_list(models: List[str]) -> List[str]:
    """
    Ensures all requested models are supported by the current configuration.
    """
    if not models:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="At least one model must be specified."
        )
        
    invalid_models = [m for m in models if m not in ALLOWED_MODELS]
    if invalid_models:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Unsupported models detected: {', '.join(invalid_models)}. Supported models: {', '.join(ALLOWED_MODELS)}"
        )
    return models
