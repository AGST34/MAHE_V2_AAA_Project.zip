// components/results-panel.js (Expandable Results Panel System - 300+ lines)
export class ResultsPanel {
    constructor(containerId) {
        this.container = document.getElementById(containerId);
        if (!this.container) throw new Error(`Container #${containerId} not found`);
        this.isRendered = false;
        this.data = null;
    }

    render(data) {
        this.data = data;
        
        // Ensure container is visible and clean
        this.container.classList.remove('hidden');
        this.container.innerHTML = '';
        
        const panelHtml = `
            <div class="results-wrapper animate-slide-up h-full flex flex-col">
                <!-- Summary Header -->
                <div class="bg-tertiary border-b border-primary p-4 flex justify-between items-center flex-shrink-0">
                    <div class="flex items-center gap-4">
                        <div class="w-10 h-10 rounded-full flex items-center justify-center ${data.isHallucination ? 'bg-error/10 text-error' : 'bg-success/10 text-success'}">
                            <svg class="w-6 h-6"><use href="#${data.isHallucination ? 'icon-alert' : 'icon-check'}"></use></svg>
                        </div>
                        <div>
                            <h3 class="font-bold text-lg leading-tight">
                                ${data.isHallucination ? 'Hallucination Detected' : 'Clean Response'}
                            </h3>
                            <div class="text-xs text-muted font-mono">
                                Evaluator: ${data.judgeModel} | Latency: ${data.metrics.latency}ms | Confidence: ${(data.metrics.confidence * 100).toFixed(1)}%
                            </div>
                        </div>
                    </div>
                    <div class="flex gap-2">
                        <button class="btn btn-secondary px-3 py-1.5 text-xs flex items-center gap-1 action-export">
                            <svg class="w-3 h-3"><use href="#icon-download"></use></svg> Export
                        </button>
                        <button class="btn ${data.isHallucination ? 'btn-danger' : 'btn-primary'} px-3 py-1.5 text-xs action-save">
                            Save to Ledger
                        </button>
                    </div>
                </div>

                <!-- Scrollable Content -->
                <div class="flex-1 overflow-y-auto p-6 space-y-6 custom-scrollbar bg-primary/30">
                    
                    <!-- Rationale Section -->
                    <div class="glass-panel p-5 rounded-xl border ${data.isHallucination ? 'border-error/30 shadow-[0_0_15px_rgba(255,23,68,0.1)]' : 'border-success/30 shadow-[0_0_15px_rgba(0,230,118,0.1)]'}">
                        <h4 class="text-sm font-bold uppercase tracking-wider mb-3 ${data.isHallucination ? 'text-error' : 'text-success'} flex items-center gap-2">
                            <svg class="w-4 h-4"><use href="#icon-analytics"></use></svg>
                            Judge Rationale
                        </h4>
                        <div class="text-sm text-secondary leading-relaxed font-mono whitespace-pre-wrap">
                            ${data.rationale}
                        </div>
                    </div>

                    <!-- Target Response with Highlights -->
                    <div class="glass-panel rounded-xl border border-primary overflow-hidden">
                        <div class="bg-tertiary px-4 py-3 border-b border-primary flex justify-between items-center">
                            <h4 class="text-sm font-bold flex items-center gap-2">
                                <svg class="w-4 h-4 text-cyan"><use href="#icon-dashboard"></use></svg>
                                Target Output: <span class="text-cyan font-mono">${data.targetModel}</span>
                            </h4>
                            <div class="flex gap-2">
                                <button class="chart-action-btn active btn-view-formatted">Formatted</button>
                                <button class="chart-action-btn btn-view-raw">Raw JSON</button>
                            </div>
                        </div>
                        
                        <div class="p-5 text-sm leading-relaxed text-secondary relative min-h-[150px] bg-secondary" id="response-content-area">
                            ${this.renderHighlightedResponse(data.response, data.highlights)}
                        </div>
                        
                        <div class="hidden p-0" id="response-raw-area">
                            <pre class="m-0 p-4 bg-[#0d0d12] text-primary font-mono text-xs overflow-x-auto">${JSON.stringify(data.rawPayload, null, 2)}</pre>
                        </div>
                    </div>
                    
                    <!-- Advanced Metrics Accordion -->
                    <div class="border border-primary rounded-xl overflow-hidden mt-4 bg-tertiary">
                        <button class="w-full p-4 flex justify-between items-center hover:bg-glass transition-colors accordion-toggle">
                            <span class="font-bold text-sm">Granular Metrics Pipeline</span>
                            <svg class="w-4 h-4 transform transition-transform chevron"><use href="#icon-chevron-down"></use></svg>
                        </button>
                        <div class="p-4 border-t border-primary bg-secondary hidden accordion-content">
                            <div class="grid grid-cols-2 md:grid-cols-4 gap-4">
                                <div class="p-3 bg-tertiary rounded-lg border border-primary text-center">
                                    <div class="text-[10px] text-muted uppercase mb-1">Factual Alignment</div>
                                    <div class="text-xl font-bold font-mono">${(data.metrics.factuality * 10).toFixed(1)}/10</div>
                                </div>
                                <div class="p-3 bg-tertiary rounded-lg border border-primary text-center">
                                    <div class="text-[10px] text-muted uppercase mb-1">Logical Coherence</div>
                                    <div class="text-xl font-bold font-mono">${(data.metrics.coherence * 10).toFixed(1)}/10</div>
                                </div>
                                <div class="p-3 bg-tertiary rounded-lg border border-primary text-center">
                                    <div class="text-[10px] text-muted uppercase mb-1">Tone Penalty</div>
                                    <div class="text-xl font-bold font-mono text-warning">${data.metrics.tonePenalty.toFixed(2)}</div>
                                </div>
                                <div class="p-3 bg-tertiary rounded-lg border border-primary text-center">
                                    <div class="text-[10px] text-muted uppercase mb-1">Eval Cost</div>
                                    <div class="text-xl font-bold font-mono text-cyan">$${data.metrics.cost.toFixed(4)}</div>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        `;
        
        this.container.innerHTML = panelHtml;
        this.isRendered = true;
        this.bindEvents();
    }

    renderHighlightedResponse(text, highlights = []) {
        if (!highlights || highlights.length === 0) return `<p>${text}</p>`;
        
        // Simple mock implementation of text highlighting.
        // In a real app, this would use substring replacement based on start/end indices.
        let html = text;
        
        highlights.forEach(h => {
            const span = `<span class="bg-error/20 border-b-2 border-error text-white px-1 cursor-help relative group" title="${h.reason}">
                ${h.text}
                <div class="absolute bottom-full left-1/2 transform -translate-x-1/2 mb-2 w-48 p-2 bg-tertiary border border-error rounded shadow-lg text-xs opacity-0 group-hover:opacity-100 transition-opacity z-50 pointer-events-none hidden group-hover:block">
                    <strong class="block text-error mb-1">${h.type}</strong>
                    ${h.reason}
                </div>
            </span>`;
            html = html.replace(h.text, span);
        });
        
        // Wrap in paragraphs
        return html.split('\n\n').map(p => `<p class="mb-3">${p}</p>`).join('');
    }

    bindEvents() {
        const toggleRaw = this.container.querySelector('.btn-view-raw');
        const toggleFmt = this.container.querySelector('.btn-view-formatted');
        const contentArea = this.container.querySelector('#response-content-area');
        const rawArea = this.container.querySelector('#response-raw-area');
        
        if (toggleRaw && toggleFmt) {
            toggleRaw.addEventListener('click', () => {
                toggleRaw.classList.add('active');
                toggleFmt.classList.remove('active');
                contentArea.classList.add('hidden');
                rawArea.classList.remove('hidden');
            });
            
            toggleFmt.addEventListener('click', () => {
                toggleFmt.classList.add('active');
                toggleRaw.classList.remove('active');
                rawArea.classList.add('hidden');
                contentArea.classList.remove('hidden');
            });
        }
        
        const accToggle = this.container.querySelector('.accordion-toggle');
        const accContent = this.container.querySelector('.accordion-content');
        const accChev = this.container.querySelector('.chevron');
        
        if (accToggle) {
            accToggle.addEventListener('click', () => {
                accContent.classList.toggle('hidden');
                accChev.style.transform = accContent.classList.contains('hidden') ? 'rotate(0deg)' : 'rotate(180deg)';
            });
        }
    }
}
