"""
Structured Logger Module

Provides a custom logging setup that outputs logs in JSON format.
This is essential for modern log aggregation tools (Datadog, ELK, Splunk).
Includes ContextVar support for injecting 'correlation_id' across async boundaries.
"""

import json
import logging
import sys
import traceback
from contextvars import ContextVar
from datetime import datetime
from typing import Any, Dict

# Context variable to hold the correlation ID for the current request cycle
correlation_id: ContextVar[str] = ContextVar('correlation_id', default='system-init')

class JSONFormatter(logging.Formatter):
    """
    Custom formatter that dumps log records as a JSON string.
    Automatically includes timestamps, log levels, the logger name, 
    and the active correlation_id.
    """
    def __init__(self, **kwargs):
        super().__init__()
        self.static_fields = kwargs

    def format(self, record: logging.LogRecord) -> str:
        # Base log record structure
        log_data: Dict[str, Any] = {
            "timestamp": datetime.utcnow().isoformat() + "Z",
            "level": record.levelname,
            "message": record.getMessage(),
            "logger_name": record.name,
            "correlation_id": correlation_id.get(),
            "module": record.module,
            "line_no": record.lineno,
        }
        
        # Include custom fields added during instantiation
        log_data.update(self.static_fields)
        
        # Handle exceptions if present
        if record.exc_info:
            log_data["exception"] = {
                "type": record.exc_info[0].__name__ if record.exc_info[0] else "Unknown",
                "message": str(record.exc_info[1]),
                "stack_trace": "".join(traceback.format_exception(*record.exc_info))
            }
            
        # Handle extra arguments passed to logger (e.g., logger.info("msg", extra={"user": "123"}))
        if hasattr(record, "extra") and isinstance(record.extra, dict):
            log_data["extra"] = record.extra
            
        return json.dumps(log_data)

def setup_root_logger(level: str = "INFO", app_name: str = "mahe-v2"):
    """
    Configures the root python logger to use the JSON Formatter.
    Called once during application startup.
    """
    logger = logging.getLogger()
    
    # Remove existing handlers to prevent duplicate logs
    for handler in logger.handlers[:]:
        logger.removeHandler(handler)
        
    log_level = getattr(logging, level.upper(), logging.INFO)
    logger.setLevel(log_level)
    
    # Log to stdout for Docker/Kubernetes best practices
    handler = logging.StreamHandler(sys.stdout)
    
    formatter = JSONFormatter(app=app_name)
    handler.setFormatter(formatter)
    
    logger.addHandler(handler)
    
    return logger

def get_logger(name: str) -> logging.Logger:
    """
    Retrieves a logger instance for a specific module.
    Child loggers inherit the configuration from the root logger.
    """
    return logging.getLogger(name)

def set_correlation_id(c_id: str) -> str:
    """
    Sets the correlation ID for the current context.
    Must be called at the edge of the system (e.g. Middleware).
    """
    correlation_id.set(c_id)
    return c_id

def get_correlation_id() -> str:
    """Retrieves the current correlation ID."""
    return correlation_id.get()
