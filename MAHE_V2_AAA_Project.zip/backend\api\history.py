"""
History API Routes Module

Handles querying, paginating, filtering, and exporting historical evaluations.
Provides detailed endpoints for users to review past AI hallucination checks.
"""

import csv
import io
from datetime import datetime
from typing import Any, Dict, List, Optional

from fastapi import APIRouter, Depends, HTTPException, Query, Response, status
from sqlalchemy import desc, or_, and_
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.future import select
from sqlalchemy.orm import selectinload

from backend.auth import get_current_user
from backend.database import get_db
from backend.models import Evaluation, User
from backend.schemas import EvaluationResponse
from backend.utils.logger import get_logger

logger = get_logger(__name__)
router = APIRouter()

@router.get(
    "", 
    response_model=Dict[str, Any],
    summary="List historical evaluations with pagination and filters"
)
async def list_history(
    skip: int = Query(0, ge=0, description="Pagination offset"),
    limit: int = Query(20, ge=1, le=100, description="Number of records to return"),
    status_filter: Optional[str] = Query(None, description="Filter by evaluation status (e.g., completed)"),
    search: Optional[str] = Query(None, description="Search inside prompt or context"),
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user)
) -> Dict[str, Any]:
    """
    Retrieves a paginated list of evaluation history for the current user.
    """
    # Base query for the user's evaluations
    stmt = select(Evaluation).where(Evaluation.user_id == current_user.id)
    
    # Apply Filters
    if status_filter:
        stmt = stmt.where(Evaluation.status == status_filter)
        
    if search:
        search_term = f"%{search}%"
        stmt = stmt.where(
            or_(
                Evaluation.prompt.ilike(search_term),
                Evaluation.context.ilike(search_term)
            )
        )
        
    # Count total matching records
    # (In a real app, use a dedicated count query for efficiency on large tables)
    count_stmt = stmt
    count_result = await db.execute(count_stmt)
    total_count = len(count_result.scalars().all())
    
    # Apply ordering and pagination
    stmt = stmt.order_by(desc(Evaluation.created_at)).offset(skip).limit(limit)
    
    # Ensure relationships are loaded
    stmt = stmt.options(selectinload(Evaluation.results))
    
    result = await db.execute(stmt)
    evaluations = result.scalars().all()
    
    # Serialize using Pydantic
    serialized = [EvaluationResponse.model_validate(e).model_dump() for e in evaluations]
    
    return {
        "total": total_count,
        "skip": skip,
        "limit": limit,
        "items": serialized
    }

@router.get(
    "/export",
    summary="Export history to CSV"
)
async def export_history_csv(
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """
    Generates and returns a CSV file containing the user's evaluation history
    and scores across all models.
    """
    stmt = select(Evaluation).options(selectinload(Evaluation.results))\
        .where(Evaluation.user_id == current_user.id)\
        .order_by(desc(Evaluation.created_at))
        
    result = await db.execute(stmt)
    evaluations = result.scalars().all()
    
    # Create CSV in memory
    output = io.StringIO()
    writer = csv.writer(output)
    
    # Header
    writer.writerow([
        "Evaluation ID", "Date", "Status", "Prompt", 
        "Agent", "Composite Score", "Hallucination Score", "Coherence", "Factual Accuracy", "Judge Rationale"
    ])
    
    for eval_obj in evaluations:
        date_str = eval_obj.created_at.isoformat() if eval_obj.created_at else ""
        prompt_trunc = eval_obj.prompt[:100] + "..." if len(eval_obj.prompt) > 100 else eval_obj.prompt
        
        if not eval_obj.results:
            writer.writerow([eval_obj.id, date_str, eval_obj.status, prompt_trunc, "N/A", "", "", "", "", ""])
            continue
            
        for res in eval_obj.results:
            writer.writerow([
                eval_obj.id,
                date_str,
                eval_obj.status,
                prompt_trunc,
                res.agent_name,
                f"{res.composite_score:.3f}" if res.composite_score is not None else "",
                f"{res.hallucination_score:.3f}" if res.hallucination_score is not None else "",
                f"{res.coherence_score:.3f}" if res.coherence_score is not None else "",
                f"{res.factual_accuracy:.3f}" if res.factual_accuracy is not None else "",
                res.judge_rationale
            ])
            
    output.seek(0)
    
    filename = f"mahe_export_{datetime.utcnow().strftime('%Y%m%d%H%M%S')}.csv"
    headers = {
        "Content-Disposition": f"attachment; filename={filename}"
    }
    
    return Response(content=output.getvalue(), media_type="text/csv", headers=headers)

@router.delete("/{eval_id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_history_item(
    eval_id: str,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """
    Deletes a specific evaluation from the user's history.
    """
    stmt = select(Evaluation).where(
        and_(Evaluation.id == eval_id, Evaluation.user_id == current_user.id)
    )
    result = await db.execute(stmt)
    eval_obj = result.scalar_one_or_none()
    
    if not eval_obj:
        raise HTTPException(status_code=404, detail="Evaluation not found")
        
    await db.delete(eval_obj)
    await db.commit()
    return None
