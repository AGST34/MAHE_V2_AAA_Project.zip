"""
Pydantic Schemas Module

This module defines all Data Transfer Objects (DTOs) for the application.
It uses Pydantic V2 for strict validation, serialization, and OpenAPI documentation generation.
Includes extensive validators, field constraints, and configuration classes.
"""

from datetime import datetime
from typing import List, Optional, Dict, Any
from pydantic import BaseModel, ConfigDict, EmailStr, Field, field_validator, model_validator


# ==========================================
# Generic / Shared Schemas
# ==========================================

class ErrorResponse(BaseModel):
    """Standard error response schema."""
    detail: str = Field(..., description="A description of the error")
    code: str = Field("ERROR", description="An internal error code")
    timestamp: datetime = Field(default_factory=datetime.utcnow)

    model_config = ConfigDict(
        json_schema_extra={
            "example": {
                "detail": "Resource not found",
                "code": "NOT_FOUND",
                "timestamp": "2026-01-01T12:00:00Z"
            }
        }
    )


# ==========================================
# User Schemas
# ==========================================

class UserBase(BaseModel):
    """Base user properties shared across multiple user schemas."""
    email: EmailStr = Field(..., description="User's email address")
    full_name: Optional[str] = Field(None, description="User's full name", min_length=2, max_length=100)


class UserCreate(UserBase):
    """Schema for creating a new user (Registration)."""
    password: str = Field(..., description="User's password", min_length=8)

    @field_validator('password')
    def validate_password_strength(cls, v: str) -> str:
        """Ensures password meets minimum complexity requirements."""
        if not any(char.isdigit() for char in v):
            raise ValueError('Password must contain at least one digit')
        if not any(char.isupper() for char in v):
            raise ValueError('Password must contain at least one uppercase letter')
        return v


class UserUpdate(BaseModel):
    """Schema for updating user details."""
    full_name: Optional[str] = Field(None, description="Updated full name")
    password: Optional[str] = Field(None, description="New password", min_length=8)
    is_active: Optional[bool] = Field(None, description="Status of the user account")


class UserResponse(UserBase):
    """Schema for returning user data (omits sensitive fields)."""
    id: str = Field(..., description="Unique UUID of the user")
    is_active: bool = Field(..., description="Whether the user is currently active")
    is_superuser: bool = Field(..., description="Whether the user has administrative privileges")
    created_at: datetime = Field(..., description="Timestamp of user creation")

    model_config = ConfigDict(from_attributes=True)


# ==========================================
# Authentication & API Key Schemas
# ==========================================

class Token(BaseModel):
    """Schema for returning a JWT access token."""
    access_token: str = Field(..., description="The JWT access token string")
    token_type: str = Field("bearer", description="The token type")
    expires_in: int = Field(..., description="Expiration time in seconds")


class TokenData(BaseModel):
    """Schema for extracting data from a validated JWT."""
    email: Optional[str] = None
    user_id: Optional[str] = None
    permissions: List[str] = Field(default_factory=list)


class APIKeyCreate(BaseModel):
    """Schema for generating a new API key."""
    name: str = Field(..., description="A friendly name for the API key", min_length=3, max_length=50)
    expires_in_days: Optional[int] = Field(None, description="Optional expiration period in days", ge=1, le=365)


class APIKeyResponse(BaseModel):
    """Schema for returning an API key details."""
    id: str = Field(..., description="Unique identifier of the API key record")
    name: str = Field(..., description="Name of the key")
    key: Optional[str] = Field(None, description="The actual API key. Only returned on creation.")
    is_active: bool = Field(..., description="Whether the key is active")
    created_at: datetime
    expires_at: Optional[datetime]
    last_used_at: Optional[datetime]

    model_config = ConfigDict(from_attributes=True)


# ==========================================
# Evaluation Schemas
# ==========================================

class EvaluationRequest(BaseModel):
    """Schema for submitting a single hallucination evaluation request."""
    prompt: str = Field(..., description="The primary prompt or question to evaluate", min_length=5)
    context: Optional[str] = Field(None, description="Background context for grounding truth")
    models_to_test: List[str] = Field(
        default=["gpt-4", "gemini-pro", "claude-3"],
        description="List of AI models to run the prompt against",
        min_length=1
    )
    temperature: float = Field(default=0.7, description="Temperature setting for generation", ge=0.0, le=2.0)
    
    @field_validator('models_to_test')
    def validate_models(cls, v: List[str]) -> List[str]:
        """Validates that requested models are supported."""
        allowed = {"gpt-4", "gpt-3.5-turbo", "gemini-pro", "claude-3", "claude-3-opus"}
        for model in v:
            if model not in allowed:
                raise ValueError(f"Model '{model}' is not supported. Allowed: {', '.join(allowed)}")
        return v

    model_config = ConfigDict(
        json_schema_extra={
            "example": {
                "prompt": "What are the health benefits of drinking green tea?",
                "context": "Green tea contains antioxidants called catechins...",
                "models_to_test": ["gpt-4", "gemini-pro"],
                "temperature": 0.5
            }
        }
    )


class EvaluationResultSchema(BaseModel):
    """Schema for the results from a single agent evaluation."""
    id: str = Field(..., description="Result ID")
    agent_name: str = Field(..., description="Name of the model/agent that produced the response")
    response_text: str = Field(..., description="The actual generated response")
    
    # Metrics
    hallucination_score: Optional[float] = Field(None, description="Score from 0 to 1 indicating hallucination likelihood")
    coherence_score: Optional[float] = Field(None, description="Score from 0 to 1 indicating logical coherence")
    factual_accuracy: Optional[float] = Field(None, description="Score from 0 to 1 indicating factual alignment with context")
    composite_score: Optional[float] = Field(None, description="Overall weighted score")
    
    judge_rationale: Optional[str] = Field(None, description="Explanation provided by the Judge agent")
    meta_judge_score: Optional[float] = Field(None, description="Confidence score from the Meta-Judge")
    
    # Telemetry
    processing_time_ms: Optional[int] = Field(None, description="Time taken to generate and evaluate")
    tokens_used_total: Optional[int] = Field(None, description="Total tokens consumed by this specific agent")

    model_config = ConfigDict(from_attributes=True)


class EvaluationResponse(BaseModel):
    """Schema for the comprehensive output of an evaluation request."""
    id: str = Field(..., description="Unique evaluation ID")
    prompt: str = Field(..., description="The original prompt")
    context: Optional[str] = Field(None, description="The provided context")
    status: str = Field(..., description="Current status: pending, running, completed, failed")
    error_message: Optional[str] = Field(None, description="Error details if the evaluation failed")
    
    created_at: datetime
    completed_at: Optional[datetime]
    total_processing_time_ms: Optional[int] = Field(None, description="Total time taken across all agents")
    
    results: List[EvaluationResultSchema] = Field(default_factory=list, description="List of results per agent")

    model_config = ConfigDict(from_attributes=True)


class BatchEvaluationRequest(BaseModel):
    """Schema for running multiple evaluations in bulk."""
    evaluations: List[EvaluationRequest] = Field(..., description="List of evaluation requests", max_length=50)
    batch_name: Optional[str] = Field(None, description="An optional name for this batch job")


class BatchEvaluationResponse(BaseModel):
    """Schema for acknowledging a batch submission."""
    batch_id: str = Field(..., description="Identifier for the batch job")
    status: str = Field("accepted", description="Status of the batch submission")
    evaluation_count: int = Field(..., description="Number of evaluations queued")
