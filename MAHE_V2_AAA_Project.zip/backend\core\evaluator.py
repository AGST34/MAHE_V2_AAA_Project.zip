"""
Core Evaluation Pipeline Module

This module defines the `EvaluationPipeline`, a high-level service class that bridges
the API layer with the Agent Orchestrator. It handles database persistence, 
batch processing logic, comparative analysis calculations, and telemetry recording.
"""

import asyncio
import logging
import time
from typing import List, Dict, Any, Optional

from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.future import select
from fastapi import HTTPException

from backend.agents.orchestrator import Orchestrator
from backend.models import Evaluation, EvaluationResult, User
from backend.schemas import (
    EvaluationRequest, 
    EvaluationResponse, 
    EvaluationResultSchema,
    BatchEvaluationRequest
)
from backend.utils.logger import get_logger

logger = get_logger(__name__)

class EvaluationPipeline:
    """
    Manages the lifecycle of evaluation requests, including DB operations,
    orchestrating the agents, and aggregating the final results.
    """
    
    def __init__(self, db: AsyncSession, current_user: Optional[User] = None, room_id: Optional[str] = None):
        """
        Initializes the pipeline.
        
        Args:
            db (AsyncSession): The database session.
            current_user (User, optional): The user initiating the request.
            room_id (str, optional): WebSocket room for live streaming.
        """
        self.db = db
        self.current_user = current_user
        self.room_id = room_id
        self.orchestrator = Orchestrator(room_id=self.room_id)

    async def _create_db_evaluation(self, prompt: str, context: Optional[str]) -> Evaluation:
        """
        Persists a new Evaluation record in the 'pending' state.
        """
        eval_record = Evaluation(
            user_id=self.current_user.id if self.current_user else None,
            prompt=prompt,
            context=context,
            status="running"
        )
        self.db.add(eval_record)
        await self.db.commit()
        await self.db.refresh(eval_record)
        logger.info(f"Created Evaluation record ID: {eval_record.id}")
        return eval_record

    async def _persist_results(self, eval_record: Evaluation, results_schemas: List[EvaluationResultSchema]):
        """
        Translates raw schemas from Orchestrator into SQLAlchemy objects and persists them.
        Updates the parent evaluation record's state based on overall success.
        """
        total_time = 0
        has_error = False
        
        db_results = []
        for res_schema in results_schemas:
            # Handle potential partial failures
            if res_schema.agent_name == "error" or not res_schema.response_text:
                has_error = True
                
            db_res = EvaluationResult(
                evaluation_id=eval_record.id,
                agent_name=res_schema.agent_name,
                response_text=res_schema.response_text,
                hallucination_score=res_schema.hallucination_score,
                coherence_score=res_schema.coherence_score,
                factual_accuracy=res_schema.factual_accuracy,
                composite_score=res_schema.composite_score,
                judge_rationale=res_schema.judge_rationale,
                processing_time_ms=res_schema.processing_time_ms,
                tokens_used_total=res_schema.tokens_used_total
            )
            # Re-calculate composite score if it wasn't provided
            if db_res.composite_score is None:
                db_res.compute_composite_score()
                
            db_results.append(db_res)
            
            if res_schema.processing_time_ms:
                total_time += res_schema.processing_time_ms
                
        self.db.add_all(db_results)
        
        # Update parent record
        eval_record.total_processing_time_ms = total_time
        if has_error:
            eval_record.mark_completed(status="partial_success")
        else:
            eval_record.mark_completed(status="completed")
            
        await self.db.commit()
        logger.info(f"Persisted {len(db_results)} results for Evaluation ID: {eval_record.id}")

    async def run_single_evaluation(self, request: EvaluationRequest) -> EvaluationResponse:
        """
        Runs a standard single prompt evaluation against multiple models.
        
        Args:
            request (EvaluationRequest): The incoming request payload.
            
        Returns:
            EvaluationResponse: The fully populated response.
        """
        logger.info(f"Starting single evaluation pipeline for {len(request.models_to_test)} models.")
        
        # 1. Create DB Record
        eval_record = await self._create_db_evaluation(request.prompt, request.context)
        
        try:
            # 2. Execute Orchestrator
            results = await self.orchestrator.run_evaluation(
                prompt=request.prompt,
                context=request.context,
                models=request.models_to_test
            )
            
            # 3. Save Results
            await self._persist_results(eval_record, results)
            
            # Refresh to ensure relationships are loaded
            await self.db.refresh(eval_record, ["results"])
            
        except Exception as e:
            logger.exception(f"Pipeline failed for Evaluation ID {eval_record.id}")
            eval_record.status = "failed"
            eval_record.error_message = str(e)
            eval_record.completed_at = asyncio.get_event_loop().time()
            await self.db.commit()
            raise HTTPException(status_code=500, detail="Evaluation pipeline failed internally.")

        # 4. Construct Response Schema
        # Using Pydantic's model_validate for ORM conversion
        return EvaluationResponse.model_validate(eval_record)

    async def run_batch_evaluation(self, request: BatchEvaluationRequest) -> Dict[str, Any]:
        """
        Handles batch processing of multiple evaluation prompts.
        In a true production environment, this would likely push to a message queue 
        (e.g., Celery/RabbitMQ) and return a Job ID. Here, we process concurrently 
        up to a certain limit.
        """
        logger.info(f"Starting batch evaluation for {len(request.evaluations)} items.")
        
        # Semaphore to limit massive concurrent blasts that might hit API rate limits
        semaphore = asyncio.Semaphore(5)
        
        async def _bounded_eval(eval_req: EvaluationRequest):
            async with semaphore:
                try:
                    return await self.run_single_evaluation(eval_req)
                except Exception as e:
                    logger.error(f"Batch item failed: {str(e)}")
                    return None
                    
        tasks = [_bounded_eval(req) for req in request.evaluations]
        results = await asyncio.gather(*tasks)
        
        successful = [r for r in results if r is not None]
        
        return {
            "status": "batch_completed",
            "total_requested": len(request.evaluations),
            "total_successful": len(successful),
            "failed": len(request.evaluations) - len(successful),
            "results_ids": [r.id for r in successful]
        }

    async def run_comparative_analysis(self, evaluation_id: str) -> Dict[str, Any]:
        """
        Generates statistical insights and comparative analysis for a completed evaluation.
        Calculates the 'winner', score variances, and highlights strengths/weaknesses.
        
        Args:
            evaluation_id (str): The ID of the evaluation to analyze.
        """
        stmt = select(Evaluation).where(Evaluation.id == evaluation_id)
        result = await self.db.execute(stmt)
        eval_record = result.scalar_one_or_none()
        
        if not eval_record:
            raise HTTPException(status_code=404, detail="Evaluation not found")
            
        if not eval_record.results:
            return {"detail": "No results available for comparison."}
            
        best_overall = None
        best_score = -1.0
        lowest_hallucination = None
        min_h_score = 2.0
        
        rankings = []
        
        for res in eval_record.results:
            # Re-verify composite score
            comp = res.composite_score or 0.0
            h_score = res.hallucination_score or 1.0
            
            rankings.append({
                "agent": res.agent_name,
                "composite": round(comp, 3),
                "hallucination": round(h_score, 3)
            })
            
            if comp > best_score:
                best_score = comp
                best_overall = res.agent_name
                
            if h_score < min_h_score:
                min_h_score = h_score
                lowest_hallucination = res.agent_name
                
        # Sort rankings by composite score descending
        rankings = sorted(rankings, key=lambda x: x["composite"], reverse=True)
        
        return {
            "evaluation_id": evaluation_id,
            "prompt_summary": eval_record.prompt[:50] + "...",
            "analysis": {
                "winner_overall": best_overall,
                "most_grounded": lowest_hallucination, # Lowest hallucination score
                "rankings": rankings
            }
        }
