"""
Resilience & Retry Module

Provides a robust decorator for handling transient failures in network calls
(like AI provider APIs). Implements exponential backoff, jitter, and a basic
circuit breaker pattern to prevent overwhelming failing services.
"""

import asyncio
import logging
import random
from functools import wraps
from typing import Callable, Any, Type, Tuple

logger = logging.getLogger(__name__)

class CircuitBreakerOpenException(Exception):
    """Raised when the circuit breaker prevents a call to a failing service."""
    pass

class CircuitBreaker:
    """
    A simple circuit breaker implementation.
    If a service fails `failure_threshold` times consecutively, the circuit 'opens'.
    Subsequent calls will instantly fail for `recovery_timeout` seconds, after which
    it 'half-opens' and tries again.
    """
    def __init__(self, failure_threshold: int = 5, recovery_timeout: float = 60.0):
        self.failure_threshold = failure_threshold
        self.recovery_timeout = recovery_timeout
        self.failures = 0
        self.last_failure_time = 0.0
        self.state = "CLOSED" # CLOSED, OPEN, HALF_OPEN
        self.lock = asyncio.Lock()

    async def record_failure(self):
        async with self.lock:
            self.failures += 1
            if self.failures >= self.failure_threshold:
                self.state = "OPEN"
                self.last_failure_time = asyncio.get_event_loop().time()
                logger.warning(f"Circuit Breaker TRIPPED (OPEN) after {self.failures} failures.")

    async def record_success(self):
        async with self.lock:
            if self.state != "CLOSED":
                logger.info("Circuit Breaker RESET (CLOSED). Service recovered.")
            self.failures = 0
            self.state = "CLOSED"

    async def check_state(self):
        async with self.lock:
            if self.state == "OPEN":
                now = asyncio.get_event_loop().time()
                if (now - self.last_failure_time) > self.recovery_timeout:
                    self.state = "HALF_OPEN"
                    logger.info("Circuit Breaker HALF_OPEN. Testing service...")
                else:
                    raise CircuitBreakerOpenException("Service is currently unavailable (Circuit Open)")

# Global registry of circuit breakers per provider
circuit_breakers = {}

def get_breaker(service_name: str) -> CircuitBreaker:
    if service_name not in circuit_breakers:
        circuit_breakers[service_name] = CircuitBreaker()
    return circuit_breakers[service_name]

def with_retry(
    max_retries: int = 3, 
    base_delay: float = 1.0, 
    max_delay: float = 20.0, 
    jitter: bool = True,
    service_name: str = "default",
    exceptions: Tuple[Type[Exception], ...] = (Exception,)
):
    """
    Decorator that retries an async function upon failure with exponential backoff.
    Integrates with the CircuitBreaker pattern.
    """
    breaker = get_breaker(service_name)
    
    def decorator(func: Callable):
        @wraps(func)
        async def wrapper(*args, **kwargs) -> Any:
            retries = 0
            while True:
                # 1. Check Circuit Breaker
                await breaker.check_state()
                
                try:
                    # 2. Execute
                    result = await func(*args, **kwargs)
                    
                    # 3. Record Success
                    await breaker.record_success()
                    return result
                    
                except exceptions as e:
                    retries += 1
                    await breaker.record_failure()
                    
                    if retries > max_retries:
                        logger.error(f"Max retries ({max_retries}) reached for {func.__name__}")
                        raise e
                    
                    # Calculate Delay
                    delay = min(base_delay * (2 ** (retries - 1)), max_delay)
                    if jitter:
                        # Full Jitter algorithm
                        delay = random.uniform(0, delay)
                        
                    logger.warning(
                        f"Retry {retries}/{max_retries} for {func.__name__} "
                        f"in {delay:.2f}s. Error: {str(e)}"
                    )
                    await asyncio.sleep(delay)
        return wrapper
    return decorator
