"""
MAHE V2 CLI Application

A comprehensive command-line interface for the Multi-Agent Hallucination Evaluator.
Provides rich terminal outputs, progress tracking, batch processing capabilities,
and historical data viewing using Typer and Rich.
"""

import asyncio
import json
import os
import sys
from datetime import datetime
from pathlib import Path
from typing import List, Optional

import typer
from rich.console import Console
from rich.panel import Panel
from rich.progress import (
    BarColumn,
    Progress,
    SpinnerColumn,
    TextColumn,
    TimeElapsedColumn,
)
from rich.table import Table
from rich import print as rprint
from rich.syntax import Syntax

# Import backend modules
# (In a real scenario, the CLI might communicate over HTTP to the FastAPI server, 
# but for local tool usage, we can hook into the ORM/core directly or use HTTPx. 
# Here we'll simulate direct core integration for robustness).
from backend.agents.orchestrator import Orchestrator
from backend.config import settings
from backend.schemas import EvaluationResultSchema

# Initialize Typer App and Rich Console
app = typer.Typer(
    name="mahe",
    help="MAHE V2 - Multi-Agent Hallucination Evaluator command-line interface.",
    no_args_is_help=True,
    add_completion=False
)
console = Console()

# ==========================================
# Helpers
# ==========================================

def render_json(data: dict) -> None:
    """Renders formatted JSON to the console."""
    json_str = json.dumps(data, indent=2)
    syntax = Syntax(json_str, "json", theme="monokai", line_numbers=True)
    console.print(syntax)


def display_results_table(results: List[EvaluationResultSchema], prompt: str) -> None:
    """
    Renders a rich table comparing the results of different agents.
    """
    console.print(Panel(f"[bold italic]{prompt}[/bold italic]", title="[bold blue]Evaluated Prompt[/bold blue]"))
    
    table = Table(title="Evaluation Results Matrix", show_header=True, header_style="bold magenta")
    table.add_column("Agent Model", style="cyan", no_wrap=True)
    table.add_column("Response Time", justify="right", style="green")
    table.add_column("Composite", justify="right", style="bold yellow")
    table.add_column("Hallucination", justify="right", style="red")
    table.add_column("Coherence", justify="right", style="blue")
    table.add_column("Factual", justify="right", style="green")
    
    for r in results:
        # Format scores, handling None values gracefully
        comp_str = f"{r.composite_score:.2f}" if r.composite_score is not None else "N/A"
        hal_str = f"{r.hallucination_score:.2f}" if r.hallucination_score is not None else "N/A"
        coh_str = f"{r.coherence_score:.2f}" if r.coherence_score is not None else "N/A"
        fac_str = f"{r.factual_accuracy:.2f}" if r.factual_accuracy is not None else "N/A"
        time_str = f"{r.processing_time_ms}ms" if r.processing_time_ms else "Error"
        
        table.add_row(
            r.agent_name,
            time_str,
            comp_str,
            hal_str,
            coh_str,
            fac_str
        )
        
    console.print(table)
    
    # Render rationales separately since they are long
    console.print("\n[bold]Judge Rationales:[/bold]")
    for r in results:
        console.print(f"[bold cyan]{r.agent_name}[/bold cyan]: {r.judge_rationale or 'No rationale provided.'}")
        console.print("-" * 40)


# ==========================================
# Commands
# ==========================================

@app.command("eval")
def evaluate_prompt(
    prompt: str = typer.Argument(..., help="The primary prompt to evaluate against multiple LLMs."),
    context: Optional[str] = typer.Option(None, "--context", "-c", help="Ground truth context for factual checking."),
    models: str = typer.Option(
        "gpt-4,gemini-pro,claude-3", 
        "--models", 
        "-m", 
        help="Comma-separated list of models to evaluate."
    ),
    export: Optional[Path] = typer.Option(None, "--export", "-e", help="Path to export results as JSON.")
):
    """
    Run an immediate evaluation against a list of models and judge their hallucination levels.
    """
    model_list = [m.strip() for m in models.split(",")]
    
    async def _run_eval():
        # Setup rich progress bar
        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            BarColumn(),
            TimeElapsedColumn(),
            console=console
        ) as progress:
            
            task = progress.add_task(f"[cyan]Evaluating prompt across {len(model_list)} models...", total=100)
            
            # Instantiate orchestrator
            orchestrator = Orchestrator()
            
            # We don't have true granular async hooks into the orchestrator for this CLI progress bar 
            # without web-sockets, so we'll just fake a 50% advance before awaiting.
            progress.update(task, advance=20)
            
            try:
                results = await orchestrator.run_evaluation(prompt, context, model_list)
                progress.update(task, completed=100)
            except Exception as e:
                console.print(f"[bold red]Error during evaluation:[/] {str(e)}")
                sys.exit(1)
                
        # Display the rich output
        display_results_table(results, prompt)
        
        # Export logic
        if export:
            try:
                export_data = {
                    "timestamp": datetime.utcnow().isoformat(),
                    "prompt": prompt,
                    "context": context,
                    "results": [r.model_dump() for r in results]
                }
                with open(export, "w", encoding="utf-8") as f:
                    json.dump(export_data, f, indent=2)
                console.print(f"[bold green]Successfully exported results to {export}[/bold green]")
            except Exception as e:
                console.print(f"[bold red]Failed to export results:[/] {str(e)}")

    # Execute async loop
    asyncio.run(_run_eval())


@app.command("batch")
def evaluate_batch(
    file_path: Path = typer.Argument(..., help="Path to a JSON file containing an array of evaluation requests."),
    output_dir: Path = typer.Option(Path("./results"), "--output", "-o", help="Directory to save batch results.")
):
    """
    Process multiple evaluation requests from a JSON file.
    Expects format: [{"prompt": "...", "context": "...", "models": [...]}, ...]
    """
    if not file_path.exists():
        console.print(f"[bold red]Error:[/] File {file_path} does not exist.")
        raise typer.Exit(code=1)
        
    try:
        with open(file_path, "r", encoding="utf-8") as f:
            batch_data = json.load(f)
    except Exception as e:
        console.print(f"[bold red]Error parsing JSON:[/] {str(e)}")
        raise typer.Exit(code=1)
        
    if not isinstance(batch_data, list):
        console.print("[bold red]Error:[/] Batch file must contain a JSON array of requests.")
        raise typer.Exit(code=1)

    output_dir.mkdir(parents=True, exist_ok=True)
    
    async def _run_batch():
        orchestrator = Orchestrator()
        
        with Progress(console=console) as progress:
            task = progress.add_task("[cyan]Processing batch...", total=len(batch_data))
            
            for i, req in enumerate(batch_data):
                prompt = req.get("prompt")
                context = req.get("context")
                models = req.get("models", ["gpt-4", "gemini-pro"])
                
                if not prompt:
                    console.print(f"[yellow]Warning:[/] Skipping item {i} (no prompt found).")
                    progress.advance(task)
                    continue
                    
                results = await orchestrator.run_evaluation(prompt, context, models)
                
                # Save individual result
                out_file = output_dir / f"result_{i}_{int(datetime.utcnow().timestamp())}.json"
                with open(out_file, "w") as f:
                    json.dump({
                        "prompt": prompt,
                        "context": context,
                        "results": [r.model_dump() for r in results]
                    }, f, indent=2)
                    
                progress.advance(task)
                
        console.print(f"[bold green]Batch processing complete. Results saved to {output_dir}/[/bold green]")

    asyncio.run(_run_batch())


@app.command("config")
def view_config(
    reveal_secrets: bool = typer.Option(False, "--reveal-secrets", help="Show sensitive keys in plaintext.")
):
    """
    View the current application configuration and environment variables.
    """
    console.print("[bold blue]MAHE V2 Configuration[/bold blue]")
    
    # We dump the settings dict
    config_dict = settings.model_dump()
    
    if not reveal_secrets:
        # Mask sensitive keys
        for key in ["SECRET_KEY", "OPENAI_API_KEY", "GEMINI_API_KEY", "ANTHROPIC_API_KEY", "DATABASE_URL"]:
            if config_dict.get(key):
                val = str(config_dict[key])
                config_dict[key] = val[:4] + "*" * (len(val) - 8) + val[-4:] if len(val) > 8 else "****"

    render_json(config_dict)


@app.command("history")
def view_history(
    limit: int = typer.Option(10, "--limit", "-l", help="Number of recent evaluations to show."),
    user_id: Optional[str] = typer.Option(None, "--user", "-u", help="Filter by specific User ID.")
):
    """
    View recent evaluation history from the database.
    (Requires direct database access).
    """
    console.print(f"[bold cyan]Fetching last {limit} evaluations...[/bold cyan]")
    # In a full CLI, this would query the DB using async SQLAlchemy
    console.print("[yellow]Note: History fetching via CLI directly connecting to DB is a stub in this version. Use the API endpoint /history.[/yellow]")


if __name__ == "__main__":
    app()
