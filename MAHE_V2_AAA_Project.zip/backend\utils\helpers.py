"""
Miscellaneous Helper Utilities

Includes functions for text manipulation (truncation), token counting (using mock tiktoken),
hash generation, and a performance timing context manager.
"""

import hashlib
import time
import uuid
import logging
from contextlib import contextmanager
from typing import Optional

logger = logging.getLogger(__name__)

def truncate_text(text: str, max_length: int = 100, suffix: str = "...") -> str:
    """
    Safely truncates a string to a maximum length.
    Ensures that trailing whitespaces are removed before appending the suffix.
    
    Args:
        text: The input text.
        max_length: Maximum allowed length.
        suffix: String to append if truncated.
        
    Returns:
        Truncated string.
    """
    if not text:
        return ""
    if len(text) <= max_length:
        return text
    return text[:max_length].rstrip() + suffix

def estimate_tokens(text: str, provider: str = "openai") -> int:
    """
    Estimates the number of tokens in a string.
    In a real app, this would use `tiktoken` for OpenAI and `anthropic`'s tokenizer for Claude.
    
    Args:
        text: Input string.
        provider: Which tokenizer heuristic to use.
        
    Returns:
        Estimated token count.
    """
    if not text:
        return 0
        
    # Heuristics based on common english tokenization
    # OpenAI/Claude usually average 4 chars per token.
    length = len(text)
    
    if provider == "openai":
        # Simulate tiktoken cl100k_base
        return int(length / 3.8)
    elif provider == "claude":
        return int(length / 3.5)
    else:
        return int(length / 4.0)

def generate_secure_hash(data: str, salt: Optional[str] = None) -> str:
    """
    Generates a secure SHA-256 hash.
    Useful for anonymizing data or creating cache keys.
    """
    if salt is None:
        salt = str(uuid.uuid4())
    
    encoded = f"{salt}:{data}".encode('utf-8')
    return hashlib.sha256(encoded).hexdigest()

@contextmanager
def timing_block(description: str):
    """
    A context manager to easily time blocks of synchronous code.
    Logs the duration upon completion.
    
    Usage:
        with timing_block("Database Query"):
            # do work
    """
    start_time = time.perf_counter()
    try:
        yield
    finally:
        end_time = time.perf_counter()
        duration_ms = (end_time - start_time) * 1000
        logger.debug(f"[TIMING] {description} took {duration_ms:.2f}ms")

class AsyncTimer:
    """
    Async equivalent of the timing block, useful for wrapping await calls.
    
    Usage:
        async with AsyncTimer("API Call"):
            await client.get()
    """
    def __init__(self, description: str):
        self.description = description
        
    async def __aenter__(self):
        self.start_time = time.perf_counter()
        return self
        
    async def __aexit__(self, exc_type, exc_val, exc_tb):
        end_time = time.perf_counter()
        duration_ms = (end_time - self.start_time) * 1000
        logger.debug(f"[ASYNC TIMING] {self.description} took {duration_ms:.2f}ms")
