"""
Metrics Calculation Module

Handles complex formulas and weights for calculating aggregate evaluation scores.
Defines strict definitions for hallucination, coherence, and factual accuracy calculations.
"""

from pydantic import BaseModel, Field

class MetricsDefinition(BaseModel):
    """
    Data structure holding all independent metric components.
    """
    hallucination: float = Field(..., ge=0.0, le=1.0)
    coherence: float = Field(..., ge=0.0, le=1.0)
    factual_accuracy: float = Field(..., ge=0.0, le=1.0)


class ScoringWeights:
    """
    Configurable weights for the composite score calculation.
    Adjusting these allows tuning the system to penalize hallucinations more aggressively.
    """
    HALLUCINATION_PENALTY = 0.6  # Heavy penalty for hallucinating
    COHERENCE_WEIGHT = 0.3      # Medium importance on readability
    FACTUAL_WEIGHT = 0.7        # High importance on factual correctness

    @classmethod
    def calculate_composite(cls, metrics: MetricsDefinition) -> float:
        """
        Calculates the final score based on configured weights.
        The formula ensures the score remains between 0.0 (terrible) and 1.0 (perfect).
        
        A high hallucination score acts as a direct penalty to the base factual/coherence score.
        """
        # Base positive score (Max possible is 1.0 since weights sum to 1.0)
        # Actually, let's normalize the positive weights:
        total_positive_weight = cls.COHERENCE_WEIGHT + cls.FACTUAL_WEIGHT
        base_score = (
            (metrics.coherence * cls.COHERENCE_WEIGHT) +
            (metrics.factual_accuracy * cls.FACTUAL_WEIGHT)
        ) / total_positive_weight
        
        # Apply hallucination penalty
        penalty = metrics.hallucination * cls.HALLUCINATION_PENALTY
        
        final_score = base_score - penalty
        
        # Clamp to bounds
        return max(0.0, min(1.0, final_score))

def analyze_variance(results: list) -> float:
    """
    Calculates the variance in hallucination scores across a batch of agents.
    Useful for determining if a prompt is highly volatile.
    """
    if not results or len(results) < 2:
        return 0.0
        
    scores = [r.hallucination_score for r in results if getattr(r, 'hallucination_score', None) is not None]
    if len(scores) < 2:
        return 0.0
        
    mean = sum(scores) / len(scores)
    variance = sum((x - mean) ** 2 for x in scores) / len(scores)
    return variance
