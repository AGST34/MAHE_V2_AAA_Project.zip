// components/navbar.js (Detailed Navbar integration)
export function initNavbar(app) {
    const navbar = app.ui.navbar || document.getElementById('navbar');
    if (!navbar) return;
    
    // Theme toggle injection (assuming we added a button in index.html, if not we create one)
    const navRight = navbar.querySelector('.navbar-right');
    if (navRight) {
        const themeBtn = document.createElement('button');
        themeBtn.className = 'action-btn mr-2';
        themeBtn.title = 'Toggle Theme';
        themeBtn.innerHTML = `<svg class="icon"><use href="#icon-refresh"></use></svg>`; // using refresh icon as placeholder for theme
        
        themeBtn.addEventListener('click', () => {
            const current = window.store.getState().ui.theme;
            window.store.setState({
                ui: {
                    ...window.store.getState().ui,
                    theme: current === 'dark' ? 'light' : 'dark'
                }
            });
        });
        
        // Insert before notification bell
        const notifWrapper = navRight.querySelector('.notification-wrapper');
        if (notifWrapper) {
            navRight.insertBefore(themeBtn, notifWrapper);
        } else {
            navRight.appendChild(themeBtn);
        }
    }

    // Global Search behavior
    const searchInput = app.ui.globalSearch;
    if (searchInput) {
        let searchTimeout;
        searchInput.addEventListener('input', (e) => {
            const query = e.target.value.trim();
            if (searchTimeout) clearTimeout(searchTimeout);
            
            if (query.length === 0) {
                // Clear search results overlay (implementation left for scale)
                return;
            }
            
            searchTimeout = setTimeout(() => {
                // Trigger global search event
                app.events.emit('ui:global_search', query);
                
                // For demo, just show a toast if searching "error"
                if (query.toLowerCase().includes('error')) {
                    app.toast.warning(`Found 3 error logs matching "${query}"`);
                }
            }, 500);
        });
        
        searchInput.addEventListener('keydown', (e) => {
            if (e.key === 'Enter') {
                const query = e.target.value.trim();
                if (query) {
                    app.router.navigate(`/history?q=${encodeURIComponent(query)}`);
                    e.target.blur();
                    e.target.value = '';
                }
            }
        });
    }
}
