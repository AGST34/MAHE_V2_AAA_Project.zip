"""
Gemini Agent Module

Provides the complete integration with Google's Gemini API (formerly MakerSuite).
Implements streaming, structured outputs, safety settings, and robust error handling
by extending the BaseAgent class.
"""

import asyncio
import json
import logging
from typing import Any, AsyncGenerator, Dict, List, Optional

# In a real scenario, this would be: import google.generativeai as genai
# We simulate the SDK structure for this implementation.
class MockGenAI:
    class GenerativeModel:
        def __init__(self, model_name: str, generation_config: dict = None, safety_settings: list = None):
            self.model_name = model_name
            self.generation_config = generation_config or {}
            self.safety_settings = safety_settings or []
            
        async def generate_content_async(self, contents: list, stream: bool = False):
            await asyncio.sleep(1.0)
            if stream:
                # Mock streaming response
                class StreamChunk:
                    def __init__(self, text):
                        self.text = text
                
                async def mock_stream():
                    words = "This is a mock streaming response from Gemini based on the prompt.".split()
                    for word in words:
                        yield StreamChunk(word + " ")
                        await asyncio.sleep(0.1)
                return mock_stream()
            else:
                class MockResponse:
                    @property
                    def text(self):
                        return "This is a complete mock response from Gemini."
                return MockResponse()

genai_mock = MockGenAI()

from backend.agents.base import BaseAgent
from backend.config import settings

logger = logging.getLogger(__name__)

class GeminiAgent(BaseAgent):
    """
    Agent implementation for Google's Gemini models.
    Supports gemini-pro, gemini-1.5-pro, etc.
    """

    def __init__(self, model: str = "gemini-pro", temperature: float = 0.7, max_tokens: int = 2048):
        """
        Initializes the Gemini agent with appropriate API keys and configurations.
        """
        super().__init__(name="gemini", model=model, temperature=temperature, max_tokens=max_tokens)
        
        self.api_key = settings.GEMINI_API_KEY
        if not self.api_key:
            logger.warning("GEMINI_API_KEY is not set. The agent will fail in production.")
            
        # Default safety settings - blocks only high-risk content
        self.safety_settings = [
            {"category": "HARM_CATEGORY_HARASSMENT", "threshold": "BLOCK_ONLY_HIGH"},
            {"category": "HARM_CATEGORY_HATE_SPEECH", "threshold": "BLOCK_ONLY_HIGH"},
            {"category": "HARM_CATEGORY_SEXUALLY_EXPLICIT", "threshold": "BLOCK_ONLY_HIGH"},
            {"category": "HARM_CATEGORY_DANGEROUS_CONTENT", "threshold": "BLOCK_ONLY_HIGH"},
        ]
        
        self.generation_config = {
            "temperature": self.temperature,
            "top_p": 0.95,
            "top_k": 40,
            "max_output_tokens": self.max_tokens,
        }
        
        self._client = None
        
    def _get_client(self):
        """Lazy initialization of the client."""
        if not self._client:
            # genai.configure(api_key=self.api_key)
            self._client = genai_mock.GenerativeModel(
                model_name=self.model,
                generation_config=self.generation_config,
                safety_settings=self.safety_settings
            )
        return self._client

    def _format_prompt(self, prompt: str, context: Optional[str] = None) -> List[Dict[str, str]]:
        """
        Formats the prompt and context into the structure expected by Gemini.
        """
        parts = []
        if context:
            parts.append({
                "role": "user",
                "parts": [f"Background context information:\n{context}\n\nPlease strictly use this context to answer the following prompt."]
            })
            parts.append({
                "role": "model",
                "parts": ["I understand. I will use the provided context to answer the prompt accurately."]
            })
            
        parts.append({
            "role": "user",
            "parts": [prompt]
        })
        return parts

    async def generate_response(self, prompt: str, context: Optional[str] = None) -> str:
        """
        Generates a complete response block from Gemini.
        
        Args:
            prompt: User prompt.
            context: Grounding context.
            
        Returns:
            The raw text string.
        """
        client = self._get_client()
        formatted_contents = self._format_prompt(prompt, context)
        
        try:
            logger.debug(f"Sending request to Gemini model {self.model}")
            response = await client.generate_content_async(contents=formatted_contents, stream=False)
            return response.text
        except Exception as e:
            logger.error(f"Gemini API Error: {str(e)}")
            raise ValueError(f"Failed to generate from Gemini: {str(e)}")

    async def stream_response(self, prompt: str, context: Optional[str] = None) -> AsyncGenerator[str, None]:
        """
        Streams the response token-by-token.
        """
        client = self._get_client()
        formatted_contents = self._format_prompt(prompt, context)
        
        try:
            response_stream = await client.generate_content_async(contents=formatted_contents, stream=True)
            async for chunk in response_stream:
                if hasattr(chunk, 'text') and chunk.text:
                    yield chunk.text
        except Exception as e:
            logger.error(f"Gemini Streaming Error: {str(e)}")
            yield f"\n[Streaming Interrupted: {str(e)}]"
            
    async def generate_structured(self, prompt: str, schema: Dict[str, Any], context: Optional[str] = None) -> Dict[str, Any]:
        """
        Attempts to force Gemini to return JSON matching a specific schema.
        Since native JSON mode might not be available on all models, we prompt engineer it.
        """
        schema_str = json.dumps(schema, indent=2)
        json_prompt = (
            f"{prompt}\n\n"
            f"You MUST return the output ONLY as raw, valid JSON matching the following schema:\n"
            f"{schema_str}\n\n"
            "Do not include markdown blocks, just the JSON string."
        )
        
        raw_text = await self.generate_response(json_prompt, context)
        
        # Cleanup potential markdown
        cleaned = raw_text.strip()
        if cleaned.startswith("```json"):
            cleaned = cleaned[7:]
        if cleaned.startswith("```"):
            cleaned = cleaned[3:]
        if cleaned.endswith("```"):
            cleaned = cleaned[:-3]
            
        return json.loads(cleaned.strip())
