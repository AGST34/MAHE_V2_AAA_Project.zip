"""
Database Configuration and Session Management Module

This module sets up the asynchronous SQLAlchemy engine, session factory, and declarative base.
It includes mixins for common attributes (like timestamps and IDs), connection pooling configurations,
and health check utilities to ensure database connectivity.
"""

import logging
import uuid
from datetime import datetime
from typing import AsyncGenerator, Any, Dict

from sqlalchemy import Column, DateTime, String
from sqlalchemy.exc import SQLAlchemyError
from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker, create_async_engine
from sqlalchemy.ext.declarative import declared_attr
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column
from sqlalchemy import text

from backend.config import settings

logger = logging.getLogger(__name__)

# Engine configuration parameters
engine_kwargs = {
    "echo": settings.DEBUG,
    "future": True,
}

# Add SQLite specific configuration if using SQLite
if settings.DATABASE_URL and settings.DATABASE_URL.startswith("sqlite"):
    engine_kwargs["connect_args"] = {"check_same_thread": False}
else:
    # Postgres/MySQL specific pooling configurations
    engine_kwargs.update({
        "pool_size": settings.DB_POOL_SIZE,
        "max_overflow": settings.DB_MAX_OVERFLOW,
        "pool_pre_ping": True,  # Enable connection health checks
    })

# Create the asynchronous engine
try:
    engine = create_async_engine(settings.DATABASE_URL, **engine_kwargs)
    logger.info(f"Database engine created successfully for {settings.DATABASE_URL.split('://')[0]}")
except Exception as e:
    logger.critical(f"Failed to create database engine: {str(e)}")
    raise

# Create the session factory
async_session_maker = async_sessionmaker(
    engine, 
    class_=AsyncSession, 
    expire_on_commit=False,
    autoflush=False
)


class Base(DeclarativeBase):
    """
    Base class for all SQLAlchemy declarative models.
    Provides utility methods and common configurations for all models.
    """
    
    @declared_attr.directive
    def __tablename__(cls) -> str:
        """Automatically generates table names from class names (pluralized loosely)."""
        return cls.__name__.lower() + "s"

    def to_dict(self) -> Dict[str, Any]:
        """
        Converts the SQLAlchemy model instance into a dictionary.
        This is useful for serialization and debugging.
        """
        return {
            column.name: getattr(self, column.name)
            for column in self.__table__.columns
        }

    def __repr__(self) -> str:
        """Provides a standard string representation for all models."""
        attrs = ", ".join(f"{k}={v!r}" for k, v in self.to_dict().items() if not k.startswith("_"))
        return f"<{self.__class__.__name__}({attrs})>"


class TimestampMixin:
    """
    Mixin that adds created_at and updated_at columns to a model.
    Automatically handles setting the updated_at timestamp on updates.
    """
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), 
        default=datetime.utcnow, 
        nullable=False
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), 
        default=datetime.utcnow, 
        onupdate=datetime.utcnow, 
        nullable=False
    )


class UUIDMixin:
    """
    Mixin that adds a UUID primary key to a model.
    """
    id: Mapped[str] = mapped_column(
        String(36), 
        primary_key=True, 
        default=lambda: str(uuid.uuid4()), 
        index=True
    )


async def get_db() -> AsyncGenerator[AsyncSession, None]:
    """
    FastAPI dependency that provides an asynchronous database session.
    Ensures the session is properly closed after the request is processed,
    and handles automatic rollback in case of an unhandled exception.
    """
    async with async_session_maker() as session:
        try:
            yield session
            # Attempt to commit any pending transactions
            await session.commit()
        except SQLAlchemyError as db_exc:
            # Log the database error and rollback
            logger.error(f"Database error occurred: {str(db_exc)}. Rolling back transaction.")
            await session.rollback()
            raise
        except Exception as exc:
            # Catch any other unexpected exceptions and rollback
            logger.error(f"Unexpected error during request: {str(exc)}. Rolling back transaction.")
            await session.rollback()
            raise
        finally:
            # Ensure the session is always closed
            await session.close()


async def check_database_health() -> bool:
    """
    Utility function to check if the database is reachable.
    Can be used by health check endpoints.
    
    Returns:
        bool: True if the database is reachable, False otherwise.
    """
    try:
        async with engine.connect() as conn:
            await conn.execute(text("SELECT 1"))
        return True
    except Exception as e:
        logger.error(f"Database health check failed: {str(e)}")
        return False
