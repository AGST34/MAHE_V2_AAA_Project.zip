// websocket.js (Expanded WebSocket client with queue, heartbeat, and reconnection)
export class Socket {
    constructor(url, appInstance) {
        this.url = url;
        this.app = appInstance;
        this.ws = null;
        
        this.reconnectAttempts = 0;
        this.maxReconnectAttempts = 7;
        this.reconnectBaseDelay = 1000;
        
        this.isConnected = false;
        this.isConnecting = false;
        
        this.heartbeatInterval = null;
        this.pingTimeout = null;
        
        this.messageQueue = [];
        this.eventListeners = new Map();
        
        this.bindEvents();
    }

    bindEvents() {
        // Expose a public API for components to listen to WS events
        this.on('eval_progress', this.handleEvalProgress.bind(this));
        this.on('notification', this.handleNotification.bind(this));
    }

    connect() {
        if (this.isConnected || this.isConnecting) return;
        
        this.isConnecting = true;
        console.log(`[WS] Attempting connection to ${this.url}`);
        
        try {
            // For this frontend-only build, we will simulate the WebSocket
            // In production, this would be: this.ws = new WebSocket(this.url);
            
            // --- MOCK WEBSOCKET IMPLEMENTATION ---
            this.ws = {
                send: (data) => {
                    console.log('[WS Mock Send]', data);
                },
                close: () => {
                    this.onClose({ code: 1000, reason: 'Manual close', wasClean: true });
                },
                readyState: 1 // OPEN
            };
            
            // Simulate async connection success
            setTimeout(() => {
                this.onOpen();
            }, 500);
            
        } catch (error) {
            console.error('[WS] Connection attempt failed:', error);
            this.isConnecting = false;
            this.handleReconnect();
        }
    }

    onOpen() {
        console.log('[WS] Connection established');
        this.isConnected = true;
        this.isConnecting = false;
        this.reconnectAttempts = 0;
        
        // Flush queue
        while (this.messageQueue.length > 0) {
            const msg = this.messageQueue.shift();
            this.send(msg);
        }
        
        this.startHeartbeat();
        this.emit('connected', { timestamp: Date.now() });
    }

    onMessage(event) {
        try {
            const payload = typeof event.data === 'string' ? JSON.parse(event.data) : event.data;
            if (payload.type === 'pong') {
                this.handlePong();
                return;
            }
            
            console.debug('[WS Received]', payload);
            this.emit(payload.type || 'message', payload.data || payload);
            
        } catch (error) {
            console.error('[WS] Failed to parse message', error, event.data);
        }
    }

    onClose(event) {
        console.log(`[WS] Connection closed. Code: ${event.code}, Reason: ${event.reason}`);
        this.isConnected = false;
        this.isConnecting = false;
        this.stopHeartbeat();
        
        this.emit('disconnected', event);
        
        // Don't reconnect on manual close (1000)
        if (event.code !== 1000) {
            this.handleReconnect();
        }
    }

    onError(error) {
        console.error('[WS] Error observed:', error);
        this.emit('error', error);
    }

    handleReconnect() {
        if (this.reconnectAttempts >= this.maxReconnectAttempts) {
            console.error('[WS] Max reconnection attempts reached. Giving up.');
            this.app?.toast.error('Real-time connection lost permanently. Please refresh.');
            return;
        }
        
        this.reconnectAttempts++;
        // Exponential backoff with jitter
        const jitter = Math.random() * 500;
        const delay = Math.min(this.reconnectBaseDelay * Math.pow(1.5, this.reconnectAttempts) + jitter, 15000);
        
        console.log(`[WS] Reconnecting in ${Math.round(delay)}ms (Attempt ${this.reconnectAttempts})`);
        
        setTimeout(() => {
            this.connect();
        }, delay);
    }

    startHeartbeat() {
        this.heartbeatInterval = setInterval(() => {
            if (this.isConnected) {
                this.send({ type: 'ping', timestamp: Date.now() });
                
                // Set timeout waiting for pong
                this.pingTimeout = setTimeout(() => {
                    console.warn('[WS] Ping timeout. Terminating connection.');
                    if (this.ws && typeof this.ws.terminate === 'function') {
                        this.ws.terminate();
                    } else if (this.ws) {
                        this.ws.close();
                    }
                }, 5000);
            }
        }, 30000);
    }

    handlePong() {
        if (this.pingTimeout) {
            clearTimeout(this.pingTimeout);
            this.pingTimeout = null;
        }
    }

    stopHeartbeat() {
        if (this.heartbeatInterval) clearInterval(this.heartbeatInterval);
        if (this.pingTimeout) clearTimeout(this.pingTimeout);
    }

    send(data) {
        const payload = typeof data === 'string' ? data : JSON.parse(data);
        
        if (this.isConnected && this.ws.readyState === 1) {
            this.ws.send(JSON.stringify(payload));
        } else {
            console.debug('[WS] Queueing message (offline)');
            this.messageQueue.push(payload);
        }
    }

    on(event, callback) {
        if (!this.eventListeners.has(event)) {
            this.eventListeners.set(event, []);
        }
        this.eventListeners.get(event).push(callback);
    }

    off(event, callback) {
        if (this.eventListeners.has(event)) {
            const listeners = this.eventListeners.get(event).filter(cb => cb !== callback);
            this.eventListeners.set(event, listeners);
        }
    }

    emit(event, data) {
        if (this.eventListeners.has(event)) {
            this.eventListeners.get(event).forEach(cb => {
                try { cb(data); } catch (e) { console.error(e); }
            });
        }
        // Also emit to global app bus if available
        if (this.app && this.app.events) {
            this.app.events.emit(`ws:${event}`, data);
        }
    }

    // --- Specific Handlers ---
    handleEvalProgress(data) {
        // Route to the active view if it's evaluate
        const currentState = this.app?.store?.getState();
        if (currentState && currentState.ui.activeView === 'evaluate') {
            // Handled by evaluate.js subscribing to this event
        }
    }

    handleNotification(data) {
        this.app?.toast.info(data.message, { title: data.title });
    }
}
