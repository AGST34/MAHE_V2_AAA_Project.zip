"""
Authentication API Routes Module

Handles user registration, JWT generation, login flows, and API Key issuance.
Implements secure password handling and standard OAuth2 compliant structures.
"""

from datetime import timedelta
from typing import Any

from fastapi import APIRouter, Depends, HTTPException, status
from fastapi.security import OAuth2PasswordRequestForm
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.future import select

from backend.auth import (
    authenticate_user, 
    create_access_token, 
    get_current_user,
    get_password_hash
)
from backend.config import settings
from backend.database import get_db
from backend.models import User, APIKey
from backend.schemas import (
    Token, 
    UserCreate, 
    UserResponse,
    APIKeyCreate,
    APIKeyResponse
)
from backend.utils.logger import get_logger

logger = get_logger(__name__)
router = APIRouter()

@router.post("/register", response_model=UserResponse, status_code=status.HTTP_201_CREATED)
async def register_user(user_in: UserCreate, db: AsyncSession = Depends(get_db)) -> Any:
    """
    Registers a new user account. Ensures emails are unique.
    """
    # Check if user exists
    stmt = select(User).where(User.email == user_in.email)
    result = await db.execute(stmt)
    if result.scalar_one_or_none():
        raise HTTPException(
            status_code=400,
            detail="The user with this email already exists in the system.",
        )
        
    # Create user
    user = User(
        email=user_in.email,
        hashed_password=get_password_hash(user_in.password),
        full_name=user_in.full_name,
        is_active=True,
        is_superuser=False # Default to standard user
    )
    db.add(user)
    await db.commit()
    await db.refresh(user)
    
    logger.info(f"New user registered: {user.email}")
    return user

@router.post("/login", response_model=Token)
async def login_access_token(
    db: AsyncSession = Depends(get_db), 
    form_data: OAuth2PasswordRequestForm = Depends()
) -> Any:
    """
    OAuth2 compatible token login, getting an access token for future requests.
    """
    user = await authenticate_user(db, form_data.username, form_data.password)
    if not user:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Incorrect email or password",
            headers={"WWW-Authenticate": "Bearer"},
        )
    elif not user.is_active:
        raise HTTPException(status_code=400, detail="Inactive user account")
        
    # Define scopes (admin vs regular user)
    scopes = ["admin", "me"] if user.is_superuser else ["me"]
        
    access_token_expires = timedelta(minutes=settings.ACCESS_TOKEN_EXPIRE_MINUTES)
    
    access_token = create_access_token(
        subject=user.email, scopes=scopes, expires_delta=access_token_expires
    )
    
    return {
        "access_token": access_token,
        "token_type": "bearer",
        "expires_in": settings.ACCESS_TOKEN_EXPIRE_MINUTES * 60
    }

@router.post("/apikey", response_model=APIKeyResponse, status_code=status.HTTP_201_CREATED)
async def generate_apikey(
    key_in: APIKeyCreate,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user)
) -> Any:
    """
    Generates a long-lived API Key for programmatic access.
    The raw key is only returned ONCE during this creation step.
    """
    import secrets
    
    raw_key = f"mahe_{secrets.token_urlsafe(32)}"
    
    expires = None
    if key_in.expires_in_days:
        expires = datetime.utcnow() + timedelta(days=key_in.expires_in_days)
        
    db_key = APIKey(
        name=key_in.name,
        key=raw_key,
        user_id=current_user.id,
        expires_at=expires
    )
    
    db.add(db_key)
    await db.commit()
    await db.refresh(db_key)
    
    # Return schema requires mapping
    return APIKeyResponse(
        id=db_key.id,
        name=db_key.name,
        key=raw_key, # Expose only once
        is_active=db_key.is_active,
        created_at=db_key.created_at,
        expires_at=db_key.expires_at,
        last_used_at=db_key.last_used_at
    )
