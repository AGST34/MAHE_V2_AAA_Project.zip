"""
Async LRU Cache Module

Implements a thread-safe, asynchronous In-Memory Least Recently Used (LRU) Cache 
with Time-To-Live (TTL) expiration, hit/miss statistics, and dynamic resizing.
Useful for caching repeated identical agent prompts or judge evaluations.
"""

import asyncio
from datetime import datetime, timedelta
from typing import Any, Dict, Optional
import hashlib
import json

class CacheStats:
    """Tracks cache performance metrics."""
    def __init__(self):
        self.hits = 0
        self.misses = 0
        self.evictions = 0
        
    def hit_rate(self) -> float:
        total = self.hits + self.misses
        return (self.hits / total) if total > 0 else 0.0

class AsyncLRUCache:
    """
    Asynchronous LRU Cache implementation with TTL support.
    """
    def __init__(self, maxsize: int = 1000, ttl_seconds: int = 3600):
        self.maxsize = maxsize
        self.ttl = timedelta(seconds=ttl_seconds)
        self.cache: Dict[str, Dict[str, Any]] = {}
        self.lock = asyncio.Lock()
        self.stats = CacheStats()

    @staticmethod
    def generate_key(*args, **kwargs) -> str:
        """
        Generates a deterministic hash key from arguments.
        """
        key_data = {"args": args, "kwargs": kwargs}
        # Sort keys to ensure consistent hashing
        json_str = json.dumps(key_data, sort_keys=True, default=str)
        return hashlib.sha256(json_str.encode('utf-8')).hexdigest()

    async def get(self, key: str) -> Optional[Any]:
        """
        Retrieve an item from the cache. Updates LRU ordering if found and valid.
        """
        async with self.lock:
            if key in self.cache:
                item = self.cache[key]
                if datetime.utcnow() < item['expires_at']:
                    # Move to end (most recently used)
                    val = self.cache.pop(key)
                    self.cache[key] = val
                    self.stats.hits += 1
                    return val['value']
                else:
                    # Expired
                    del self.cache[key]
                    self.stats.evictions += 1
                    
            self.stats.misses += 1
            return None

    async def set(self, key: str, value: Any):
        """
        Insert or update an item in the cache. Evicts oldest if full.
        """
        async with self.lock:
            if key in self.cache:
                del self.cache[key]
            elif len(self.cache) >= self.maxsize:
                # Evict oldest (first item in dict)
                oldest_key = next(iter(self.cache))
                del self.cache[oldest_key]
                self.stats.evictions += 1
                
            self.cache[key] = {
                'value': value,
                'expires_at': datetime.utcnow() + self.ttl
            }

    async def invalidate(self, key: str):
        """Removes a specific key from the cache."""
        async with self.lock:
            if key in self.cache:
                del self.cache[key]

    async def clear(self):
        """Clears the entire cache."""
        async with self.lock:
            self.cache.clear()
            
    def get_stats(self) -> dict:
        """Returns current cache statistics."""
        return {
            "size": len(self.cache),
            "max_size": self.maxsize,
            "hits": self.stats.hits,
            "misses": self.stats.misses,
            "evictions": self.stats.evictions,
            "hit_rate": self.stats.hit_rate()
        }

# Global singleton instance for common usage
app_cache = AsyncLRUCache()
