"""
Streaming & SSE Utilities Module

Helper functions to transform internal async generators into standards-compliant
Server-Sent Events (SSE) for FastAPI's StreamingResponse. Also contains utilities
for translating generic streams into WebSocket frames.
"""

import json
import logging
from typing import AsyncGenerator, Any, Dict

logger = logging.getLogger(__name__)

async def format_sse(generator: AsyncGenerator[Any, None], event_type: str = "message") -> AsyncGenerator[str, None]:
    """
    Wraps an existing async generator and formats the output as SSE format.
    
    Format:
    event: <event_type>
    data: <json string or raw string>
    \n\n
    """
    try:
        async for item in generator:
            if isinstance(item, str):
                # Raw text streaming (e.g. LLM chunks)
                payload = json.dumps({"content": item})
                yield f"event: {event_type}\ndata: {payload}\n\n"
            elif isinstance(item, dict):
                # Structured data streaming
                payload = json.dumps(item)
                yield f"event: {event_type}\ndata: {payload}\n\n"
            else:
                # Fallback for objects like Pydantic models
                if hasattr(item, "model_dump_json"):
                    payload = item.model_dump_json()
                else:
                    payload = json.dumps(str(item))
                yield f"event: {event_type}\ndata: {payload}\n\n"
    except Exception as e:
        logger.error(f"Streaming error in SSE formatter: {str(e)}")
        error_payload = json.dumps({"error": str(e)})
        yield f"event: error\ndata: {error_payload}\n\n"
    finally:
        # Send a terminal event so the client knows to close the connection
        yield "event: done\ndata: [DONE]\n\n"

async def ws_stream_adapter(websocket_sender: Any, generator: AsyncGenerator[Any, None]):
    """
    Adapts an async generator to push directly to a WebSocket connection.
    Useful for bridging generic agent outputs to real-time socket clients.
    
    Args:
        websocket_sender: A callable like `websocket.send_json`
        generator: The source stream
    """
    try:
        async for chunk in generator:
            if isinstance(chunk, str):
                await websocket_sender({"type": "chunk", "data": chunk})
            else:
                await websocket_sender({"type": "event", "data": chunk})
        await websocket_sender({"type": "done"})
    except Exception as e:
        logger.error(f"WebSocket streaming adapter failed: {str(e)}")
        await websocket_sender({"type": "error", "message": str(e)})
