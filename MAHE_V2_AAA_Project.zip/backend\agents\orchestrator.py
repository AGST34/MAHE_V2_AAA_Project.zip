"""
Orchestrator Module

This module defines the Orchestrator, the central nervous system of MAHE V2.
It is responsible for taking an evaluation request, fanning it out to multiple
target agents concurrently, awaiting their responses (with timeout handling),
and then passing those responses sequentially or concurrently to the Judge agent.
"""

import asyncio
import logging
import time
from typing import List, Optional, Dict, Any, Tuple

from backend.agents.gemini_agent import GeminiAgent
from backend.agents.openai_agent import OpenAIAgent
from backend.agents.claude_agent import ClaudeAgent
from backend.agents.judge_agent import JudgeAgent
from backend.schemas import EvaluationResultSchema
from backend.websocket import manager as ws_manager

logger = logging.getLogger(__name__)

class Orchestrator:
    """
    Coordinates the concurrent execution of multiple AI agents and handles 
    the pipeline of generation -> evaluation -> aggregation.
    """
    
    def __init__(self, room_id: Optional[str] = None):
        """
        Initializes the Orchestrator.
        
        Args:
            room_id (str, optional): A WebSocket room ID to broadcast progress to.
        """
        self.room_id = room_id
        
        # Lazy initialization of available agents
        self.available_agents = {
            "gemini-pro": GeminiAgent(model="gemini-pro"),
            "gpt-4": OpenAIAgent(model="gpt-4"),
            "gpt-3.5-turbo": OpenAIAgent(model="gpt-3.5-turbo"),
            "claude-3": ClaudeAgent(model="claude-3-opus")
        }
        
        # The primary evaluator
        self.judge = JudgeAgent(strict_mode=False)

    async def _emit_progress(self, event_type: str, data: Dict[str, Any]):
        """Helper to stream progress over WebSockets if a room is defined."""
        if self.room_id:
            payload = {
                "type": event_type,
                "timestamp": time.time(),
                "data": data
            }
            await ws_manager.broadcast_to_room(self.room_id, payload)
            logger.debug(f"Emitted WS event {event_type} to room {self.room_id}")

    async def _generate_and_judge(self, agent_name: str, prompt: str, context: Optional[str]) -> EvaluationResultSchema:
        """
        Pipeline for a single agent:
        1. Request generation
        2. Wait for completion
        3. Pass to judge
        4. Assemble result schema
        """
        if agent_name not in self.available_agents:
            logger.error(f"Requested agent '{agent_name}' is not configured.")
            # Return an error schema immediately
            return EvaluationResultSchema(
                id="error",
                agent_name=agent_name,
                response_text=f"Configuration Error: Agent {agent_name} not found.",
                status="failed"
            )
            
        agent = self.available_agents[agent_name]
        
        # --- STEP 1: Generation ---
        await self._emit_progress("generation_started", {"agent": agent_name})
        
        # Execute the agent's run method (which includes retries/timeouts)
        gen_response = await agent.run(prompt, context=context, timeout_seconds=45)
        
        await self._emit_progress("generation_completed", {
            "agent": agent_name, 
            "status": gen_response.status,
            "time_ms": gen_response.processing_time_ms
        })
        
        # If generation failed completely, return partial result without judging
        if gen_response.status != "success":
            return EvaluationResultSchema(
                id=str(time.time()), # Placeholder
                agent_name=agent_name,
                response_text=gen_response.content,
                hallucination_score=None,
                coherence_score=None,
                factual_accuracy=None,
                composite_score=None,
                judge_rationale=f"Generation Failed: {gen_response.error_message}",
                processing_time_ms=gen_response.processing_time_ms,
                tokens_used_total=gen_response.total_tokens
            )
            
        # --- STEP 2: Evaluation (Judging) ---
        await self._emit_progress("judging_started", {"agent": agent_name})
        
        judge_start = time.time()
        try:
            evaluation = await self.judge.evaluate(prompt, context, gen_response.content)
            judge_status = "success"
        except Exception as e:
            logger.error(f"Judge failed for agent {agent_name}: {str(e)}")
            evaluation = {
                "hallucination_score": None,
                "coherence_score": None,
                "factual_accuracy": None,
                "judge_rationale": f"Judging error: {str(e)}"
            }
            judge_status = "error"
            
        judge_time_ms = int((time.time() - judge_start) * 1000)
        
        await self._emit_progress("judging_completed", {
            "agent": agent_name, 
            "status": judge_status,
            "time_ms": judge_time_ms
        })
        
        # --- STEP 3: Assembly ---
        # Calculate composite score manually here if needed, or rely on schema
        h_score = evaluation.get("hallucination_score")
        c_score = evaluation.get("coherence_score")
        f_score = evaluation.get("factual_accuracy")
        
        comp_score = None
        if None not in (h_score, c_score, f_score):
            # Same formula as defined in models
            comp_score = max(0.0, min(1.0, (c_score * 0.4) + (f_score * 0.6) - (h_score * 0.5)))
            
        return EvaluationResultSchema(
            id=str(time.time()), # Placeholder ID, will be overwritten by DB insert
            agent_name=agent_name,
            response_text=gen_response.content,
            hallucination_score=h_score,
            coherence_score=c_score,
            factual_accuracy=f_score,
            composite_score=comp_score,
            judge_rationale=evaluation.get("judge_rationale"),
            processing_time_ms=gen_response.processing_time_ms + judge_time_ms,
            tokens_used_total=gen_response.total_tokens
        )

    async def run_evaluation(self, prompt: str, context: Optional[str], models: List[str]) -> List[EvaluationResultSchema]:
        """
        Executes the entire orchestrator pipeline.
        Fans out the generation tasks concurrently and aggregates the results.
        
        Args:
            prompt (str): Target prompt.
            context (str, optional): Context string.
            models (List[str]): List of model names to evaluate.
            
        Returns:
            List[EvaluationResultSchema]: Collected results.
        """
        logger.info(f"Orchestrator starting evaluation for models: {models}")
        await self._emit_progress("orchestrator_started", {"models": models})
        
        # Create asynchronous tasks for the entire pipeline of each agent
        # (generate -> judge happens sequentially *within* each concurrent task)
        tasks = [
            self._generate_and_judge(model_name, prompt, context) 
            for model_name in models
        ]
        
        # Execute all tasks concurrently.
        # return_exceptions=True ensures that a failure in one agent doesn't crash the entire batch.
        results_raw = await asyncio.gather(*tasks, return_exceptions=True)
        
        final_results = []
        for i, res in enumerate(results_raw):
            if isinstance(res, Exception):
                logger.error(f"Uncaught exception in Orchestrator for {models[i]}: {str(res)}")
                final_results.append(
                    EvaluationResultSchema(
                        id="fatal_error",
                        agent_name=models[i],
                        response_text="",
                        judge_rationale=f"Fatal Orchestrator Error: {str(res)}",
                        status="failed"
                    )
                )
            else:
                final_results.append(res)
                
        await self._emit_progress("orchestrator_completed", {"total_results": len(final_results)})
        logger.info(f"Orchestrator finished evaluation. Gathered {len(final_results)} results.")
        
        return final_results
