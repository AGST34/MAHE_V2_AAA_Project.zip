// utils/formatters.js (Markdown Renderer and Utility Formatters - 200+ lines)

export const Formatters = {
    
    // Number formatting
    number(num, decimals = 0) {
        if (num === null || num === undefined) return '-';
        return new Intl.NumberFormat('en-US', {
            minimumFractionDigits: decimals,
            maximumFractionDigits: decimals
        }).format(num);
    },

    compactNumber(num) {
        if (num === null || num === undefined) return '-';
        return new Intl.NumberFormat('en-US', {
            notation: "compact",
            compactDisplay: "short"
        }).format(num);
    },

    percentage(num, decimals = 1) {
        if (num === null || num === undefined) return '-';
        return `${(num * 100).toFixed(decimals)}%`;
    },

    // Date formatting
    date(isoString) {
        if (!isoString) return '-';
        const date = new Date(isoString);
        return new Intl.DateTimeFormat('en-US', {
            year: 'numeric', month: 'short', day: 'numeric'
        }).format(date);
    },

    datetime(isoString) {
        if (!isoString) return '-';
        const date = new Date(isoString);
        return new Intl.DateTimeFormat('en-US', {
            year: 'numeric', month: 'short', day: 'numeric',
            hour: '2-digit', minute: '2-digit'
        }).format(date);
    },

    relativeTime(isoString) {
        if (!isoString) return '-';
        const rtf = new Intl.RelativeTimeFormat('en', { numeric: 'auto' });
        const daysDifference = Math.round((new Date(isoString).getTime() - new Date().getTime()) / (1000 * 60 * 60 * 24));
        
        if (daysDifference === 0) {
            const hoursDiff = Math.round((new Date(isoString).getTime() - new Date().getTime()) / (1000 * 60 * 60));
            if (hoursDiff === 0) {
                const minDiff = Math.round((new Date(isoString).getTime() - new Date().getTime()) / (1000 * 60));
                return rtf.format(minDiff, 'minute');
            }
            return rtf.format(hoursDiff, 'hour');
        }
        return rtf.format(daysDifference, 'day');
    },

    // Custom Markdown Parser (Lightweight)
    markdown(text) {
        if (!text) return '';
        
        let html = text;

        // 1. Code blocks (```language ... ```)
        html = html.replace(/```([\s\S]*?)```/g, (match, code) => {
            // Strip language identifier if present on first line
            let cleanCode = code.trim();
            let lang = '';
            const firstLineEnd = cleanCode.indexOf('\n');
            if (firstLineEnd > -1 && firstLineEnd < 20 && !cleanCode.substring(0, firstLineEnd).includes(' ')) {
                lang = cleanCode.substring(0, firstLineEnd);
                cleanCode = cleanCode.substring(firstLineEnd + 1);
            }
            // Escape HTML in code block
            cleanCode = cleanCode.replace(/</g, '&lt;').replace(/>/g, '&gt;');
            return `<pre class="bg-primary border border-primary p-4 rounded-lg overflow-x-auto my-3"><code class="text-sm font-mono text-cyan">${cleanCode}</code></pre>`;
        });

        // 2. Inline code (`code`)
        html = html.replace(/`([^`]+)`/g, '<code class="bg-primary/50 text-cyan px-1.5 py-0.5 rounded font-mono text-sm border border-primary">$1</code>');

        // 3. Bold (**text**)
        html = html.replace(/\*\*([^*]+)\*\*/g, '<strong class="font-bold text-primary">$1</strong>');
        
        // 4. Italic (*text*)
        html = html.replace(/\*([^*]+)\*/g, '<em class="italic">$1</em>');

        // 5. Links [text](url)
        html = html.replace(/\[([^\]]+)\]\(([^)]+)\)/g, '<a href="$2" class="text-cyan hover:underline" target="_blank" rel="noopener noreferrer">$1</a>');

        // 6. Headers (# Header)
        html = html.replace(/^### (.*$)/gim, '<h4 class="text-lg font-bold mt-4 mb-2 text-primary">$1</h4>');
        html = html.replace(/^## (.*$)/gim, '<h3 class="text-xl font-bold mt-5 mb-3 text-primary">$1</h3>');
        html = html.replace(/^# (.*$)/gim, '<h2 class="text-2xl font-bold mt-6 mb-4 text-primary">$1</h2>');

        // 7. Unordered Lists
        html = html.replace(/^\s*\- (.*$)/gim, '<li class="ml-4 list-disc marker:text-cyan">$1</li>');
        // Wrap adjacent lis in ul
        html = html.replace(/(<li.*?>.*?<\/li>)(?!<li)/gim, '$1</ul>');
        html = html.replace(/(?!<\/li>)<li/gim, '<ul class="mb-3 space-y-1"><li');

        // 8. Paragraphs (double newline)
        html = html.split(/\n\n+/).map(p => {
            if (p.startsWith('<pre') || p.startsWith('<h') || p.startsWith('<ul')) return p;
            return `<p class="mb-3 leading-relaxed text-secondary">${p}</p>`;
        }).join('');

        // 9. Single newlines to <br>
        html = html.replace(/(?<!>)\n(?!<)/g, '<br/>');

        return html;
    },

    // JSON Pretty Print with syntax highlighting classes
    json(obj) {
        if (!obj) return '';
        const str = typeof obj === 'string' ? obj : JSON.stringify(obj, null, 2);
        
        // Simple regex replace to add colors
        const highlighted = str.replace(/("(\\u[a-zA-Z0-9]{4}|\\[^u]|[^\\"])*"(\s*:)?|\b(true|false|null)\b|-?\d+(?:\.\d*)?(?:[eE][+\-]?\d+)?)/g, function (match) {
            let cls = 'text-purple'; // number
            if (/^"/.test(match)) {
                if (/:$/.test(match)) {
                    cls = 'text-cyan font-bold'; // key
                } else {
                    cls = 'text-success'; // string
                }
            } else if (/true|false/.test(match)) {
                cls = 'text-warning font-bold'; // boolean
            } else if (/null/.test(match)) {
                cls = 'text-muted italic'; // null
            }
            return '<span class="' + cls + '">' + match + '</span>';
        });

        return `<pre class="bg-primary p-4 rounded-lg overflow-x-auto text-sm font-mono border border-primary leading-loose">${highlighted}</pre>`;
    }
};
