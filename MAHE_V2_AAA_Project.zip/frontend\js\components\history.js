// history.js (Detailed Evaluation History with Table logic, sorting, filtering)
export default {
    render(app) {
        const div = document.createElement('div');
        div.className = 'history-view fade-in flex flex-col h-full';
        
        div.innerHTML = `
            <div class="glass-panel p-6 rounded-xl flex flex-col h-full min-h-[600px] shadow-lg border border-primary">
                <!-- Header & Actions -->
                <div class="flex flex-col md:flex-row justify-between items-start md:items-center mb-6 gap-4">
                    <div>
                        <h3 class="text-xl font-bold flex items-center gap-2">
                            <svg class="w-6 h-6 text-purple"><use href="#icon-history"></use></svg>
                            Evaluation Ledger
                        </h3>
                        <p class="text-sm text-muted mt-1">Comprehensive log of all model hallucinations and clean responses.</p>
                    </div>
                    
                    <div class="flex flex-wrap items-center gap-3">
                        <div class="relative">
                            <svg class="w-4 h-4 absolute left-3 top-1/2 transform -translate-y-1/2 text-muted"><use href="#icon-search"></use></svg>
                            <input type="text" id="history-search" class="bg-tertiary border border-primary rounded-lg pl-9 pr-4 py-2 text-sm focus:border-cyan w-64" placeholder="Search queries, models, IDs...">
                        </div>
                        
                        <button class="btn btn-secondary flex items-center gap-2" id="btn-filter">
                            <svg class="w-4 h-4"><use href="#icon-filter"></use></svg>
                            Filters
                        </button>
                        
                        <button class="btn btn-secondary flex items-center gap-2" id="btn-export">
                            <svg class="w-4 h-4"><use href="#icon-download"></use></svg>
                            Export CSV
                        </button>
                    </div>
                </div>
                
                <!-- Filter Panel (Hidden by default) -->
                <div id="filter-panel" class="hidden bg-tertiary border border-primary rounded-lg p-4 mb-6 animate-slide-down">
                    <div class="grid grid-cols-4 gap-4">
                        <div>
                            <label class="block text-xs text-secondary mb-1">Status</label>
                            <select class="form-control text-sm">
                                <option>All</option>
                                <option>Clean</option>
                                <option>Hallucination</option>
                            </select>
                        </div>
                        <div>
                            <label class="block text-xs text-secondary mb-1">Model</label>
                            <select class="form-control text-sm">
                                <option>All Models</option>
                                <option>GPT-4o</option>
                                <option>Claude 3</option>
                                <option>Gemini 1.5</option>
                            </select>
                        </div>
                        <div>
                            <label class="block text-xs text-secondary mb-1">Date Range</label>
                            <select class="form-control text-sm">
                                <option>Last 7 Days</option>
                                <option>Last 30 Days</option>
                                <option>All Time</option>
                            </select>
                        </div>
                        <div class="flex items-end">
                            <button class="btn btn-primary w-full text-sm">Apply Filters</button>
                        </div>
                    </div>
                </div>

                <!-- Table Container -->
                <div class="table-container flex-1 overflow-hidden flex flex-col border border-primary rounded-lg">
                    <div class="overflow-y-auto flex-1">
                        <table class="data-table w-full">
                            <thead class="sticky top-0 bg-tertiary z-10 shadow-sm">
                                <tr>
                                    <th class="w-10 text-center"><input type="checkbox" class="accent-cyan"></th>
                                    <th class="cursor-pointer hover:text-cyan transition-colors group">EVAL ID <svg class="w-3 h-3 inline opacity-0 group-hover:opacity-100"><use href="#icon-chevron-down"></use></svg></th>
                                    <th class="cursor-pointer hover:text-cyan transition-colors group">DATE <svg class="w-3 h-3 inline opacity-0 group-hover:opacity-100"><use href="#icon-chevron-down"></use></svg></th>
                                    <th>MODEL</th>
                                    <th class="w-2/5">USER QUERY</th>
                                    <th>STATUS</th>
                                    <th>SCORE</th>
                                    <th class="text-right">ACTIONS</th>
                                </tr>
                            </thead>
                            <tbody id="history-table-body">
                                <!-- Populated by JS -->
                            </tbody>
                        </table>
                    </div>
                    
                    <!-- Pagination -->
                    <div class="bg-tertiary border-t border-primary p-4 flex justify-between items-center text-sm text-secondary">
                        <div>Showing <span class="text-primary font-medium">1-10</span> of <span class="text-primary font-medium">1,245</span> entries</div>
                        <div class="flex gap-2">
                            <button class="btn btn-secondary px-3 py-1 text-xs disabled:opacity-50" disabled>Previous</button>
                            <button class="btn bg-cyan text-black px-3 py-1 text-xs font-bold border-none">1</button>
                            <button class="btn btn-secondary px-3 py-1 text-xs">2</button>
                            <button class="btn btn-secondary px-3 py-1 text-xs">3</button>
                            <span class="px-2">...</span>
                            <button class="btn btn-secondary px-3 py-1 text-xs">125</button>
                            <button class="btn btn-secondary px-3 py-1 text-xs">Next</button>
                        </div>
                    </div>
                </div>
            </div>
        `;
        return div;
    },

    init(app) {
        this.app = app;
        this.bindEvents();
        this.loadHistoryData();
    },

    bindEvents() {
        const filterBtn = document.getElementById('btn-filter');
        const filterPanel = document.getElementById('filter-panel');
        
        if (filterBtn && filterPanel) {
            filterBtn.addEventListener('click', () => {
                filterPanel.classList.toggle('hidden');
            });
        }

        const exportBtn = document.getElementById('btn-export');
        if (exportBtn) {
            exportBtn.addEventListener('click', () => {
                this.app.toast.info('Preparing CSV export...', { duration: 2000 });
                setTimeout(() => {
                    this.app.toast.success('history_export_2024.csv downloaded.');
                }, 2000);
            });
        }
    },

    loadHistoryData() {
        // Mock Data Generation
        const tbody = document.getElementById('history-table-body');
        if (!tbody) return;

        const data = [
            { id: 'EVAL-1042', date: 'Oct 24, 14:32', model: 'GPT-4o', query: 'Write a python script to parse JSON logs and extract error codes.', status: 'clean', score: 0.98 },
            { id: 'EVAL-1041', date: 'Oct 24, 11:15', model: 'Claude 3 Opus', query: 'Summarize the plot of Inception and focus on the spinning top.', status: 'hallucination', score: 0.45 },
            { id: 'EVAL-1040', date: 'Oct 23, 16:45', model: 'Gemini 1.5', query: 'Explain quantum entanglement in simple terms for a 5 year old.', status: 'clean', score: 0.95 },
            { id: 'EVAL-1039', date: 'Oct 23, 09:10', model: 'Llama 3 70B', query: 'Who won the 2024 Super Bowl and what was the final score?', status: 'hallucination', score: 0.22 },
            { id: 'EVAL-1038', date: 'Oct 22, 14:20', model: 'GPT-4 Turbo', query: 'What are the side effects of taking amoxicillin with ibuprofen?', status: 'clean', score: 0.99 },
            { id: 'EVAL-1037', date: 'Oct 22, 10:05', model: 'Mistral Large', query: 'Provide a complete working React code for a tree view component.', status: 'hallucination', score: 0.55 },
            { id: 'EVAL-1036', date: 'Oct 21, 15:30', model: 'GPT-4o', query: 'Translate this French text to English and maintain the poetic tone.', status: 'clean', score: 0.92 }
        ];

        let html = '';
        data.forEach((row, i) => {
            const isClean = row.status === 'clean';
            const statusBadge = isClean ? 
                `<span class="badge badge-success px-2 py-1"><svg class="w-3 h-3 inline mr-1"><use href="#icon-check"></use></svg>Clean</span>` : 
                `<span class="badge badge-error px-2 py-1"><svg class="w-3 h-3 inline mr-1"><use href="#icon-alert"></use></svg>Hallucination</span>`;
                
            const modelColor = row.model.includes('GPT') ? 'text-cyan' : row.model.includes('Claude') ? 'text-purple' : 'text-primary';
            const scoreColor = row.score > 0.8 ? 'text-success' : row.score > 0.5 ? 'text-warning' : 'text-error';

            html += `
                <tr class="hover:bg-glass border-b border-primary transition-colors delay-${i * 100} animate-fade-in" style="opacity:0; animation-delay: ${i * 50}ms;">
                    <td class="text-center"><input type="checkbox" class="accent-cyan"></td>
                    <td class="font-mono text-xs text-muted">${row.id}</td>
                    <td class="text-sm text-secondary">${row.date}</td>
                    <td class="text-sm font-medium ${modelColor}">${row.model}</td>
                    <td class="text-sm text-secondary truncate max-w-[300px]" title="${row.query}">${row.query}</td>
                    <td>${statusBadge}</td>
                    <td class="font-mono text-sm font-bold ${scoreColor}">${row.score.toFixed(2)}</td>
                    <td class="text-right">
                        <button class="btn btn-secondary px-2 py-1 text-xs" title="View Details">
                            <svg class="w-4 h-4"><use href="#icon-search"></use></svg>
                        </button>
                    </td>
                </tr>
            `;
        });

        tbody.innerHTML = html;
    }
}
