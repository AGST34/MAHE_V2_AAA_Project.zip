// components/loading.js (Comprehensive Skeleton and Progress Loading states)
export const LoadingSystem = {
    // Top-level progress bar for route transitions
    progress: {
        el: null,
        value: 0,
        interval: null,
        
        init() {
            this.el = document.createElement('div');
            this.el.className = 'fixed top-0 left-0 h-1 bg-cyan z-[9999] transition-all duration-200 shadow-cyan-glow';
            this.el.style.width = '0%';
            this.el.style.opacity = '0';
            document.body.appendChild(this.el);
        },
        
        start() {
            if (!this.el) this.init();
            clearInterval(this.interval);
            
            this.value = 0;
            this.el.style.opacity = '1';
            this.el.style.width = '0%';
            
            this.interval = setInterval(() => {
                this.value += Math.random() * 10;
                if (this.value > 90) this.value = 90; // Never fully complete automatically
                this.el.style.width = `${this.value}%`;
            }, 200);
        },
        
        done() {
            if (!this.el) return;
            clearInterval(this.interval);
            
            this.value = 100;
            this.el.style.width = '100%';
            
            setTimeout(() => {
                this.el.style.opacity = '0';
                setTimeout(() => {
                    this.el.style.width = '0%';
                }, 200);
            }, 300);
        }
    },

    // Skeleton screen generators
    skeletons: {
        dashboard() {
            return `
                <div class="dashboard-grid fade-in">
                    <!-- Stats -->
                    <div class="col-span-3 h-32 skeleton rounded-xl"></div>
                    <div class="col-span-3 h-32 skeleton rounded-xl"></div>
                    <div class="col-span-3 h-32 skeleton rounded-xl"></div>
                    <div class="col-span-3 h-32 skeleton rounded-xl"></div>
                    
                    <!-- Charts -->
                    <div class="col-span-8 h-[400px] skeleton rounded-xl mt-4"></div>
                    <div class="col-span-4 h-[400px] skeleton rounded-xl mt-4"></div>
                </div>
            `;
        },
        
        table(rows = 5) {
            let rowHtml = '';
            for(let i=0; i<rows; i++) {
                rowHtml += `
                    <div class="flex items-center p-4 border-b border-primary">
                        <div class="w-10 h-4 skeleton mr-4"></div>
                        <div class="w-24 h-4 skeleton mr-4"></div>
                        <div class="w-32 h-4 skeleton mr-4"></div>
                        <div class="flex-1 h-4 skeleton mr-4"></div>
                        <div class="w-20 h-6 skeleton rounded-full mr-4"></div>
                        <div class="w-16 h-4 skeleton"></div>
                    </div>
                `;
            }
            return `
                <div class="border border-primary rounded-xl overflow-hidden fade-in bg-secondary">
                    <div class="bg-tertiary p-4 flex justify-between border-b border-primary">
                        <div class="w-48 h-6 skeleton"></div>
                        <div class="w-64 h-8 skeleton rounded"></div>
                    </div>
                    <div class="bg-tertiary p-3 flex border-b border-primary">
                        <div class="w-full h-4 skeleton opacity-50"></div>
                    </div>
                    ${rowHtml}
                </div>
            `;
        },
        
        form() {
            return `
                <div class="glass-panel p-6 rounded-xl fade-in max-w-2xl">
                    <div class="w-48 h-8 skeleton mb-8"></div>
                    
                    <div class="mb-6">
                        <div class="w-32 h-4 skeleton mb-2"></div>
                        <div class="w-full h-10 skeleton rounded"></div>
                    </div>
                    
                    <div class="mb-6">
                        <div class="w-40 h-4 skeleton mb-2"></div>
                        <div class="w-full h-24 skeleton rounded"></div>
                    </div>
                    
                    <div class="mb-8">
                        <div class="w-36 h-4 skeleton mb-2"></div>
                        <div class="grid grid-cols-2 gap-4">
                            <div class="h-12 skeleton rounded"></div>
                            <div class="h-12 skeleton rounded"></div>
                        </div>
                    </div>
                    
                    <div class="w-full h-12 skeleton rounded-lg mt-4"></div>
                </div>
            `;
        }
    }
};
