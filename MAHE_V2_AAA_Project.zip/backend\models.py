"""
SQLAlchemy ORM Models Module

This module defines the schema definitions for the database tables.
It includes comprehensive models for Users, API Keys, Usage Logs, Evaluations,
and Evaluation Results, complete with relationships, indexes, and utility methods.
"""

from datetime import datetime
from typing import List, Optional

from sqlalchemy import Boolean, Column, DateTime, Float, ForeignKey, Integer, String, Text, Index
from sqlalchemy.orm import Mapped, mapped_column, relationship

from backend.database import Base, TimestampMixin, UUIDMixin


class User(Base, UUIDMixin, TimestampMixin):
    """
    User model representing an account in the system.
    Users can have multiple API keys and perform multiple evaluations.
    """
    __tablename__ = "users"

    email: Mapped[str] = mapped_column(String(255), unique=True, index=True, nullable=False)
    hashed_password: Mapped[str] = mapped_column(String(255), nullable=False)
    full_name: Mapped[Optional[str]] = mapped_column(String(255), nullable=True)
    
    is_active: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)
    is_superuser: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    
    # Relationships
    api_keys: Mapped[List["APIKey"]] = relationship(
        "APIKey", 
        back_populates="user", 
        cascade="all, delete-orphan",
        lazy="selectin"
    )
    evaluations: Mapped[List["Evaluation"]] = relationship(
        "Evaluation", 
        back_populates="user", 
        cascade="all, delete-orphan",
        lazy="selectin"
    )

    def __repr__(self) -> str:
        return f"<User(id={self.id}, email={self.email}, active={self.is_active})>"


class APIKey(Base, UUIDMixin, TimestampMixin):
    """
    API Key model for programmatic access to the API.
    Linked to a specific user and tracks expiration and state.
    """
    __tablename__ = "api_keys"

    key: Mapped[str] = mapped_column(String(255), unique=True, index=True, nullable=False)
    name: Mapped[str] = mapped_column(String(100), nullable=False)
    user_id: Mapped[str] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"), nullable=False)
    
    is_active: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)
    expires_at: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True), nullable=True)
    last_used_at: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True), nullable=True)

    # Relationships
    user: Mapped["User"] = relationship("User", back_populates="api_keys")
    usage_logs: Mapped[List["UsageLog"]] = relationship(
        "UsageLog", 
        back_populates="api_key", 
        cascade="all, delete-orphan",
        lazy="noload" # Don't load logs automatically
    )

    __table_args__ = (
        Index("ix_api_keys_user_id_active", "user_id", "is_active"),
    )

    def is_valid(self) -> bool:
        """Checks if the API key is active and not expired."""
        if not self.is_active:
            return False
        if self.expires_at and datetime.utcnow() > self.expires_at:
            return False
        return True


class UsageLog(Base, UUIDMixin, TimestampMixin):
    """
    Usage Log model to track API consumption and token usage.
    Crucial for rate limiting and billing/analytics.
    """
    __tablename__ = "usage_logs"

    api_key_id: Mapped[str] = mapped_column(ForeignKey("api_keys.id", ondelete="CASCADE"), nullable=False)
    endpoint: Mapped[str] = mapped_column(String(255), nullable=False)
    method: Mapped[str] = mapped_column(String(10), nullable=False)
    status_code: Mapped[int] = mapped_column(Integer, nullable=False)
    
    tokens_used: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    processing_time_ms: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    ip_address: Mapped[Optional[str]] = mapped_column(String(50), nullable=True)

    # Relationships
    api_key: Mapped["APIKey"] = relationship("APIKey", back_populates="usage_logs")

    __table_args__ = (
        Index("ix_usage_logs_api_key_id_created_at", "api_key_id", "created_at"),
    )


class Evaluation(Base, UUIDMixin, TimestampMixin):
    """
    Evaluation model representing a single evaluation request.
    It contains the original prompt, context, and overall status.
    """
    __tablename__ = "evaluations"

    user_id: Mapped[Optional[str]] = mapped_column(ForeignKey("users.id", ondelete="SET NULL"), nullable=True)
    prompt: Mapped[str] = mapped_column(Text, nullable=False)
    context: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    
    # status can be: pending, running, completed, failed, partial_success
    status: Mapped[str] = mapped_column(String(50), default="pending", nullable=False)
    error_message: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    
    completed_at: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True), nullable=True)
    total_processing_time_ms: Mapped[Optional[int]] = mapped_column(Integer, nullable=True)
    
    # Relationships
    user: Mapped[Optional["User"]] = relationship("User", back_populates="evaluations")
    results: Mapped[List["EvaluationResult"]] = relationship(
        "EvaluationResult", 
        back_populates="evaluation", 
        cascade="all, delete-orphan",
        lazy="selectin"
    )

    __table_args__ = (
        Index("ix_evaluations_user_id_status", "user_id", "status"),
        Index("ix_evaluations_created_at", "created_at"),
    )

    def mark_completed(self, status: str = "completed"):
        """Utility method to finalize the evaluation state."""
        self.status = status
        self.completed_at = datetime.utcnow()


class EvaluationResult(Base, UUIDMixin, TimestampMixin):
    """
    Evaluation Result model representing the output of a specific agent 
    for a given evaluation, along with the judge's scoring.
    """
    __tablename__ = "evaluation_results"

    evaluation_id: Mapped[str] = mapped_column(ForeignKey("evaluations.id", ondelete="CASCADE"), nullable=False)
    agent_name: Mapped[str] = mapped_column(String(100), nullable=False)
    model_version: Mapped[Optional[str]] = mapped_column(String(100), nullable=True)
    
    response_text: Mapped[str] = mapped_column(Text, nullable=False)
    
    # Metrics
    hallucination_score: Mapped[Optional[float]] = mapped_column(Float, nullable=True)
    coherence_score: Mapped[Optional[float]] = mapped_column(Float, nullable=True)
    factual_accuracy: Mapped[Optional[float]] = mapped_column(Float, nullable=True)
    composite_score: Mapped[Optional[float]] = mapped_column(Float, nullable=True)
    
    # Judge details
    judge_rationale: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    meta_judge_score: Mapped[Optional[float]] = mapped_column(Float, nullable=True)
    
    # Telemetry
    processing_time_ms: Mapped[Optional[int]] = mapped_column(Integer, nullable=True)
    tokens_used_prompt: Mapped[Optional[int]] = mapped_column(Integer, nullable=True)
    tokens_used_completion: Mapped[Optional[int]] = mapped_column(Integer, nullable=True)
    
    # Relationships
    evaluation: Mapped["Evaluation"] = relationship("Evaluation", back_populates="results")

    __table_args__ = (
        Index("ix_eval_results_eval_id_agent", "evaluation_id", "agent_name"),
    )

    def compute_composite_score(self):
        """Calculates and updates the composite score based on individual metrics."""
        if None not in (self.hallucination_score, self.coherence_score, self.factual_accuracy):
            # Formula: (Coherence * 0.4) + (Accuracy * 0.6) - (Hallucination * 0.5)
            # Normalized to 0-1 bounds roughly depending on implementation
            base = (self.coherence_score * 0.4) + (self.factual_accuracy * 0.6)
            penalty = self.hallucination_score * 0.5
            self.composite_score = max(0.0, min(1.0, base - penalty))
