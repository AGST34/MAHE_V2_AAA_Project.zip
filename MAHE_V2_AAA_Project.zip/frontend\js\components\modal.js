// components/modal.js (Reusable Modal System - 150+ lines)
export const Modal = {
    init() {
        this.backdrop = document.getElementById('modal-backdrop');
        this.container = document.getElementById('modal-container');
        
        if (!this.backdrop || !this.container) return;
        
        this.backdrop.addEventListener('click', () => {
            // Close top-most modal if backdrop clicked
            this.closeAll();
        });
        
        // Listen to global event bus if available
        if (window.app && window.app.events) {
            window.app.events.on('ui:close_overlays', () => {
                this.closeAll();
            });
        }
    },
    
    show(options = {}) {
        if (!this.backdrop) this.init();
        
        const {
            title = 'Modal Title',
            content = '',
            size = 'md', // sm, md, lg, xl
            buttons = []
        } = options;
        
        // Generate UUID for this modal
        const id = 'modal_' + Math.random().toString(36).substr(2, 9);
        
        const sizeClass = {
            'sm': 'max-w-sm',
            'md': 'max-w-md',
            'lg': 'max-w-2xl',
            'xl': 'max-w-4xl'
        }[size] || 'max-w-md';

        const modalEl = document.createElement('div');
        modalEl.className = 'modal-dialog ' + sizeClass;
        modalEl.id = id;
        
        let footerHtml = '';
        if (buttons.length > 0) {
            footerHtml = `<div class="modal-footer">`;
            buttons.forEach((btn, idx) => {
                const btnClass = btn.type === 'primary' ? 'btn-primary' : (btn.type === 'danger' ? 'btn-danger' : 'btn-secondary');
                footerHtml += `<button class="btn ${btnClass}" id="btn-${id}-${idx}">${btn.text}</button>`;
            });
            footerHtml += `</div>`;
        }
        
        modalEl.innerHTML = `
            <div class="modal-content">
                <div class="modal-header">
                    <h3 class="modal-title">${title}</h3>
                    <button class="modal-close" id="close-${id}">
                        <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path></svg>
                    </button>
                </div>
                <div class="modal-body">
                    ${content}
                </div>
                ${footerHtml}
            </div>
        `;
        
        this.container.appendChild(modalEl);
        
        // Bind events
        document.getElementById(`close-${id}`).addEventListener('click', () => this.close(id));
        
        if (buttons.length > 0) {
            buttons.forEach((btn, idx) => {
                document.getElementById(`btn-${id}-${idx}`).addEventListener('click', () => {
                    if (typeof btn.onClick === 'function') {
                        if (btn.onClick() !== false) {
                            this.close(id);
                        }
                    } else {
                        this.close(id);
                    }
                });
            });
        }
        
        // Show
        this.backdrop.classList.remove('hidden');
        this.container.classList.remove('hidden');
        
        // Animate in
        requestAnimationFrame(() => {
            this.backdrop.style.opacity = '1';
            this.container.classList.add('show');
        });
        
        return id;
    },
    
    close(id) {
        const modalEl = document.getElementById(id);
        if (!modalEl) return;
        
        modalEl.classList.remove('show');
        
        // If it's the last modal, hide container
        if (this.container.children.length <= 1) {
            this.container.classList.remove('show');
            this.backdrop.style.opacity = '0';
            
            setTimeout(() => {
                modalEl.remove();
                this.backdrop.classList.add('hidden');
                this.container.classList.add('hidden');
            }, 200);
        } else {
            setTimeout(() => {
                modalEl.remove();
            }, 200);
        }
    },
    
    closeAll() {
        Array.from(this.container.children).forEach(child => {
            this.close(child.id);
        });
    }
};
