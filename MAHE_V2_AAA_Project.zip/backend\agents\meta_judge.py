"""
Meta-Judge Agent Module

This module introduces a meta-evaluation layer. The Meta-Judge evaluates 
the original Judge's rationale to ensure consistency, eliminate bias, 
and provide a confidence score for the hallucination metrics.
"""

import asyncio
import json
import logging
from typing import Dict, Any

from backend.agents.base import BaseAgent

logger = logging.getLogger(__name__)

META_JUDGE_PROMPT = """
You are a Meta-Evaluator. Your job is to assess the quality of an evaluation performed by another AI (the "Judge").
Review the original prompt, context, response, and the Judge's metrics and rationale.
Determine if the Judge's numerical scores align logically with its written rationale.
Check for any extreme bias or contradictory statements in the Judge's reasoning.

Output strictly valid JSON:
{
  "confidence_score": float (0.0 to 1.0, where 1.0 means the judge was perfectly consistent),
  "issues_found": list of strings (any logical gaps or biases found in the judge's rationale),
  "meta_rationale": "Your explanation for this confidence score."
}
"""

class MetaJudgeAgent(BaseAgent):
    """
    Evaluates the evaluator. Uses a powerful reasoning model (e.g., Claude 3 Opus)
    to verify the integrity of the evaluation pipeline.
    """

    def __init__(self, model: str = "claude-3-opus"):
        super().__init__(name="meta_judge", model=model, temperature=0.0)

    async def generate_response(self, prompt: str, context: str = None) -> str:
        return "Meta-judge must be called via evaluate_judge()"

    def _parse_meta_json(self, raw_output: str) -> Dict[str, Any]:
        """Parses the Meta-Judge JSON."""
        cleaned = raw_output.strip()
        if cleaned.startswith("```json"):
            cleaned = cleaned[7:]
        if cleaned.endswith("```"):
            cleaned = cleaned[:-3]
            
        try:
            data = json.loads(cleaned.strip())
            return {
                "confidence_score": max(0.0, min(1.0, float(data.get("confidence_score", 1.0)))),
                "issues_found": data.get("issues_found", []),
                "meta_rationale": data.get("meta_rationale", "")
            }
        except json.JSONDecodeError:
            logger.error(f"Meta-Judge failed to return valid JSON: {raw_output}")
            return {
                "confidence_score": 0.5,
                "issues_found": ["JSON parsing error on meta-judge output"],
                "meta_rationale": "Failed to parse."
            }

    async def evaluate_judge(self, prompt: str, context: str, response: str, judge_eval: Dict[str, Any]) -> Dict[str, Any]:
        """
        Takes all context and the judge's output, and scores the judge.
        """
        payload = (
            f"{META_JUDGE_PROMPT}\n\n"
            f"=== ORIGINAL PROMPT ===\n{prompt}\n\n"
            f"=== CONTEXT ===\n{context}\n\n"
            f"=== AGENT RESPONSE ===\n{response}\n\n"
            f"=== JUDGE EVALUATION ===\n{json.dumps(judge_eval, indent=2)}\n"
        )
        
        # Simulate meta judge API call
        await asyncio.sleep(1.0)
        
        # Mock logic
        h_score = judge_eval.get("hallucination_score", 0)
        rationale = judge_eval.get("judge_rationale", "").lower()
        
        # Simple heuristic test: if hallucination is high but rationale says "perfect", flag it.
        if h_score > 0.8 and "perfect" in rationale:
            mock_resp = '{"confidence_score": 0.2, "issues_found": ["Contradiction: high hallucination score but positive rationale"], "meta_rationale": "The judge contradicts itself."}'
        else:
            mock_resp = '{"confidence_score": 0.95, "issues_found": [], "meta_rationale": "The judge provided consistent and logical reasoning."}'
            
        return self._parse_meta_json(mock_resp)
